# SavvyHRMS (`savvy-hrms`)

Angular front end for SavvyHRMS, converted from the supplied `Latest_HRMS_project` HTML folder. Talks to an ASP.NET Core Web API under `/api`.

> **Status: hand-written scaffold.** `ng build` has been run successfully. `ng lint` currently reports existing template accessibility errors; tests have not yet been run.
> Dependency versions in `package.json` (`^20`) are a best guess; if you prefer the newest Angular, run `ng update`.

## Run
```bash
npm install
npm start            # ng serve with /api proxied to https://localhost:7100 (edit proxy.conf.cjs)
npm run lint
npm test
npm run build
```

## Structure
```
public/assets/          original CSS, fonts, icons, images (copied unchanged; login <style> extracted to css/login.css)
src/app/core/           AuthService (in-memory token), interceptor, guard, PrivilegeService, menu data
src/app/layouts/        auth-layout (login), shell-layout (rail, menu, search, header dropdowns)
src/app/features/       auth/login, self-service/dependents, placeholder
src/app/shared/         otp-input, data-grid, tabs
docs/                   HTML-ANALYSIS.md, PAGE-MAPPING.md
```

## Decisions
- **Bootstrap:** login loads Bootstrap 5.3.3 CSS, the shell loads the supplied Bootstrap **6.0.0-alpha.1** CSS (+ `style.css`), each only while its layout is active (`StylesheetService`). No Bootstrap JS, no jQuery.
  The alpha CSS is self-hosted and unchanged; swap to stable Bootstrap later if you prefer.
- **Behaviour re-implemented in Angular:** app rail, module menu + submenus, global search (Ctrl+K, arrow keys), header dropdowns, role switch, dialogs (native `<dialog>`), login steps, OTP boxes, QR modal.
- **Navigation menu:** after the authenticated shell opens, it posts `{ roleID: 1, searchText: "" }` to `/api/Privilege/getAllPrivilegeData`. The returned privileges are grouped by module and displayed in the shell; menu entries open their Angular placeholder routes until their screens are implemented.
- **Date picker:** Air Datepicker (CDN, no SRI) replaced by a native date input. `css/calendar-css` is retained but currently unused.
- **Client-side CAPTCHA and `admin`/`superadmin` special-casing removed.** The API must return `OtpRequired` / `CaptchaRequired`.

## Security notes
- Token kept in memory only; refresh via HttpOnly/Secure/SameSite cookie from the API. CSRF: Angular sends `X-XSRF-TOKEN` from the `XSRF-TOKEN` cookie.
- User ID validation encrypts the entered ID with AES-CBC/PKCS7 and posts to `/api/Auth/validateuser`; the Angular development proxy forwards it to `https://localhost:7100`, avoiding browser CORS during local development. For a separately hosted production frontend, configure the API to allow that frontend's origin via CORS. Configure `API_SECURITY_KEY` in `src/environments/environment.ts`; because it is included in the frontend bundle, it is visible to browser users and is not suitable as a secret credential. The `encKey` and `encIv` values in `src/environments/environment.ts` must match the API encryption contract.
- No `innerHTML`, `eval`, or `bypassSecurityTrust*`. No inline scripts.
- Route guards are UX only; enforce authorization in the API.
- CSP: Angular emits inline styles, so use a nonce or `style-src 'self' 'unsafe-inline'`; `script-src 'self'`. Add headers at the web server.
- A few elements keep inline `style="..."` from the original markup; move them into CSS classes if you want a stricter `style-src`.

## Known gaps / needs backend
- API contract assumed: `POST /api/auth/{login,verify-otp,refresh,logout}`, `POST /api/Privilege/getAllPrivilegeData`, and dependent CRUD via `GET|POST /api/employee-dependents`, `GET /api/employee-dependents/relation-types`, and `DELETE /api/employee-dependents/{dependentId}`. Dependent create and update both use POST; the dependent ID is included in the POST body for updates. The privilege role ID is currently `1` as in the supplied API request and should be wired to the authenticated user's role ID if role-specific IDs are returned by login.
- Only Login and Dependent Detail exist as real screens; all other menu items open `Placeholder` (designs not in the HTML).
- Payroll, Workforce, Expense, Expense Claims modules had no menu items in the source HTML.
- Google sign-in button is disabled; QR pairing uses the static image; CAPTCHA UI is a stub.
- Notification/alert data in the header is sample data.
- `DataGrid` and `Tabs` are ported from the prototypes but not yet used by a page.
- Large assets (`test.gif` 7 MB, backgrounds 3 MB / 1.9 MB) should be optimised.
- Visual parity with the original (esp. header dropdown positions and the Bootstrap 5/6 mix) has **not** been checked in a browser.
- No unit tests written yet.
