export const environment = {
  production: false,
  /** Base URL of the ASP.NET Core Web API, routed by proxy.conf.cjs in development. */
  apiBaseUrl: 'https://localhost:7100/api',
  API_SECURITY_KEY: '9f2c7a81e6d4b035a8c19f72d5e0b64c3a91f8d7e2b5c6047d8a1f39b6e0c254',
  encKey: '1234567890123456',
  encIv: '6543210987654321',
  defaultGroup: '1',
  withCaptcha: true
};
