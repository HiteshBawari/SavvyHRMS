import { Component, DestroyRef, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StylesheetService } from '../../core/stylesheet.service';

@Component({
  selector: 'savvy-auth-layout',
  imports: [RouterOutlet],
  template: '<router-outlet />',
})
export class AuthLayout {
  constructor() {
    const unload = inject(StylesheetService).load([
      'assets/tabler-icons/tabler-icons.min.css',
      'assets/css/bootstrap_5.min.css',
      'assets/css/login.css',
    ]);
    inject(DestroyRef).onDestroy(unload);
  }
}
