import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, ElementRef, HostListener, computed, inject, signal, viewChild } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { StylesheetService } from '../../core/stylesheet.service';
import { AuthService } from '../../core/auth.service';
import { mapPrivilegesToMenu } from '../../core/menu.data';
import { PrivilegeService } from '../../core/privilege.service';
import { MenuItem, MenuModule } from '../../models/menu.model';
import { Role } from '../../models/auth.model';

type HeaderDropdown = 'role' | 'mail' | 'alerts' | 'settings';
interface OpenSub { key: string; top: number; left: number; }
const EMPTY_MODULE: MenuModule = { id: '', label: '', icon: '', items: [] };

@Component({
  selector: 'savvy-shell-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule],
  templateUrl: './shell-layout.html',
  styleUrl: './shell-layout.css',
})
export class ShellLayout {
  private readonly router = inject(Router);
  readonly auth = inject(AuthService);
  private readonly privilegeService = inject(PrivilegeService);
  private readonly destroyRef = inject(DestroyRef);

  readonly modules = signal<MenuModule[]>([]);
  readonly activeModuleId = signal('');
  readonly activeModule = computed<MenuModule>(() =>
    this.modules().find((m) => m.id === this.activeModuleId()) ?? this.modules()[0] ?? EMPTY_MODULE);
  readonly menuLoading = signal(true);
  readonly menuError = signal<string | null>(null);

  readonly railOpen = signal(false);
  readonly mobileMenuOpen = signal(false);
  readonly searchOpen = signal(false);
  readonly moreIconsOpen = signal(false);
  readonly dropdown = signal<HeaderDropdown | null>(null);
  readonly openSub = signal<OpenSub | null>(null);

  readonly query = signal('');
  readonly highlighted = signal(-1);
  readonly suggestions = computed(() => {
    const q = this.query().trim().toLowerCase();
    if (!q) return [];
    return this.flatItems().filter((i) => i.label.toLowerCase().includes(q));
  });

  readonly roles: Role[] = ['Administrator', 'HR', 'User'];
  // TODO: replace with API data (GET /api/notifications, GET /api/tasks/summary). Sample values from header.html.
  readonly mails = [
    { title: 'Travel Expense Request', body: 'Travel Expense Request For Approval', when: 'about a year ago' },
    { title: 'Travel Expense Request', body: 'Travel Expense Request For Approval', when: 'about a year ago' },
  ];
  readonly alertItems = [
    { icon: 'ti-message-circle', label: 'AR Approval', count: 0 },
    { icon: 'ti-brand-twitter', label: 'OD Approval', count: 0 },
  ];
  readonly menuArea = viewChild<ElementRef<HTMLElement>>('menuArea');
  readonly searchInput = viewChild<ElementRef<HTMLInputElement>>('searchInput');

  private readonly flatItems = computed<MenuItem[]>(() =>
    this.modules().flatMap((m) =>
      m.items.flatMap((i) => (i.children ? i.children : [i])).filter((i) => !!i.route)));

  constructor() {
    const unload = inject(StylesheetService).load([
      'assets/css/bootstrap_6.min.css',
      'assets/tabler-icons/tabler-icons.min.css',
      'assets/css/style.css',
      'assets/css/calendar-css/calendar-style.css',
    ]);
    this.destroyRef.onDestroy(unload);

    this.privilegeService.getAll(1).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (privileges) => {
        const modules = mapPrivilegesToMenu(privileges);
        this.modules.set(modules);
        this.activeModuleId.set(modules[0]?.id ?? '');
        this.menuLoading.set(false);
      },
      error: (err: unknown) => {
        this.menuLoading.set(false);
        this.menuError.set(this.getMenuErrorMessage(err));
      },
    });
  }

  hue(index: number): string { return `hsl(${(index * 137.508) % 360}, 70%, 50%)`; }
  alertHue(index: number): string { return `hsl(${(610 + index * 137.508) % 360}, 90%, 50%)`; }

  selectModule(id: string): void { this.activeModuleId.set(id); this.openSub.set(null); }
  toggleRail(): void { this.railOpen.update((v) => !v); }
  toggleMobileMenu(): void { this.mobileMenuOpen.update((v) => !v); }
  toggleMore(): void { this.moreIconsOpen.update((v) => !v); }
  toggleDropdown(d: HeaderDropdown, ev: Event): void { ev.stopPropagation(); this.dropdown.update((c) => (c === d ? null : d)); }

  toggleSearch(): void {
    this.searchOpen.update((v) => !v);
    if (this.searchOpen()) setTimeout(() => this.searchInput()?.nativeElement.focus(), 0);
  }

  toggleSub(key: string, ev: Event): void {
    ev.stopPropagation();
    if (this.openSub()?.key === key) { this.openSub.set(null); return; }
    const rect = (ev.currentTarget as HTMLElement).getBoundingClientRect();
    this.openSub.set({ key, top: rect.bottom, left: rect.left });
  }

  scrollMenu(dir: -1 | 1): void {
    this.menuArea()?.nativeElement.scrollBy({ left: dir * 200, behavior: 'smooth' });
    this.openSub.set(null);
  }

  onSearchKey(ev: KeyboardEvent): void {
    const list = this.suggestions();
    if (!list.length) return;
    if (ev.key === 'ArrowDown') { ev.preventDefault(); this.highlighted.set((this.highlighted() + 1) % list.length); }
    else if (ev.key === 'ArrowUp') { ev.preventDefault(); this.highlighted.set((this.highlighted() - 1 + list.length) % list.length); }
    else if (ev.key === 'Enter' && this.highlighted() >= 0) { ev.preventDefault(); this.go(list[this.highlighted()]); }
    else if (ev.key === 'Escape') { this.query.set(''); }
  }

  go(item: MenuItem): void {
    if (item.route) void this.router.navigateByUrl(item.route);
    this.query.set(''); this.highlighted.set(-1); this.openSub.set(null);
  }

  private getMenuErrorMessage(err: unknown): string {
    if (err instanceof HttpErrorResponse) {
      const body = err.error;
      const apiMessage = typeof body === 'object' && body !== null
        && 'message' in body && typeof body.message === 'string'
        ? body.message
        : null;
      return apiMessage || 'Unable to load your menu. Check the API connection and try again.';
    }
    return err instanceof Error
      ? err.message
      : 'Unable to load your menu. Check the API connection and try again.';
  }

  logout(): void { this.auth.logout(); }

  @HostListener('document:click')
  closeFloating(): void { this.dropdown.set(null); this.openSub.set(null); }

  @HostListener('document:keydown', ['$event'])
  onGlobalKey(ev: KeyboardEvent): void {
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'k') {
      ev.preventDefault();
      this.searchOpen.set(true);
      setTimeout(() => this.searchInput()?.nativeElement.focus(), 0);
    }
  }
}
