import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./layouts/auth-layout/auth-layout').then((m) => m.AuthLayout),
    children: [
      { path: '', title: 'SavvyHRMS - Secure Employee Access Portal',
        loadComponent: () => import('./features/auth/login/login').then((m) => m.Login) },
    ],
  },
  {
    path: '',
    //canActivate: [authGuard],
    loadComponent: () => import('./layouts/shell-layout/shell-layout').then((m) => m.ShellLayout),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'employee-dashboard' },
      {
        path: 'employee-dashboard',
        title: 'Employee Dashboard',
        loadComponent: () => import('./features/employee-dashboard/employee-dashboard').then((m) => m.EmployeeDashboard),
      },
      {
        path: 'self-service/dependents',
        title: 'Add/Update Dependent Detail',
        loadComponent: () => import('./features/self-service/dependents/dependents').then((m) => m.Dependents),
      },
      //at this line change
          {
        path: 'self-service/advance-leave',
        title: 'Advance Leave Request',
        loadComponent: () =>
          import('./features/self-service/dependents/advance-leave/advance-leave').then((m) => m.AdvanceLeavePage),
      },
      {
        path: 'page/:module/:slug',
        loadComponent: () => import('./features/placeholder/placeholder').then((m) => m.Placeholder),
      },
      {
        path: 'home',
        loadComponent: () => import('./features/placeholder/placeholder').then((m) => m.Placeholder),
        data: { title: 'Home' },
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
