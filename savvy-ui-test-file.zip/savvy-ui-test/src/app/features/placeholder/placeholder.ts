import { Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';

/** Stand-in for HRMS screens whose designs are not in the supplied HTML folder. */
@Component({
  selector: 'savvy-placeholder',
  template: `
    <div class="main-page-content-heading d-flex align-items-center p-4 border-bottom">
      <h5 class="page-name">{{ title() }}</h5>
    </div>
    <div class="main-page-content-area p-4">
      <div class="card"><div class="card-body">This screen has not been designed or implemented yet.</div></div>
    </div>`,
})
export class Placeholder {
  private readonly route = inject(ActivatedRoute);
  private readonly params = toSignal(this.route.paramMap, { initialValue: this.route.snapshot.paramMap });
  readonly title = computed(() => {
    const slug = this.params().get('slug');
    return (this.route.snapshot.data['title'] as string | undefined) ?? (slug ? slug.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) : 'Page');
  });
}
