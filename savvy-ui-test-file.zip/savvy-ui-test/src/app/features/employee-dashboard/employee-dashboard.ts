import { Component } from '@angular/core';

@Component({
  selector: 'savvy-employee-dashboard',
  templateUrl: './employee-dashboard.html',
})
export class EmployeeDashboard {}
