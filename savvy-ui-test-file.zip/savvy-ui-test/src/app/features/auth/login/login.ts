import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../../core/auth.service';
import { OtpInput } from '../../../shared/otp-input/otp-input';

@Component({
  selector: 'savvy-login',
  imports: [ReactiveFormsModule, OtpInput],
  templateUrl: './login.html',
})
export class Login {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly year = new Date().getFullYear();
  readonly step = signal<'id' | 'password'>('id');
  readonly showPassword = signal(false);
  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);
  readonly captchaRequired = signal(false);
  readonly captchaCode = signal('');
  readonly qrOpen = signal(false);
  readonly otpOpen = signal(false);
  readonly otpError = signal<string | null>(null);
  readonly cardTop = signal<number | null>(null);

  readonly form = this.fb.nonNullable.group({
    userId: ['', [Validators.required, Validators.maxLength(50)]],
    password: ['', [Validators.required, Validators.maxLength(128)]],
    captcha: [''],
  });
  readonly otpForm = this.fb.nonNullable.group({
    otp: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]],
  });

  get userId() { return this.form.controls.userId; }
  get password() { return this.form.controls.password; }

  clearError(): void {
    this.error.set(null);
  }

  refreshCaptcha(): void {
    const randomValue = new Uint32Array(1);
    globalThis.crypto.getRandomValues(randomValue);
    this.captchaCode.set(String(100000 + (randomValue[0] % 900000)));
    this.form.controls.captcha.reset('');
    this.error.set(null);
  }

  onLogoLoad(img: HTMLImageElement): void {
    this.cardTop.set(window.innerWidth <= 700 ? img.offsetHeight : null);
  }

  changeUser(): void {
    this.step.set('id');
    this.userId.enable();
    this.form.reset();
    this.captchaRequired.set(false);
    this.captchaCode.set('');
    this.error.set(null);
  }

  continue(): void {
    this.error.set(null);
    if (this.step() === 'id') {
      this.userId.markAsTouched();
      if (!this.userId.valid) return;
      this.submitting.set(true);
      this.auth.validateUser(this.userId.value).subscribe({
        next: (result) => {
          this.submitting.set(false);
          if (!result.success) {
            this.error.set(result.message || 'User ID could not be validated.');
            return;
          }
          this.step.set('password');
          this.userId.disable();
        },
        error: (err: unknown) => {
          this.submitting.set(false);
          if (err instanceof HttpErrorResponse) {
            const body = err.error;
            const apiMessage = typeof body === 'object' && body !== null
              && 'message' in body && typeof body.message === 'string'
              ? body.message
              : null;
            this.error.set(apiMessage || 'Unable to validate User ID. Check the API connection and try again.');
            return;
          }
          this.error.set(err instanceof Error
            ? err.message
            : 'Unable to validate User ID. Check the API connection and try again.');
        },
      });
      return;
    }
    this.password.markAsTouched();
    if (this.password.invalid) return;
    this.submit();
  }

  private submit(): void {
    const { password, captcha } = this.form.getRawValue();
    if (this.captchaRequired()) {
      if (!captcha.trim()) {
        this.error.set('Enter the CAPTCHA shown above.');
        return;
      }
      if (captcha.trim() !== this.captchaCode()) {
        this.refreshCaptcha();
        this.error.set('The CAPTCHA does not match. Please try again.');
        return;
      }
    }

    this.error.set(null);
    this.submitting.set(true);
    this.auth.loginviauser({
      userName: this.userId.value,
      password,
      captchaToken: captcha.trim() || undefined,
      isCaptcha: this.captchaRequired(),
    }).subscribe({
      next: (r) => {
        this.submitting.set(false);
        if (r.code === 4) {
          this.otpError.set(null);
          this.otpOpen.set(true);
        } else if (r.code === 1 || r.status === 'Authenticated') void this.router.navigate(['/employee-dashboard']);
        else if (r.status === 'OtpRequired') {
          this.otpError.set(null);
          this.otpOpen.set(true);
        }
        else if (r.code === -11 || r.status === 'CaptchaRequired') {
          this.captchaRequired.set(true);
          this.refreshCaptcha();
          this.error.set(r.message || 'Enter the CAPTCHA shown above to continue.');
        }
      },
      error: (err: unknown) => {
        this.submitting.set(false);
        if (err instanceof HttpErrorResponse) {
          const body = err.error;
          const apiMessage = typeof body === 'object' && body !== null
            && 'message' in body && typeof body.message === 'string'
            ? body.message
            : null;
          this.error.set(apiMessage || 'Sign-in failed. Check your credentials and try again.');
          return;
        }
        this.error.set(err instanceof Error
          ? err.message
          : 'Sign-in failed. Check your credentials and try again.');
      },
    });
  }

  verifyOtp(): void {
    if (this.otpForm.invalid) { this.otpForm.markAllAsTouched(); return; }
    this.otpError.set(null);
    this.submitting.set(true);
    const { userId, password } = this.form.getRawValue();
    this.auth.loginViaTfa({
      userName: userId,
      password,
      otp: this.otpForm.getRawValue().otp,
    }).subscribe({
      next: (r) => {
        this.submitting.set(false);
        if (r.code === 1 || r.status === 'Authenticated') {
          this.otpOpen.set(false);
          void this.router.navigate(['/employee-dashboard']);
          return;
        }
        this.otpError.set(r.message || 'The verification code could not be verified. Please try again.');
      },
      error: (err: unknown) => {
        this.submitting.set(false);
        this.otpForm.controls.otp.setErrors({ invalid: true });
        this.otpError.set(err instanceof HttpErrorResponse
          ? (typeof err.error?.message === 'string' ? err.error.message : 'The verification code could not be verified. Please try again.')
          : 'Unable to verify the code. Check the API connection and try again.');
      },
    });
  }
}
