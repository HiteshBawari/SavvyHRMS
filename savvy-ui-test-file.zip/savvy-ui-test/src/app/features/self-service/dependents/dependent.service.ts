import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Dependent, DependentRelation, DependentSaveRequest } from '../../../models/dependent.model';

@Injectable({ providedIn: 'root' })
export class DependentService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}/employee-dependents`;

  list(): Observable<Dependent[]> { return this.http.get<Dependent[]>(this.url); }
  relationTypes(): Observable<DependentRelation[]> {
    return this.http.get<DependentRelation[]>(`${this.url}/relation-types`);
  }
  save(d: DependentSaveRequest): Observable<Dependent> {
    return this.http.post<Dependent>(this.url, d);
  }
  remove(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }
}
