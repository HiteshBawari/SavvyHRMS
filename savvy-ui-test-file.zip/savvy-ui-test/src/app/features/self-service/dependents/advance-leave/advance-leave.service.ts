import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, delay, of } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import {
  AdvanceLeave, AdvanceLeaveFilter, LeaveType, NewAdvanceLeave,
} from '../../../../models/advance-leave.model';

const USE_MOCK = true; // change to false when the real API is ready

@Injectable({ providedIn: 'root' })
export class AdvanceLeaveService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}/self-service/advance-leave`;

  // ----- fake data, only used while USE_MOCK is true -----
  private nextId = 1;
  private mockRows: AdvanceLeave[] = [];
  private mockTypes: LeaveType[] = [
    { id: 1, name: 'Casual Leave', eligibleDays: 5 },
    { id: 2, name: 'Earned Leave', eligibleDays: 10 },
    { id: 3, name: 'Sick Leave', eligibleDays: 7 },
  ];

  list(f: AdvanceLeaveFilter): Observable<AdvanceLeave[]> {
    if (USE_MOCK) {
      const result = this.mockRows.filter((r) =>
        (!f.fromDate || r.requestDate >= f.fromDate) &&
        (!f.toDate || r.requestDate <= f.toDate) &&
        (!f.status || r.status === f.status));
      return of(result).pipe(delay(300));
    }
    let params = new HttpParams();
    if (f.fromDate) params = params.set('fromDate', f.fromDate);
    if (f.toDate) params = params.set('toDate', f.toDate);
    if (f.status) params = params.set('status', f.status);
    return this.http.get<AdvanceLeave[]>(this.url, { params });
  }

  leaveTypes(): Observable<LeaveType[]> {
    if (USE_MOCK) return of(this.mockTypes);
    return this.http.get<LeaveType[]>(`${this.url}/leave-types`);
  }

  submit(r: NewAdvanceLeave): Observable<AdvanceLeave> {
    if (USE_MOCK) {
      const id = this.nextId++;
      const row: AdvanceLeave = {
        id,
        tokenNo: 'ADV-' + String(id).padStart(4, '0'),
        empCode: 'E001',
        employeeName: 'Devender Kumar Singh',
        leaveName: this.mockTypes.find((t) => t.id === r.leaveTypeId)?.name ?? '',
        advanceDays: r.advanceDays,
        remarks: r.remarks,
        requestDate: new Date().toISOString().slice(0, 10),
        status: 'Pending',
        actionBy: null,
        actionDate: null,
      };
      this.mockRows.push(row);
      return of(row).pipe(delay(300));
    }
    return this.http.post<AdvanceLeave>(this.url, r);
  }

  cancel(id: number): Observable<void> {
    if (USE_MOCK) {
      const row = this.mockRows.find((x) => x.id === id);
      if (row) row.status = 'Cancelled';
      return of(undefined).pipe(delay(200));
    }
    return this.http.put<void>(`${this.url}/${id}/cancel`, {});
  }
}