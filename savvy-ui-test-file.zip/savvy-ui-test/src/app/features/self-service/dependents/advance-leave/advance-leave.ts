import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, inject, signal, viewChild } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdvanceLeave, LeaveType } from '../../../../models/advance-leave.model';
import { AdvanceLeaveService } from './advance-leave.service';

@Component({
  selector: 'savvy-advance-leave',
  imports: [ReactiveFormsModule, DatePipe],
  templateUrl: './advance-leave.html',
  styleUrl: './advance-leave.css',
})
export class AdvanceLeavePage implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly api = inject(AdvanceLeaveService);
  private readonly dialog = viewChild.required<ElementRef<HTMLDialogElement>>('dlg');

  // ----- page state -----
  readonly tab = signal<'status' | 'request'>('status');
  readonly rows = signal<AdvanceLeave[]>([]);
  readonly leaveTypes = signal<LeaveType[]>([]);
  readonly selected = signal<AdvanceLeave | null>(null);
  readonly eligibleDays = signal<number | null>(null);
  readonly daysError = signal('');
  readonly loadError = signal(false);
  readonly saveError = signal(false);
  readonly searched = signal(false);

  readonly statuses = ['Draft', 'Pending', 'Approved', 'Rejected', 'Cancelled'];

  // ----- forms -----
  readonly filterForm = this.fb.nonNullable.group({
    fromDate: [''],
    toDate: [''],
    status: [''],
  });

  readonly form = this.fb.nonNullable.group({
    leaveTypeId: [null as number | null, Validators.required],
    advanceDays: [null as number | null, [Validators.required, Validators.min(1)]],
    remarks: ['', [Validators.required, Validators.maxLength(250)]],
  });

  ngOnInit(): void {
    this.search();
    this.api.leaveTypes().subscribe({ next: (t) => this.leaveTypes.set(t) });
  }

  // ----- Status tab -----
  search(): void {
    this.api.list(this.filterForm.getRawValue()).subscribe({
      next: (data) => { this.rows.set(data); this.loadError.set(false); this.searched.set(true); },
      error: () => { this.loadError.set(true); this.searched.set(true); },
    });
  }

  statusClass(s: string): string {
    return 'adv-badge adv-' + s.toLowerCase();
  }

  cancelRequest(r: AdvanceLeave): void {
    if (!confirm(`Cancel request ${r.tokenNo}?`)) return;
    this.api.cancel(r.id).subscribe({ next: () => this.search() });
  }

  openDetail(r: AdvanceLeave): void {
    this.selected.set(r);
    this.dialog().nativeElement.showModal();
  }

  closeDetail(): void {
    this.dialog().nativeElement.close();
  }

  // ----- Request tab -----
  onLeaveChange(): void {
    const id = Number(this.form.controls.leaveTypeId.value);
    const leave = this.leaveTypes().find((l) => l.id === id);
    this.eligibleDays.set(leave ? leave.eligibleDays : null);
    this.daysError.set('');
  }

  submit(): void {
    this.daysError.set('');
    this.saveError.set(false);

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const v = this.form.getRawValue();
    const max = this.eligibleDays();
    if (max !== null && v.advanceDays! > max) {
      this.daysError.set(`You can request at most ${max} day(s) for this leave.`);
      return;
    }

    this.api.submit({
      leaveTypeId: Number(v.leaveTypeId),
      advanceDays: Number(v.advanceDays),
      remarks: v.remarks.trim(),
    }).subscribe({
      next: () => { this.resetForm(); this.tab.set('status'); this.search(); },
      error: () => this.saveError.set(true), // server-side validation remains authoritative
    });
  }

  resetForm(): void {
    this.form.reset({ leaveTypeId: null, advanceDays: null, remarks: '' });
    this.eligibleDays.set(null);
    this.daysError.set('');
    this.saveError.set(false);
  }
}