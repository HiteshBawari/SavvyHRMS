import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Dependent, DependentRelation, DependentSaveRequest } from '../../../models/dependent.model';
import { DependentService } from './dependent.service';

interface DependentForm {
  id?: number;
  name: string;
  dob: string;
  relationTypeId: number | null;
  age: number | null;
  cardNo: string;
  amount: number | null;
}

@Component({
  selector: 'savvy-dependents',
  imports: [DatePipe, FormsModule, RouterLink],
  templateUrl: './dependents.html',
  styleUrl: './dependents.css',
})
export class Dependents implements OnInit {
  private readonly api = inject(DependentService);

  readonly dependents = signal<Dependent[]>([]);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly showForm = signal(false);
  readonly formError = signal<string | null>(null);
  readonly saving = signal(false);
  readonly toDelete = signal<Dependent | null>(null);
  readonly deleting = signal(false);
  readonly today = this.localDateString(new Date());
  readonly relations = signal<DependentRelation[]>([]);
  readonly form = this.emptyForm();
  readonly formTitle = () => this.form.id !== undefined ? 'Update Dependent Details' : 'Add Dependent Details';

  ngOnInit(): void {
    this.load();
    this.loadRelations();
  }

  openAdd(): void {
    this.form.id = undefined;
    this.form.name = '';
    this.form.dob = '';
    this.form.relationTypeId = null;
    this.form.age = null;
    this.form.cardNo = '';
    this.form.amount = null;
    this.formError.set(null);
    this.showForm.set(true);
  }

  openEdit(dependent: Dependent): void {
    this.form.id = dependent.EMPLOYEE_DEPENDENT_ID;
    this.form.name = dependent.DEPENDENT_NAME;
    this.form.dob = this.toDateInput(dependent.DATE_OF_BIRTH);
    this.form.relationTypeId = this.relations().find(
      (relation) => relation.EMPLOYEE_RELATION_TYPE.toLowerCase() === dependent.RELATION.toLowerCase(),
    )?.ID ?? null;
    this.form.age = dependent.AGE;
    this.form.cardNo = dependent.INSURANCE_CARD_NO;
    this.form.amount = dependent.INSURANCE_AMOUNT;
    this.formError.set(null);
    this.showForm.set(true);
  }

  save(): void {
    if (!this.form.name.trim()) {
      this.formError.set('Dependent name is required.');
      return;
    }
    if (this.form.age !== null && (this.form.age < 0 || this.form.age > 120)) {
      this.formError.set('Age must be between 0 and 120.');
      return;
    }
    if (this.form.amount !== null && this.form.amount < 0) {
      this.formError.set('Insurance amount cannot be negative.');
      return;
    }

    const relation = this.relations().find((item) => item.ID === this.form.relationTypeId);
    const dob = this.form.dob ? new Date(`${this.form.dob}T00:00:00`).toISOString() : null;
    const dependent: DependentSaveRequest = {
      employeE_DEPENDENT_ID: this.form.id ?? 0,
      dependenT_NAME: this.form.name.trim(),
      datE_OF_BIRTH: dob,
      datE_OF_BIRTH_1: this.form.dob,
      age: this.form.age ?? 0,
      relation: relation?.EMPLOYEE_RELATION_TYPE ?? '',
      relationTypeId: relation?.ID ?? 0,
      relationName: relation?.EMPLOYEE_RELATION_TYPE ?? '',
      insurancE_CARD_NO: this.form.cardNo.trim(),
      insurancE_AMOUNT: this.form.amount ?? 0,
    };

    this.saving.set(true);
    this.formError.set(null);
    this.api.save(dependent).subscribe({
      next: () => {
        this.saving.set(false);
        this.showForm.set(false);
        this.load();
      },
      error: (err: unknown) => {
        this.saving.set(false);
        this.formError.set(this.getErrorMessage(err, 'Could not save dependent details. Please try again.'));
      },
    });
  }

  confirmDelete(dependent: Dependent): void {
    this.toDelete.set(dependent);
  }

  remove(): void {
    const dependent = this.toDelete();
    if (!dependent) {
      this.error.set('Select a dependent to remove.');
      this.toDelete.set(null);
      return;
    }

    this.deleting.set(true);
    this.api.remove(dependent.EMPLOYEE_DEPENDENT_ID).subscribe({
      next: () => {
        this.deleting.set(false);
        this.toDelete.set(null);
        this.load();
      },
      error: (err: unknown) => {
        this.deleting.set(false);
        this.error.set(this.getErrorMessage(err, 'Could not remove dependent details. Please try again.'));
        this.toDelete.set(null);
      },
    });
  }

  relationName(dependent: Dependent): string {
    return dependent.RELATION;
  }

  private load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.list().subscribe({
      next: (rows) => {
        this.dependents.set(rows);
        this.loading.set(false);
      },
      error: (err: unknown) => {
        this.loading.set(false);
        this.error.set(this.getErrorMessage(err, 'Dependents could not be loaded. Please try again.'));
      },
    });
  }

  private loadRelations(): void {
    this.api.relationTypes().subscribe({
      next: (relations) => this.relations.set(relations),
      error: (err: unknown) => this.error.set(this.getErrorMessage(err, 'Dependent relation types could not be loaded.')),
    });
  }

  private emptyForm(): DependentForm {
    return { name: '', dob: '', relationTypeId: null, age: null, cardNo: '', amount: null };
  }

  private toDateInput(value: string | null): string {
    if (!value) return '';
    const match = /^(\d{4}-\d{2}-\d{2})/.exec(value);
    return match?.[1] ?? '';
  }

  private localDateString(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private getErrorMessage(err: unknown, fallback: string): string {
    if (err instanceof HttpErrorResponse) {
      const body = err.error;
      const message = typeof body === 'object' && body !== null
        && 'message' in body && typeof body.message === 'string'
        ? body.message
        : null;
      return message || fallback;
    }
    return err instanceof Error ? err.message : fallback;
  }
}
