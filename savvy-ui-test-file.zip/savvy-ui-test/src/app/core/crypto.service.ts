import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CryptoService {
  private key = CryptoJS.enc.Utf8.parse(environment.encKey);
  private iv = CryptoJS.enc.Utf8.parse(environment.encIv);

  encrypt(text: string): string {
    return CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(text), this.key, {
      iv: this.iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7
    }).toString();
  }
}
