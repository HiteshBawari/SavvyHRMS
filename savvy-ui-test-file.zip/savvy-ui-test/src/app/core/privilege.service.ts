import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Privilege } from '../models/menu.model';

@Injectable({ providedIn: 'root' })
export class PrivilegeService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}/Privilege/getAllPrivilegeData`;

  getAll(roleID: number): Observable<Privilege[]> {
    return this.http.post<Privilege[]>(this.url, { roleID, searchText: '' }, {
      headers: { Accept: '*/*' },
    });
  }
}
