import { DOCUMENT } from '@angular/common';
import { Injectable, inject } from '@angular/core';

/** Loads/unloads same-origin stylesheets per layout so Bootstrap 5 (login) and Bootstrap 6 alpha (shell) never clash. */
@Injectable({ providedIn: 'root' })
export class StylesheetService {
  private readonly doc = inject(DOCUMENT);

  load(hrefs: string[]): () => void {
    const links = hrefs.map((href) => {
      const link = this.doc.createElement('link');
      link.rel = 'stylesheet';
      link.href = href;
      this.doc.head.appendChild(link);
      return link;
    });
    return () => links.forEach((l) => l.remove());
  }
}
