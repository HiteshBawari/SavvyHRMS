import { MenuModule, Privilege } from '../models/menu.model';

const slugify = (value: string): string =>
  value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'page';

const iconClass = (markup: string | null | undefined): string => {
  const classes = markup?.match(/class\s*=\s*["']([^"']*)["']/i)?.[1].split(/\s+/) ?? [];
  return classes.find((name) => /^ti-[a-z0-9-]+$/.test(name)) ?? 'ti-layout-grid';
};

export function mapPrivilegesToMenu(privileges: Privilege[]): MenuModule[] {
  const modules = new Map<string, { displayOrder: number; index: number; menu: MenuModule }>();

  privileges.forEach((privilege, index) => {
    const moduleName = privilege.MM_MODULE_MAME?.trim();
    const label = privilege.PM_PRIVILEGE_NAME?.trim();
    if (!moduleName || !label) return;

    const moduleId = slugify(moduleName);
    let entry = modules.get(moduleId);
    if (!entry) {
      entry = {
        displayOrder: Number.isFinite(privilege.DISPLAY_ORDER) ? privilege.DISPLAY_ORDER : Number.MAX_SAFE_INTEGER,
        index,
        menu: { id: moduleId, label: moduleName, icon: iconClass(privilege.PM_ICON), items: [] },
      };
      modules.set(moduleId, entry);
    }

    entry.menu.items.push({
      label,
      route: `/SavvyHRMS/${moduleId}/${slugify(label)}`,
    });
  });

  return [...modules.values()]
    .sort((a, b) => a.displayOrder - b.displayOrder || a.index - b.index)
    .map(({ menu }) => menu);
}
