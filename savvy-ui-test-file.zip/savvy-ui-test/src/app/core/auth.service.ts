import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, defer, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest, LoginResponse, Role, TfaLoginRequest, UserSession, ValidateUserResponse } from '../models/auth.model';
import { CryptoService } from './crypto.service';

/**
 * Access token is kept in memory only (never localStorage) to limit XSS exposure.
 * The API is expected to keep the refresh token in an HttpOnly, Secure, SameSite cookie.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly crypto = inject(CryptoService);
  private readonly base = `${environment.apiBaseUrl}/auth`;

  private readonly _token = signal<string | null>(null);
  private readonly _user = signal<UserSession | null>(null);

  readonly user = this._user.asReadonly();
  readonly isAuthenticated = computed(() => this._token() !== null);
  get token(): string | null { return this._token(); }
 
  validateUser(userName: string): Observable<ValidateUserResponse> {
    return defer(() => this.http.post<ValidateUserResponse>(`${environment.apiBaseUrl}/Auth/validateuser`, {
      userName: this.crypto.encrypt(userName),
    }, {
      headers: { Accept: '*/*', 'X-Security-Key': environment.API_SECURITY_KEY },
    }));
  }
  
  loginviauser(req: LoginRequest): Observable<LoginResponse> {
    const encryptedRequest = {
      userName: this.crypto.encrypt(req.userName),
      password: this.crypto.encrypt(req.password),
      captchaToken: req.captchaToken,
      IsCaptcha: req.isCaptcha,
    };
    return this.http.post<LoginResponse>(`${this.base}/loginviauser`, encryptedRequest, {
      headers: { Accept: '*/*', 'X-Security-Key': environment.API_SECURITY_KEY },
      withCredentials: true,
    })
      .pipe(tap((r) => this.accept(r)));
  }
  loginViaTfa(req: TfaLoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${environment.apiBaseUrl}/Auth/loginviatfa`, {
      UserName: this.crypto.encrypt(req.userName),
      Password: this.crypto.encrypt(req.password),
      otp: req.otp,
    }, {
      headers: { Accept: '*/*', 'X-Security-Key': environment.API_SECURITY_KEY },
      withCredentials: true,
    })
      .pipe(tap((r) => this.accept(r)));
  }

  /** Restores the session from the refresh cookie on page reload. */
  refresh(): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.base}/refresh`, {}, { withCredentials: true })
      .pipe(tap((r) => this.accept(r)));
  }

  switchRole(role: Role): void {
    const u = this._user();
    if (u && u.roles.includes(role)) this._user.set({ ...u, activeRole: role });
  }

  logout(): void {
    this.http.post(`${this.base}/logout`, {}, { withCredentials: true }).subscribe({ error: () => undefined });
    this._token.set(null);
    this._user.set(null);
    void this.router.navigate(['/login']);
  }

  private accept(r: LoginResponse): void {
    const token = r.accessToken ?? (r.code === 1 ? r.token : null);
    if (!token) return;
    this._token.set(token);
    this._user.set(r.user ?? null);
  }
}
