import { Component, Directive, TemplateRef, contentChildren, inject, input, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';

/** Usage: <ng-template savvyTab label="Overview">…content…</ng-template>. Replaces HTML-string tab content from the prototype. */
@Directive({ selector: 'ng-template[savvyTab]' })
export class TabPanel {
  readonly label = input.required<string>();
  readonly template = inject(TemplateRef);
}

@Component({
  selector: 'savvy-tabs',
  imports: [NgTemplateOutlet],
  template: `
    <div [class.d-flex]="orientation() === 'vertical'" [class.gap-3]="orientation() === 'vertical'">
      <div role="tablist" class="nav" [class.nav-tabs]="orientation() === 'horizontal'" [class.flex-column]="orientation() === 'vertical'"
           [attr.aria-orientation]="orientation()">
        @for (t of panels(); track t.label(); let i = $index) {
          <button type="button" role="tab" class="nav-link" [class.active]="i === active()" [attr.aria-selected]="i === active()"
                  (click)="active.set(i)">{{ t.label() }}</button>
        }
      </div>
      <div role="tabpanel" class="p-3 flex-grow-1">
        @if (panels()[active()]; as p) { <ng-container [ngTemplateOutlet]="p.template" /> }
      </div>
    </div>`,
})
export class Tabs {
  readonly orientation = input<'horizontal' | 'vertical'>('horizontal');
  readonly panels = contentChildren(TabPanel);
  readonly active = signal(0);
}
