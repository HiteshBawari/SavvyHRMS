import { Component, computed, input, signal } from '@angular/core';

export interface GridColumn<T> { key: keyof T & string; label: string; filterable?: boolean; sortable?: boolean; }

/** Port of the jQuery grid prototype: live search, per-column filters, sorting, page size and pagination.
 *  All values render through Angular interpolation (auto-escaped). Client-side only; add server paging when the API exists. */
@Component({
  selector: 'savvy-data-grid',
  template: `
    <div class="d-flex flex-wrap gap-2 mb-3 align-items-center">
      <input type="search" class="form-control form-control-sm" style="width: 220px" placeholder="Search records..."
             aria-label="Search records" [value]="search()" (input)="setSearch($any($event.target).value)">
      @for (c of columns(); track c.key) {
        @if (c.filterable) {
          <select class="form-select form-select-sm" style="width: 150px" [attr.aria-label]="'Filter ' + c.label"
                  (change)="setFilter(c.key, $any($event.target).value)">
            <option value="">All {{ c.label }}</option>
            @for (v of uniqueValues(c.key); track v) { <option [value]="v">{{ v }}</option> }
          </select>
        }
      }
      <select class="form-select form-select-sm ms-auto" style="width: 75px" aria-label="Rows per page"
              (change)="setPageSize(+$any($event.target).value)">
        @for (n of pageSizes; track n) { <option [value]="n" [selected]="n === pageSize()">{{ n }}</option> }
      </select>
    </div>
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle mb-0">
        <thead>
          <tr>
            @for (c of columns(); track c.key) {
              <th scope="col" [style.cursor]="c.sortable === false ? null : 'pointer'" (click)="c.sortable === false || sortBy(c.key)">
                {{ c.label }} @if (sortKey() === c.key) { <span aria-hidden="true">{{ sortDir() === 'asc' ? '▲' : '▼' }}</span> }
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @for (r of pageRows(); track $index) {
            <tr>@for (c of columns(); track c.key) { <td>{{ r[c.key] }}</td> }</tr>
          } @empty {
            <tr><td [attr.colspan]="columns().length" class="text-center text-muted py-4">No records found.</td></tr>
          }
        </tbody>
      </table>
    </div>
    <nav class="d-flex justify-content-between align-items-center mt-3" aria-label="Pagination">
      <small class="text-muted">{{ filtered().length }} record(s)</small>
      <ul class="pagination pagination-sm mb-0">
        <li class="page-item" [class.disabled]="page() === 1"><button type="button" class="page-link" (click)="go(page() - 1)">Previous</button></li>
        @for (p of pages(); track p) {
          <li class="page-item" [class.active]="p === page()"><button type="button" class="page-link" (click)="go(p)">{{ p }}</button></li>
        }
        <li class="page-item" [class.disabled]="page() === totalPages()"><button type="button" class="page-link" (click)="go(page() + 1)">Next</button></li>
      </ul>
    </nav>`,
})
export class DataGrid<T extends Record<string, string | number>> {
  readonly columns = input.required<GridColumn<T>[]>();
  readonly rows = input.required<T[]>();
  readonly pageSizes = [5, 10, 25, 50];

  readonly search = signal('');
  readonly filters = signal<Record<string, string>>({});
  readonly sortKey = signal<string | null>(null);
  readonly sortDir = signal<'asc' | 'desc'>('asc');
  readonly page = signal(1);
  readonly pageSize = signal(10);

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    const f = this.filters();
    let out = this.rows().filter((r) =>
      (!q || Object.values(r).some((v) => String(v).toLowerCase().includes(q))) &&
      Object.entries(f).every(([k, v]) => !v || String(r[k]) === v));
    const key = this.sortKey();
    if (key) {
      const dir = this.sortDir() === 'asc' ? 1 : -1;
      out = [...out].sort((a, b) => (a[key] > b[key] ? 1 : a[key] < b[key] ? -1 : 0) * dir);
    }
    return out;
  });
  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.filtered().length / this.pageSize())));
  readonly pageRows = computed(() => this.filtered().slice((this.page() - 1) * this.pageSize(), this.page() * this.pageSize()));
  readonly pages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  uniqueValues(key: string): string[] { return [...new Set(this.rows().map((r) => String(r[key])))].sort(); }
  setSearch(v: string): void { this.search.set(v); this.page.set(1); }
  setFilter(key: string, v: string): void { this.filters.update((f) => ({ ...f, [key]: v })); this.page.set(1); }
  setPageSize(n: number): void { this.pageSize.set(n); this.page.set(1); }
  sortBy(key: string): void {
    if (this.sortKey() === key) this.sortDir.update((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { this.sortKey.set(key); this.sortDir.set('asc'); }
  }
  go(p: number): void { this.page.set(Math.min(Math.max(1, p), this.totalPages())); }
}
