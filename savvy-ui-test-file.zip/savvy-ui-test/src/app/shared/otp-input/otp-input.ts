import { Component, forwardRef, signal } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

/** Six-box numeric OTP field backed by one real input (keeps autofill / paste / accessibility working). */
@Component({
  selector: 'savvy-otp-input',
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => OtpInput), multi: true }],
  template: `
    <div class="otp-wrapper">
      <input #field type="text" maxlength="6" inputmode="numeric" autocomplete="one-time-code" aria-label="6-digit code"
             [value]="value()" (input)="onInput($any($event.target))" (blur)="onTouched()" [disabled]="disabled()">
      <div class="otp-boxes" (click)="field.focus()">
        @for (i of slots; track i) {
             <span [class.filled]="i < value().length"
      [class.active]="i === value().length && value().length < 6">{{ value().charAt(i) }}</span>
        }
      </div>
    </div>`,
})
export class OtpInput implements ControlValueAccessor {
  readonly slots = [0, 1, 2, 3, 4, 5];
  readonly value = signal('');
  readonly disabled = signal(false);
  private onChange: (v: string) => void = () => undefined;
  onTouched: () => void = () => undefined;

  onInput(el: HTMLInputElement): void {
    const v = el.value.replace(/\D/g, '').slice(0, 6);
    el.value = v;
    this.value.set(v);
    this.onChange(v);
  }
  writeValue(v: string | null): void { this.value.set((v ?? '').replace(/\D/g, '').slice(0, 6)); }
  registerOnChange(fn: (v: string) => void): void { this.onChange = fn; }
  registerOnTouched(fn: () => void): void { this.onTouched = fn; }
  setDisabledState(d: boolean): void { this.disabled.set(d); }
}
