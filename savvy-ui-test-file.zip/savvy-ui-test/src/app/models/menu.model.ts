// export interface MenuItem {
//   label: string;
//   /** Router link; items without one open the placeholder page. */
//   route?: string;
//   children?: MenuItem[];
// }
// export interface MenuModule {
//   id: string;
//   label: string;
//   sublabel?: string;
//   icon: string;
//   items: MenuItem[];
// }

// export interface Privilege {
//   MM_MODULE_MAME: string;
//   DISPLAY_ORDER: number;
//   PM_PRIVILEGE_NAME: string;
//   PM_PATH: string;
//   PM_ICON: string;
// }

export interface MenuItem {
  label: string;
  /** Router link; items without one open the placeholder page. */
  route?: string;
  children?: MenuItem[];
}
export interface MenuModule {
  id: string;
  label: string;
  sublabel?: string;
  icon: string;
  items: MenuItem[];
}
