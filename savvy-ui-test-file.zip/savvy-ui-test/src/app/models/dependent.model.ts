export interface Dependent {
  EMPLOYEE_DEPENDENT_ID: number;
  EMPLOYEE_ID: number;
  DEPENDENT_NAME: string;
  AGE: number | null;
  DATE_OF_BIRTH: string | null;
  DATE_OF_BIRTH_1: string;
  RELATION: string;
  INSURANCE_CARD_NO: string;
  INSURANCE_AMOUNT: number;
  STATUS: boolean;
  CREATED_BY: number;
  CREATED_DATE: string;
  MODIFIED_BY: number | null;
  MODIFIED_DATE: string | null;
}

export interface DependentSaveRequest {
  employeE_DEPENDENT_ID: number;
  dependenT_NAME: string;
  datE_OF_BIRTH: string | null;
  datE_OF_BIRTH_1: string;
  age: number;
  relation: string;
  relationTypeId: number;
  relationName: string;
  insurancE_CARD_NO: string;
  insurancE_AMOUNT: number;
}

export interface DependentRelation {
  ID: number;
  EMPLOYEE_RELATION_TYPE: string;
}
