// export type Role = 'Administrator' | 'HR' | 'User';

// export interface UserSession {
//   userId: string;
//   displayName: string;
//   roles: Role[];
//   activeRole: Role;
// }

// /** Server decides whether another step is required; the client never infers it from the user id. */
// export interface LoginRequest { userName: string; password: string; captchaToken?: string; isCaptcha: boolean; }
// export interface LoginResponse {
//   status?: 'Authenticated' | 'OtpRequired' | 'CaptchaRequired';
//   code?: number;
//   message?: string;
//   token?: string | null;
//   expiresAtUtc?: string | null;
//   accessToken?: string;
//   user?: UserSession;
//   challengeId?: string;
// }
// export interface TfaLoginRequest { userName: string; password: string; otp: string; }
// export interface ValidateUserResponse { code: number; success: boolean; message: string; }

export type Role = 'Administrator' | 'HR' | 'User';

export interface UserSession {
  userId: string;
  displayName: string;
  roles: Role[];
  activeRole: Role;
}

/** Server decides whether another step is required; the client never infers it from the user id. */
export interface LoginRequest { userName: string; password: string; captchaToken?: string; }
export interface LoginResponse {
  status?: 'Authenticated' | 'OtpRequired' | 'CaptchaRequired';
  code?: number;
  message?: string;
  token?: string | null;
  expiresAtUtc?: string | null;
  accessToken?: string;
  user?: UserSession;
  challengeId?: string;
}
export interface OtpVerifyRequest { challengeId: string; otp: string; } //only this line changed security guard 
export interface ValidateUserResponse { code: number; success: boolean; message: string; }
