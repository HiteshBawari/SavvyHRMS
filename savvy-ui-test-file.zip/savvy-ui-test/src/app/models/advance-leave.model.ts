export interface LeaveType {
  id: number;
  name: string;
  eligibleDays: number;
}

export interface AdvanceLeave {
  id: number;
  tokenNo: string;
  empCode: string;
  employeeName: string;
  leaveName: string;
  advanceDays: number;
  remarks: string;
  requestDate: string;
  status: string;
  actionBy: string | null;
  actionDate: string | null;
}

export interface AdvanceLeaveFilter {
  fromDate: string;
  toDate: string;
  status: string;
}

export interface NewAdvanceLeave {
  leaveTypeId: number;
  advanceDays: number;
  remarks: string;
}