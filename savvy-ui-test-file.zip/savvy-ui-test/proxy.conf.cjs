module.exports = {
  "/api": { "target": "https://localhost:7100", "secure": false, "changeOrigin": true }
}
