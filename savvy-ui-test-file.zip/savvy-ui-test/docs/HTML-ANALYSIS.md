# SavvyHRMS – Analysis of the Existing HTML Project

Source: `Latest_HRMS_project.zip` (100 files, ~27.5 MB unpacked). The original was **not modified**; a scratch copy was extracted for reading.

## 1. Inventory

| Area | Files |
|---|---|
| Pages (5) | `login2.html`, `header.html`, `texting code/table.html`, `texting code/table2.html`, `texting code/tabs.html` |
| Own CSS | `css/style.css` (16 KB, app shell/header/menu), `css/calendar-css/calendar-style.css` (Air Datepicker theme), inline `<style>` in `login2.html` (~600 lines) |
| Vendor CSS | `css/bootstrap_5.min.css` (v5.3.3), `css/bootstrap_6.min.css` (**v6.0.0-alpha.1**), `tabler-icons/tabler-icons.min.css` |
| Own JS | `js/javascript.js` (jQuery: menu, search, theme toggle), inline scripts in `login2.html` and `header.html` |
| Vendor JS | `jquery-4.0.0.min.js`, `bootstrap_5.min.js`, `bootstrap_6.min.js`, Air Datepicker 3.6.0 (CDN) |
| Fonts | Open Sans + Roboto variable TTFs (`fonts/`), 54 loose TTFs in `fonts/`, `Opensans/*.woff2` (3), Tabler icon font (woff/woff2) |
| Images | `ORA-new.png` (logo), `logo.jpeg`, `icon-log.png`, `qr-img.png`, `background.jpg` (3 MB), `background1.jpg` (1.9 MB), `test.gif` (**7 MB**) |

Note: `header.html` is not a fragment; it is the whole application shell *plus* one sample page ("Add/Update Dependent Detail"). The folder named `texting code` contains experiments/prototypes of a reusable data grid and tabs component, not product pages.

## 2. Page-by-page

### 2.1 `login2.html` – Secure Employee Access Portal
- Two-column layout: marketing banner (left, desktop only) and sign-in card (right); animated GIF logo block on mobile.
- Two-step sign-in: User ID → "Continue" reveals password → "Sign In". "Change" link resets.
- Password show/hide toggle; "Forgot Password?" (dead link); Google and QR-link sign-in buttons.
- **QR modal** (static backdrop): 3-step pairing guide + QR image.
- **2FA OTP modal**: 6-digit input rendered as six boxes, numeric filtering, regex validation.
- **CAPTCHA** block (hidden): 6-digit random number, refresh, verify.
- Footer: powered-by logo, copyright year, cookie/terms/privacy links.
- Breakpoints: 992 / 768 / 500 px. Uses Bootstrap 5.3.3.

### 2.2 `header.html` – Application shell
- **App switcher** (grid-dots button) opening a left rail "Your Apps": Home, Self-Service, Recruitment, Payroll, Workforce, Expense, Expense Claims (7 module groups).
- **Horizontal mega-menu** per module (`data-menu`), with scroll arrows, dropdown sub-menus (hover/click, delayed close, repositioned on scroll). Self-Service lists 14 real items (Dependent Detail, C-Off, Attendance Calendar, Leave Application, My Holiday, Salary Slip, OD, Profile, Punch Regularization, Resignation, Shift Change, Policy download, Birthday message, C-Off request). Other modules contain placeholder text ("Employee 1", "Recruitment" ×10).
- **Header tools**: global search (Ctrl+K hint, live suggestions from menu links, arrow-key navigation), role switcher (Administrator / HR / User), email notifications, task/alert counters, settings menu (Profile, Account, User Admin, System, Sys Admin Backroom), AI sparkle button, logout, mobile "more" toggle.
- **Sample page**: breadcrumb heading, card with "Add Dependent" button opening a `<dialog>` form (name, date via Air Datepicker, select).
- Theme toggle code exists (`data-bs-theme` light/dark) but is wired to `.header-logout-area1`, which does not exist in markup (dead code).
- Per-icon random hue colouring via JS (`hsl(index*137.5)`).

### 2.3 `texting code/table.html` and `table2.html` – Data grid prototypes
Reusable grid (jQuery plugin style): global live search, per-column dropdown filters, sortable headers, page-size selector, numbered pagination, empty state; `setData()`, `refresh()`, `destroy()` demo buttons and a toast alert. Three/two sample grids (products, employees, orders; inventory, personnel) with hard-coded data. Load Bootstrap 5.3.8, Font Awesome 6.4, Google Fonts and jQuery from public CDNs.

### 2.4 `texting code/tabs.html` – Tabs prototype
Config-driven tabs: horizontal (scrollable with left/right arrows) and vertical variants, three instances, tab content supplied as HTML strings. Bootstrap 6 alpha CSS.

## 3. Reusable UI elements
App shell (rail + header + mega-menu), menu dropdowns, search with suggestions, header dropdown "menus" (role/mail/alerts/settings), breadcrumb heading, card with heading + action button, slide-down dialog, form field (label + control + adornment icon), datepicker, OTP input, password input with toggle, data grid, tabs, pagination, toast alert.

## 4. Behaviours and validations
- **Validation:** only HTML `required` and a client-side 6-digit OTP regex. Required-field marking by CSS class only. No real validation messages.
- **Pagination / sorting / filtering:** only in the grid prototypes (in-memory).
- **Responsive:** `d-none-sm` / `d-block-sm` utilities, 992 px collapses menu and header icons; login card repositions via JS on ≤700 px.

## 5. Dependencies
| Library | Version | Notes |
|---|---|---|
| Bootstrap CSS/JS (two copies) | 5.3.3 and **6.0.0-alpha.1** | Alpha release; API still changing. Login uses 5, app shell uses 6 (`menu`, `dialog` components), prototypes mix 5.3.8 CDN and 6. Not compatible with ng-bootstrap/ngx-bootstrap. |
| jQuery | 4.0.0 | Very new major version; all UI behaviour depends on it. |
| Tabler Icons | local webfont | Keep (self-hosted). |
| Air Datepicker | 3.6.0 | Loaded from jsDelivr CDN, no SRI. |
| Font Awesome 6.4, Google Fonts (Inter), Bootstrap 5.3.8 CDN | – | Only in `texting code` prototypes. |

## 6. Security findings
| # | Severity | Finding | Where | Angular treatment |
|---|---|---|---|---|
| 1 | **High** | Authentication/role decisions hard-coded in the browser: `user_id == "admin"` shows CAPTCHA, `"superadmin"` shows OTP modal. | `login2.html` inline script | Remove. Server decides step-up (CAPTCHA/2FA) from the API response. |
| 2 | **High** | CAPTCHA generated with `Math.random()` and verified client-side (trivially bypassable). | `login2.html` | Replace with server-issued challenge / provider (e.g. reCAPTCHA/hCaptcha or backend-validated). |
| 3 | Medium | Template-string HTML injection (`html += ...${state.searchTerm}`, `${val}`, `${col.label}` into `.html()`), unescaped. | `table.html`, `table2.html` | Angular interpolation auto-escapes; no `innerHTML`. |
| 4 | Medium | Tab content stored as HTML strings and injected via `.html()`. | `tabs.html` | Use `ng-template`/content projection. |
| 5 | Medium | Many inline `<script>` blocks and inline `onclick=` handlers → incompatible with a strict CSP. | login, header, table.html | Move to components; no inline script. |
| 6 | Medium | Third-party scripts/styles from CDNs without Subresource Integrity (Air Datepicker, jQuery 3.7.1, Bootstrap, Font Awesome). | header, table pages | Self-host via npm; pin versions. |
| 7 | Medium | Alpha Bootstrap 6 and brand-new jQuery 4.0.0 in production UI. | all app pages | Do not ship alpha; see §7. |
| 8 | Low | External links with `target="_blank"` and no `rel="noopener noreferrer"`. | login footer | Add `rel`. |
| 9 | Low | Form has no `autocomplete` attributes for username/password; password field `name`/`id` only. | login | Add `autocomplete="username"` / `current-password`. |
| 10 | Low | `alert()` used for validation feedback; `console.log` of selected values. | login, datepicker | Replace with inline messages. |
| 11 | Info | No credentials, API keys or tokens were found in the HTML/JS. The only "secrets" are the demo user ids above. | – | – |
| 12 | Info | Placeholder sample data in notification menu (names, dates) is demo only. | header | Replace with API data. |

Inline `style="..."` attributes (≈40 in header/login) also need `style-src 'unsafe-inline'` unless moved into CSS classes.

## 7. Proposed Angular architecture (decision summary)
- **Shell** (`LayoutComponent`): rail, header, mega-menu, search, breadcrumb → one shared layout wrapping all authenticated routes.
- **Auth layout**: login page + modals (QR, OTP) → separate public route.
- **Shared components:** `MenuBar`, `AppRail`, `GlobalSearch`, `HeaderMenu` (dropdown), `Dialog`, `DataGrid`, `Tabs`, `OtpInput`, `PasswordField`, `DatePicker`, `Breadcrumb`, `PageCard`.
- **Bootstrap decision (needs your confirmation):** the shell CSS depends on Bootstrap **6 alpha** classes (`menu`, `dialog`, `btn-solid`, `g-col-*`, `theme-primary`). Two options: (a) keep the supplied `bootstrap_6.min.css` as a static, self-hosted stylesheet and re-implement the JS behaviours (menus, dialogs) as native Angular/CDK components, or (b) port to stable Bootstrap 5.3. Option (a) preserves the look most exactly and is what I would recommend; the CSS-only part is safe to keep, the alpha JS is not.
- **Date picker:** Angular CDK overlay + a native-styled calendar, or a maintained Angular date component; reuse the existing calendar CSS theme.
- **Icons/fonts:** keep Tabler icon font and Open Sans/Roboto, referenced from `public/` assets.
- **Large images:** `test.gif` (7 MB) and the two background JPGs (3 MB, 1.9 MB) should be optimised (WebM/WebP) before shipping; flagged, not changed.

## 8. Gaps the HTML does not answer
Only one real HRMS screen exists (Dependent Detail, empty). All other menu items are placeholder links (`href="#"`); their screens, fields and workflows are not present in the attachment, so they cannot be converted without the missing designs.
