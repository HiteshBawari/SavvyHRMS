# HTML → Angular mapping (proposed; status = NOT yet implemented)

| Original file | Angular route | Component(s) | Notes / backend needs |
|---|---|---|---|
| `login2.html` | `/login` (auth layout) | `LoginPageComponent`, `QrLinkDialogComponent`, `OtpDialogComponent`, `OtpInputComponent`, `PasswordFieldComponent` | Needs API: login, OTP verify, CAPTCHA challenge, QR pairing, Google SSO. Remove client-side role logic. |
| `header.html` – shell | all authenticated routes under `LayoutComponent` | `AppRailComponent`, `MenuBarComponent`, `GlobalSearchComponent`, `HeaderToolbarComponent`, `HeaderMenuComponent`, `BreadcrumbComponent` | Menu structure and role list must come from API (permissions-driven). |
| `header.html` – sample page | `/self-service/dependents` (lazy) | `DependentListPageComponent`, `DependentDialogComponent` (reactive form) | Dependent CRUD API; relationship lookup. |
| `header.html` menu links (Self-Service, 14 items) | `/self-service/*` (lazy routes) | placeholder `ComingSoonPageComponent` | **Screens not in attachment.** |
| `header.html` menus: Home, Recruitment, Payroll, Workforce, Expense, Expense Claims | `/home`, `/recruitment`, … | placeholders | Only placeholder labels exist. |
| `texting code/table.html`, `table2.html` | none (component library) | `DataGridComponent` (search, column filters, sort, page-size, pagination) | Server-side paging contract needed. |
| `texting code/tabs.html` | none (component library) | `TabsComponent` (horizontal/vertical, scroll arrows) | – |
| `css/style.css`, `css/calendar-css/*`, `login2.html <style>` | global styles / component styles | – | Login `<style>` to be split into the login component styles. |
| `images/`, `fonts/`, `Opensans/`, `tabler-icons/` | `public/assets/…` | – | Copy as-is; optimise large images. |
| `js/javascript.js`, inline scripts | – | replaced by component logic | jQuery removed. |
| `js/bootstrap_5/6.min.js`, `jquery-4.0.0.min.js` | – | **dropped** | Reasons in HTML-ANALYSIS §6–7. |
