import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private readonly API_URL = 'https://projectapi.gerasim.in/api/UserApp/login';
  private readonly REMEMBER_KEY = 'savvy_remember_email';

  // Form data (bound with ngModel in app.html)
  userObj = {
    EmailId: '',
    Password: '',
  };
  rememberMe = false;

  // Screen state (signals so the page updates correctly)
  isLoggedIn = signal(false);
  isLoading = signal(false);
  errorMessage = signal('');

  // 1) Page load: restore the remembered email (if any)
  ngOnInit() {
    try {
      const savedEmail = localStorage.getItem(this.REMEMBER_KEY);
      if (savedEmail) {
        this.userObj.EmailId = savedEmail;
        this.rememberMe = true;
      }
    } catch {
      // storage blocked: just show an empty form
    }
  }

  // 2) Sign in
  async onLogin() {
    this.errorMessage.set('');

    if (!this.userObj.EmailId.trim() || !this.userObj.Password.trim()) {
      this.errorMessage.set('Please enter your email ID and password.');
      return;
    }

    this.isLoading.set(true);
    try {
      const response = await fetch(this.API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.userObj),
      });

      const res = await response.json();

      if (response.ok && res?.result) {
        // 3) Save or clear the remembered email ONLY after a successful login
        this.handleRememberMe();
        localStorage.setItem('LoginUser', JSON.stringify(res.data));
        this.isLoggedIn.set(true);
      } else {
        this.errorMessage.set(res?.message || 'Invalid email ID or password.');
      }
    } catch {
      this.errorMessage.set('Cannot connect to the server. Please try again.');
    } finally {
      this.isLoading.set(false);
    }
  }

  private handleRememberMe() {
    try {
      if (this.rememberMe) {
        localStorage.setItem(this.REMEMBER_KEY, this.userObj.EmailId);
      } else {
        localStorage.removeItem(this.REMEMBER_KEY); // unticked = forget the user
      }
    } catch {
      // storage blocked: ignore
    }
  }

  // 4) Log out: clear session, keep the remembered email as it is
  onLogout() {
    localStorage.removeItem('LoginUser');
    this.userObj.Password = '';
    this.isLoggedIn.set(false);
  }
}