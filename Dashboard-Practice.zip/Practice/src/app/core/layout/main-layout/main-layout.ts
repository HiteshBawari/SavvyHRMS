import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { SettingsService } from '../../services/settings.service';
import { Sidebar } from '../sidebar/sidebar';
import { Topbar } from '../topbar/topbar';

/** The signed-in shell: sidebar + top bar + the page for the current route. The login page is NOT inside this. */
@Component({
  selector: 'app-main-layout',
  imports: [RouterOutlet, Sidebar, Topbar],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.css',
})
export class MainLayout {
  private settings = inject(SettingsService);
  collapsed = signal(this.settings.settings().preferences.sidebarCollapsed);
  mobileOpen = signal(false);

  constructor() {
    inject(Router).events.pipe(filter((e) => e instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => {
      this.mobileOpen.set(false);
      window.scrollTo({ top: 0 });
    });
  }

  toggleMenu(): void {
    if (window.innerWidth <= 900) {
      this.mobileOpen.update((v) => !v);
    } else {
      const next = !this.collapsed();
      this.collapsed.set(next);
      this.settings.patch('preferences', { sidebarCollapsed: next });
    }
  }
}
