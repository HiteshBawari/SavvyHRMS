import { Component, ElementRef, HostListener, computed, inject, output, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { filter, map, startWith } from 'rxjs';
import { Icon } from '../../../shared/components/icon/icon';
import { formatDateTime, initials } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-topbar',
  imports: [RouterLink, Icon],
  templateUrl: './topbar.html',
  styleUrl: './topbar.css',
})
export class Topbar {
  toggleMenu = output<void>();

  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private host = inject(ElementRef<HTMLElement>);
  private auth = inject(AuthService);
  notifier = inject(NotificationService);

  user = this.auth.session;
  userInitials = computed(() => initials(this.user()?.name ?? ''));
  userColor = computed(() => colorFor(this.user()?.name ?? ''));
  today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  fmt = formatDateTime;

  showNotifications = signal(false);
  showProfile = signal(false);

  /** Breadcrumb comes from the `data: { title }` of each nested route, so it follows navigation automatically. */
  crumbs = toSignal(
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd), startWith(null), map(() => this.buildCrumbs())),
    { initialValue: [] as string[] },
  );

  private buildCrumbs(): string[] {
    const out: string[] = [];
    let r = this.route.root.snapshot;
    while (r.firstChild) {
      r = r.firstChild;
      const t = r.data['title'] as string | undefined;
      if (t) out.push(t);
    }
    return out;
  }

  toggleNotifications(): void { this.showNotifications.update((v) => !v); this.showProfile.set(false); }
  toggleProfile(): void { this.showProfile.update((v) => !v); this.showNotifications.set(false); }
  open(link?: string, id?: string): void {
    if (id) this.notifier.markRead(id);
    this.showNotifications.set(false);
    if (link) void this.router.navigateByUrl(link);
  }
  logout(): void { this.showProfile.set(false); this.auth.logout(); }

  @HostListener('document:click', ['$event'])
  onDocClick(e: Event): void {
    if (!(this.host.nativeElement as HTMLElement).contains(e.target as Node)) { this.showNotifications.set(false); this.showProfile.set(false); }
  }
  @HostListener('document:keydown.escape')
  onEscape(): void { this.showNotifications.set(false); this.showProfile.set(false); }
}
