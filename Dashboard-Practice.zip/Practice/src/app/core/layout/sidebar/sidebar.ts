import { Component, computed, inject, input, output } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Icon } from '../../../shared/components/icon/icon';
import { initials } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';
import { AuthService } from '../../services/auth.service';
import { LeaveService } from '../../services/leave.service';
import { SettingsService } from '../../services/settings.service';

interface NavItem { label: string; link: string; icon: string; badge?: boolean }

@Component({
  selector: 'app-sidebar',
  imports: [RouterLink, RouterLinkActive, Icon],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css',
})
export class Sidebar {
  collapsed = input(false);
  mobileOpen = input(false);
  closeMobile = output<void>();

  private auth = inject(AuthService);
  private leave = inject(LeaveService);
  private settings = inject(SettingsService);

  readonly main: NavItem[] = [
    { label: 'Overview', link: '/overview', icon: 'grid' },
    { label: 'Employees', link: '/employees', icon: 'users' },
    { label: 'Attendance', link: '/attendance', icon: 'clock' },
    { label: 'Leave Management', link: '/leave', icon: 'calendar', badge: true },
    { label: 'Departments', link: '/departments', icon: 'briefcase' },
    { label: 'Payroll', link: '/payroll', icon: 'rupee' },
  ];
  readonly workspace: NavItem[] = [
    { label: 'Reports', link: '/reports', icon: 'chart' },
    { label: 'Settings', link: '/settings', icon: 'sliders' },
  ];

  pending = computed(() => this.leave.pending().length);
  company = computed(() => this.settings.settings().general);
  user = this.auth.session;
  userInitials = computed(() => initials(this.user()?.name ?? ''));
  userColor = computed(() => colorFor(this.user()?.name ?? ''));

  logout(): void { this.auth.logout(); }
}
