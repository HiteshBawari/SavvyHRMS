import { CompanySettings } from './models';

export const DEFAULT_SETTINGS: CompanySettings = {
  version: 1,
  general: {
    companyName: 'Savvy HRMS',
    email: 'hr@savvyhrms.demo',
    phone: '+91 00000 00000',
    address: 'Your company address',
    initials: 'SH',
    openPositions: 3,
    showActivity: true,
    showHolidays: true,
  },
  attendance: {
    workingDays: [1, 2, 3, 4, 5, 6], // Mon-Sat. Sunday is a weekly off. Change in Settings.
    shiftStart: '09:30',
    shiftEnd: '18:30',
    graceMinutes: 15,
    allowOvernight: false,
    countNoRecordAsAbsent: false,
  },
  leave: {
    types: [
      { name: 'Casual Leave', annualQuota: 12, paid: true },
      { name: 'Sick Leave', annualQuota: 10, paid: true },
      { name: 'Earned Leave', annualQuota: 15, paid: true },
      { name: 'Unpaid Leave', annualQuota: null, paid: false },
    ],
    requireDecisionNote: false,
  },
  payroll: { currency: 'INR', allowancePercent: 20, deductionPercent: 10 },
  preferences: {
    theme: 'light',
    sidebarCollapsed: false,
    notifyLeave: true,
    notifyAttendance: true,
    notifyPayroll: true,
  },
};

/** Demo login for the localStorage-only version. NOT real security: anyone can read this in the browser. */
export const DEMO_CREDENTIALS = { email: 'admin@savvyhrms.demo', password: 'Demo@123', name: 'Demo Admin' };
