// ---------- Shared data models (one interface per kind of saved record) ----------
// Dates are ISO strings "YYYY-MM-DD" (local calendar date). Times are 24-hour "HH:mm" (local time).

export type EmploymentType = 'Full-time' | 'Part-time' | 'Contract' | 'Intern';
export type EmployeeStatus = 'Active' | 'Onboarding' | 'On Notice' | 'Inactive';

export interface Employee {
  id: string;
  code: string; // e.g. EMP-0001 (unique)
  fullName: string;
  email: string; // unique
  phone: string;
  departmentId: string;
  designation: string;
  joiningDate: string;
  employmentType: EmploymentType;
  status: EmployeeStatus;
  basicSalary: number; // monthly
  address?: string;
  emergencyContact?: string;
  createdAt: string; // full ISO date-time
}

export interface Department {
  id: string;
  name: string;
  code: string;
  managerId?: string;
  description?: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export type AttendanceStatus = 'Present' | 'Absent' | 'Half Day';

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  date: string;
  checkIn?: string;
  checkOut?: string;
  status: AttendanceStatus;
  durationMinutes: number; // 0 until both times exist
  remarks?: string;
}

export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';

export interface LeaveRequest {
  id: string;
  employeeId: string;
  type: string;
  startDate: string;
  endDate: string;
  days: number; // working days only (weekly offs and holidays excluded)
  reason: string;
  notes?: string;
  status: LeaveStatus;
  createdAt: string;
  decidedAt?: string;
  decisionNote?: string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  period: string; // "YYYY-MM"
  basic: number;
  allowances: number;
  deductions: number;
  net: number; // basic + allowances - deductions
  status: 'Paid' | 'Pending';
  paidOn?: string;
  createdAt: string;
}

export interface Holiday {
  id: string;
  date: string;
  name: string;
  type: 'Public' | 'Company';
}

export interface LeaveType {
  name: string;
  annualQuota: number | null; // null = no limit
  paid: boolean;
}

export interface CompanySettings {
  version: number;
  general: {
    companyName: string;
    email: string;
    phone: string;
    address: string;
    initials: string;
    openPositions: number;
    showActivity: boolean;
    showHolidays: boolean;
  };
  attendance: {
    workingDays: number[]; // 0 = Sunday ... 6 = Saturday
    shiftStart: string;
    shiftEnd: string;
    graceMinutes: number;
    allowOvernight: boolean;
    countNoRecordAsAbsent: boolean;
  };
  leave: { types: LeaveType[]; requireDecisionNote: boolean };
  payroll: { currency: string; allowancePercent: number; deductionPercent: number };
  preferences: {
    theme: 'light' | 'dark';
    sidebarCollapsed: boolean;
    notifyLeave: boolean;
    notifyAttendance: boolean;
    notifyPayroll: boolean;
  };
}

export interface UserSession {
  name: string;
  email: string;
  role: string;
  mode: 'demo' | 'api';
  loginAt: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  at: string;
  read: boolean;
  link?: string;
}

export interface FeedbackSubmission {
  id: string;
  rating: number;
  category: string;
  message: string;
  at: string;
}

export interface ContactInquiry {
  id: string;
  kind: 'contact' | 'customization';
  name: string;
  email: string;
  subject: string;
  message: string;
  at: string;
}

export interface ActivityLog {
  id: string;
  at: string;
  type: 'employee' | 'attendance' | 'leave' | 'payroll' | 'department' | 'system';
  message: string;
}

export interface Result<T = void> {
  ok: boolean;
  error?: string;
  value?: T;
}
