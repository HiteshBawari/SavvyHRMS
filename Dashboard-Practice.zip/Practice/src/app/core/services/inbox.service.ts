import { Injectable, inject, signal } from '@angular/core';
import { ContactInquiry, FeedbackSubmission } from '../models/models';
import { uid } from '../../shared/utils/date.utils';
import { StorageService } from './storage.service';

/** Saves contact messages, customization inquiries and feedback in this browser only. Nothing is sent anywhere. */
@Injectable({ providedIn: 'root' })
export class InboxService {
  private storage = inject(StorageService);
  readonly feedback = signal<FeedbackSubmission[]>(this.storage.getArray<FeedbackSubmission>('feedback'));
  readonly inquiries = signal<ContactInquiry[]>(this.storage.getArray<ContactInquiry>('inquiries'));

  addFeedback(rating: number, category: string, message: string): void {
    const next = [{ id: uid('fb'), rating, category, message: message.trim(), at: new Date().toISOString() }, ...this.feedback()];
    this.feedback.set(next);
    this.storage.set('feedback', next);
  }
  addInquiry(kind: ContactInquiry['kind'], v: { name: string; email: string; subject: string; message: string }): void {
    const next = [{ id: uid('inq'), kind, name: v.name.trim(), email: v.email.trim(), subject: v.subject.trim(), message: v.message.trim(), at: new Date().toISOString() }, ...this.inquiries()];
    this.inquiries.set(next);
    this.storage.set('inquiries', next);
  }
}
