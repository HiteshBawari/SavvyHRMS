import { Injectable, computed, inject, signal } from '@angular/core';
import { LeaveRequest, LeaveStatus, Result } from '../models/models';
import { countLeaveDays } from '../../shared/utils/attendance.calc';
import { isISODate, uid } from '../../shared/utils/date.utils';
import { ActivityService } from './activity.service';
import { NotificationService } from './notification.service';
import { SettingsService } from './settings.service';
import { StorageService } from './storage.service';

export interface LeaveInput {
  employeeId: string; employeeName: string; type: string;
  startDate: string; endDate: string; reason: string; notes?: string;
}

@Injectable({ providedIn: 'root' })
export class LeaveService {
  private storage = inject(StorageService);
  private settings = inject(SettingsService);
  private activity = inject(ActivityService);
  private notifier = inject(NotificationService);

  readonly items = signal<LeaveRequest[]>(this.storage.getArray<LeaveRequest>('leaves'));
  readonly pending = computed(() => this.items().filter((l) => l.status === 'Pending'));

  private approvedByEmployee = computed(() => {
    const m = new Map<string, LeaveRequest[]>();
    for (const l of this.items()) if (l.status === 'Approved') m.set(l.employeeId, [...(m.get(l.employeeId) ?? []), l]);
    return m;
  });

  byId(id: string): LeaveRequest | undefined { return this.items().find((l) => l.id === id); }

  /** The approved leave covering this date, if any. Used by the attendance rules. */
  leaveOf(employeeId: string, date: string): LeaveRequest | undefined {
    return this.approvedByEmployee().get(employeeId)?.find((l) => l.startDate <= date && date <= l.endDate);
  }

  previewDays(start: string, end: string): number {
    return isISODate(start) && isISODate(end) && start <= end
      ? countLeaveDays(this.settings.settings().attendance, this.settings.holidayMap(), start, end) : 0;
  }

  /** Quota rule: used = approved working days in the same calendar year as the start date. */
  balance(employeeId: string, typeName: string, year: number): { quota: number | null; used: number; pending: number; remaining: number | null } {
    const quota = this.settings.settings().leave.types.find((t) => t.name === typeName)?.annualQuota ?? null;
    const inYear = (l: LeaveRequest) => l.employeeId === employeeId && l.type === typeName && l.startDate.startsWith(String(year));
    const used = this.items().filter((l) => inYear(l) && l.status === 'Approved').reduce((n, l) => n + l.days, 0);
    const pending = this.items().filter((l) => inYear(l) && l.status === 'Pending').reduce((n, l) => n + l.days, 0);
    return { quota, used, pending, remaining: quota === null ? null : quota - used - pending };
  }

  create(input: LeaveInput): Result<LeaveRequest> {
    if (!input.employeeId) return { ok: false, error: 'Choose an employee.' };
    if (!isISODate(input.startDate) || !isISODate(input.endDate)) return { ok: false, error: 'Enter valid start and end dates.' };
    if (input.endDate < input.startDate) return { ok: false, error: 'End date cannot be before the start date.' };
    const days = this.previewDays(input.startDate, input.endDate);
    if (days === 0) return { ok: false, error: 'That range has no working days (only weekly offs or holidays).' };
    const clash = this.items().find((l) => l.employeeId === input.employeeId && (l.status === 'Pending' || l.status === 'Approved')
      && l.startDate <= input.endDate && input.startDate <= l.endDate);
    if (clash) return { ok: false, error: `Overlaps an existing ${clash.status.toLowerCase()} request (${clash.startDate} to ${clash.endDate}).` };
    const bal = this.balance(input.employeeId, input.type, Number(input.startDate.slice(0, 4)));
    if (bal.remaining !== null && days > bal.remaining) {
      return { ok: false, error: `Only ${Math.max(bal.remaining, 0)} day(s) left for ${input.type} this year; you asked for ${days}.` };
    }
    const rec: LeaveRequest = {
      id: uid('lv'), employeeId: input.employeeId, type: input.type, startDate: input.startDate, endDate: input.endDate,
      days, reason: input.reason.trim(), notes: input.notes?.trim() || undefined, status: 'Pending', createdAt: new Date().toISOString(),
    };
    this.persist([rec, ...this.items()]);
    this.activity.log('leave', `${input.employeeName} requested ${days} day(s) of ${input.type}`);
    this.notifier.notify('leave', 'New leave request', `${input.employeeName} requested ${input.type} (${days} day/s).`, `/leave/${rec.id}`);
    return { ok: true, value: rec };
  }

  decide(id: string, status: Extract<LeaveStatus, 'Approved' | 'Rejected'>, employeeName: string, note?: string): Result {
    const l = this.byId(id);
    if (!l) return { ok: false, error: 'Request not found.' };
    if (l.status !== 'Pending') return { ok: false, error: `Only pending requests can be ${status.toLowerCase()}.` };
    if (this.settings.settings().leave.requireDecisionNote && !note?.trim()) return { ok: false, error: 'Please add a note for this decision (required in Settings).' };
    this.persist(this.items().map((x) => (x.id === id ? { ...x, status, decidedAt: new Date().toISOString(), decisionNote: note?.trim() || undefined } : x)));
    this.activity.log('leave', `${status} ${employeeName}'s ${l.type} request`);
    this.notifier.notify('leave', `Leave ${status.toLowerCase()}`, `${employeeName}: ${l.type}, ${l.days} day(s).`, `/leave/${id}`);
    return { ok: true };
  }

  cancel(id: string, employeeName: string): Result {
    const l = this.byId(id);
    if (!l || l.status !== 'Pending') return { ok: false, error: 'Only pending requests can be cancelled.' };
    this.persist(this.items().map((x) => (x.id === id ? { ...x, status: 'Cancelled' as const, decidedAt: new Date().toISOString() } : x)));
    this.activity.log('leave', `Cancelled ${employeeName}'s ${l.type} request`);
    return { ok: true };
  }

  countFor(employeeId: string): number { return this.items().filter((l) => l.employeeId === employeeId).length; }
  removeForEmployee(employeeId: string): void { this.persist(this.items().filter((l) => l.employeeId !== employeeId)); }

  private persist(next: LeaveRequest[]): void {
    this.items.set(next);
    this.storage.set('leaves', next);
  }
}
