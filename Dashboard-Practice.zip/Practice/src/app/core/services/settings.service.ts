import { Injectable, computed, effect, inject, signal } from '@angular/core';
import { DEFAULT_SETTINGS } from '../models/defaults';
import { CompanySettings, Holiday, Result } from '../models/models';
import { formatMoney } from '../../shared/utils/format.utils';
import { isISODate, uid } from '../../shared/utils/date.utils';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private storage = inject(StorageService);

  readonly settings = signal<CompanySettings>(this.load());
  readonly holidays = signal<Holiday[]>(this.storage.getArray<Holiday>('holidays').filter((h) => isISODate(h?.date)));
  readonly holidayMap = computed(() => new Map(this.holidays().map((h) => [h.date, h])));

  constructor() {
    // Apply the saved theme to the whole page.
    effect(() => {
      document.documentElement.dataset['theme'] = this.settings().preferences.theme;
    });
  }

  /** Merge saved settings over defaults, so old saved data still works after new fields are added. */
  private load(): CompanySettings {
    const d = DEFAULT_SETTINGS;
    const s = this.storage.get<Partial<CompanySettings>>('settings', {});
    const merged: CompanySettings = {
      version: d.version,
      general: { ...d.general, ...s.general },
      attendance: { ...d.attendance, ...s.attendance },
      leave: { ...d.leave, ...s.leave },
      payroll: { ...d.payroll, ...s.payroll },
      preferences: { ...d.preferences, ...s.preferences },
    };
    if (!Array.isArray(merged.attendance.workingDays)) merged.attendance.workingDays = d.attendance.workingDays;
    if (!Array.isArray(merged.leave.types) || !merged.leave.types.length) merged.leave.types = d.leave.types;
    return merged;
  }

  save(next: CompanySettings): void {
    this.settings.set(next);
    this.storage.set('settings', next);
  }
  patch<K extends keyof CompanySettings>(section: K, value: Partial<CompanySettings[K]>): void {
    const cur = this.settings();
    this.save({ ...cur, [section]: { ...(cur[section] as object), ...(value as object) } } as CompanySettings);
  }

  money(amount: number): string {
    return formatMoney(amount, this.settings().payroll.currency);
  }

  addHoliday(date: string, name: string, type: Holiday['type']): Result {
    if (!isISODate(date)) return { ok: false, error: 'Choose a valid date.' };
    if (!name.trim()) return { ok: false, error: 'Holiday name is required.' };
    if (this.holidayMap().has(date)) return { ok: false, error: 'A holiday already exists on that date.' };
    this.persistHolidays([...this.holidays(), { id: uid('hol'), date, name: name.trim(), type }].sort((a, b) => a.date.localeCompare(b.date)));
    return { ok: true };
  }
  removeHoliday(id: string): void {
    this.persistHolidays(this.holidays().filter((h) => h.id !== id));
  }
  private persistHolidays(next: Holiday[]): void {
    this.holidays.set(next);
    this.storage.set('holidays', next);
  }
}
