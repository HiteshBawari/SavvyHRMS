import { Injectable } from '@angular/core';

/** Every key this app writes starts with this prefix, so "reset" never touches unrelated site data. */
export const STORAGE_PREFIX = 'savvyhrms.v1.';

@Injectable({ providedIn: 'root' })
export class StorageService {
  private get ls(): Storage | null {
    try {
      return typeof localStorage === 'undefined' ? null : localStorage;
    } catch {
      return null; // storage blocked (private mode / browser settings)
    }
  }

  /** Read and parse JSON safely. Missing or broken data returns the fallback instead of crashing. */
  get<T>(key: string, fallback: T): T {
    try {
      const raw = this.ls?.getItem(STORAGE_PREFIX + key);
      if (raw === null || raw === undefined) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  }

  getArray<T>(key: string): T[] {
    const value = this.get<unknown>(key, []);
    return Array.isArray(value) ? (value as T[]) : [];
  }

  set(key: string, value: unknown): boolean {
    try {
      this.ls?.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
      return !!this.ls;
    } catch {
      return false; // quota exceeded or blocked
    }
  }

  remove(key: string): void {
    try {
      this.ls?.removeItem(STORAGE_PREFIX + key);
    } catch {
      /* ignore */
    }
  }

  /** Removes only this app's keys (never localStorage.clear()). */
  clearAppData(keep: string[] = []): void {
    const ls = this.ls;
    if (!ls) return;
    const toRemove: string[] = [];
    for (let i = 0; i < ls.length; i++) {
      const k = ls.key(i);
      if (k && k.startsWith(STORAGE_PREFIX) && !keep.includes(k.slice(STORAGE_PREFIX.length))) toRemove.push(k);
    }
    toRemove.forEach((k) => ls.removeItem(k));
  }
}
