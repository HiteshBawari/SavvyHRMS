import { Injectable, inject } from '@angular/core';
import { DEFAULT_SETTINGS } from '../models/defaults';
import { ActivityLog, AppNotification, AttendanceRecord, Department, Employee, Holiday, LeaveRequest, PayrollRecord } from '../models/models';
import { countLeaveDays } from '../../shared/utils/attendance.calc';
import { addDays, eachDate, parseISO, todayISO, toISO, weekday, workMinutes } from '../../shared/utils/date.utils';
import { StorageService } from './storage.service';

interface Meta { seeded: boolean; demo: boolean; seededAt: string }

/**
 * Creates sample data the first time the app opens, and can clear or reset it.
 * Sample data is generated relative to today's date so the screens always have recent records.
 * It is fake: names, numbers and holidays are examples only.
 */
@Injectable({ providedIn: 'root' })
export class DemoDataService {
  private storage = inject(StorageService);

  /** Called once at startup (before any other service reads storage). */
  ensureSeeded(): void {
    const meta = this.storage.get<Partial<Meta> | null>('meta', null);
    if (meta?.seeded) return;
    this.seed();
  }

  /** Removes all employees, attendance, leave, payroll, activity and notifications. Keeps your settings and login. */
  clearDemoData(): void {
    ['employees', 'departments', 'attendance', 'leaves', 'payroll', 'holidays', 'activity', 'notifications', 'feedback', 'inquiries']
      .forEach((k) => this.storage.remove(k));
    this.storage.set('meta', { seeded: true, demo: false, seededAt: new Date().toISOString() } satisfies Meta);
  }

  /** Removes every key this app owns (except the login session) and creates fresh sample data. */
  resetAll(): void {
    this.storage.clearAppData(['session']);
    this.seed();
  }

  private seed(): void {
    const today = todayISO();
    const att = DEFAULT_SETTINGS.attendance;
    const rel = (days: number) => addDays(today, -days);

    // ----- Holidays (sample list: edit in Settings > Attendance) -----
    const y = parseISO(today).getFullYear();
    const holidayRows: [string, string, Holiday['type']][] = [
      [`${y}-01-26`, 'Republic Day', 'Public'], [`${y}-08-15`, 'Independence Day', 'Public'], [`${y}-10-02`, 'Gandhi Jayanti', 'Public'],
      [`${y}-12-25`, 'Christmas', 'Public'], [`${y + 1}-01-26`, 'Republic Day', 'Public'], [`${y}-11-08`, 'Diwali (sample date)', 'Company'],
    ];
    const holidays: Holiday[] = holidayRows.map(([date, name, type], i) => ({ id: `hol_seed${i}`, date, name, type }));
    const holidaySet = new Map(holidays.map((h) => [h.date, h]));
    const isWorking = (d: string) => att.workingDays.includes(weekday(d)) && !holidaySet.has(d);
    const workingOnOrAfter = (d: string) => { let x = d; while (!isWorking(x)) x = addDays(x, 1); return x; };

    // ----- Departments -----
    const deps: Department[] = [
      ['eng', 'Engineering', 'ENG', 'Builds and maintains our software products.'],
      ['dsn', 'Design', 'DSN', 'Product, UI and brand design.'],
      ['mkt', 'Marketing', 'MKT', 'Campaigns, content and growth.'],
      ['ops', 'Operations', 'OPS', 'Day-to-day business operations and logistics.'],
      ['hr', 'Human Resources', 'HR', 'Hiring, onboarding and employee support.'],
    ].map(([k, name, code, description]) => ({ id: `dep_${k}`, name, code, description, status: 'Active' as const, createdAt: new Date().toISOString() }));

    // ----- Employees [dept, name, designation, salary, joinedDaysAgo, status, type] -----
    const rows: [string, string, string, number, number, Employee['status'], Employee['employmentType']][] = [
      ['eng', 'Aarav Sharma', 'Senior Software Engineer', 95000, 900, 'Active', 'Full-time'],
      ['eng', 'Isha Verma', 'Frontend Developer', 62000, 700, 'Active', 'Full-time'],
      ['mkt', 'Rohan Kapoor', 'Marketing Lead', 70000, 620, 'Active', 'Full-time'],
      ['dsn', 'Simran Patel', 'UI/UX Designer', 58000, 540, 'Active', 'Full-time'],
      ['ops', 'Neha Gupta', 'Operations Manager', 76000, 800, 'Active', 'Full-time'],
      ['eng', 'Vikram Singh', 'Backend Developer', 68000, 450, 'Active', 'Full-time'],
      ['hr', 'Priya Desai', 'HR Manager', 72000, 950, 'Active', 'Full-time'],
      ['dsn', 'Aditya Rao', 'Graphic Designer', 42000, 300, 'Active', 'Contract'],
      ['mkt', 'Kavya Nair', 'Content Strategist', 46000, 220, 'Active', 'Full-time'],
      ['ops', 'Manish Yadav', 'Logistics Coordinator', 34000, 160, 'Active', 'Part-time'],
      ['eng', 'Ananya Joshi', 'QA Engineer', 52000, 21, 'Onboarding', 'Full-time'],
      ['mkt', 'Karan Malhotra', 'SEO Analyst', 40000, 9, 'Onboarding', 'Intern'],
      ['ops', 'Rahul Mehta', 'Warehouse Executive', 30000, 400, 'Inactive', 'Full-time'],
    ];
    const employees: Employee[] = rows.map(([dep, fullName, designation, basicSalary, ago, status, employmentType], i) => ({
      id: `emp_seed${i + 1}`, code: `EMP-${String(i + 1).padStart(4, '0')}`, fullName,
      email: `${fullName.toLowerCase().replace(/\s+/g, '.')}@savvyhrms.demo`, phone: `98${String(10000000 + i * 137).slice(0, 8)}`,
      departmentId: `dep_${dep}`, designation, joiningDate: rel(ago), employmentType, status, basicSalary,
      address: i % 3 === 0 ? 'Sample address, India' : undefined, createdAt: new Date(parseISO(rel(ago)).getTime() + 36e5 * 10).toISOString(),
    }));
    const manager: Record<string, number> = { eng: 0, dsn: 3, mkt: 2, ops: 4, hr: 6 };
    deps.forEach((d) => { d.managerId = employees[manager[d.id.slice(4)]].id; });

    // ----- Leave requests (relative to today) -----
    const mk = (i: number, type: string, start: string, len: number, status: LeaveRequest['status'], reason: string): LeaveRequest => {
      const s = workingOnOrAfter(start);
      let e = s; let n = 1;
      while (n < len) { e = addDays(e, 1); if (isWorking(e)) n++; }
      return { id: `lv_seed${i}`, employeeId: employees[i].id, type, startDate: s, endDate: e, days: countLeaveDays(att, holidaySet, s, e), reason,
        status, createdAt: new Date().toISOString(), decidedAt: status === 'Pending' ? undefined : new Date().toISOString() };
    };
    const leaves: LeaveRequest[] = [
      mk(8, 'Sick Leave', today, 1, 'Approved', 'Fever and rest'),            // on leave today
      mk(2, 'Casual Leave', rel(6), 2, 'Approved', 'Family function'),
      mk(3, 'Earned Leave', addDays(today, 3), 2, 'Approved', 'Short trip'),
      mk(5, 'Sick Leave', addDays(today, 1), 2, 'Pending', 'Doctor appointment'),
      mk(1, 'Earned Leave', addDays(today, 7), 3, 'Pending', 'Visiting hometown'),
      mk(6, 'Casual Leave', addDays(today, 12), 1, 'Pending', 'Personal work'),
      mk(7, 'Casual Leave', rel(15), 1, 'Rejected', 'Personal work'),
    ];
    const leaveDays = new Set<string>();
    leaves.filter((l) => l.status === 'Approved').forEach((l) => eachDate(l.startDate, l.endDate).forEach((d) => leaveDays.add(l.employeeId + '|' + d)));

    // ----- Attendance: previous month start -> yesterday (+ some of today) -----
    const t0 = parseISO(today);
    const from = toISO(new Date(t0.getFullYear(), t0.getMonth() - 1, 1)); // first day of last month
    const hhmm = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
    const attendance: AttendanceRecord[] = [];
    employees.forEach((e, i) => {
      if (e.status === 'Inactive') return;
      const start = e.joiningDate > from ? e.joiningDate : from;
      for (const d of eachDate(start, today)) {
        if (!isWorking(d) || leaveDays.has(e.id + '|' + d)) continue; // no fake records on Sundays, holidays or leave
        const r = (i * 53 + parseISO(d).getDate() * 31 + parseISO(d).getMonth() * 17) % 100;
        if (d === today) {
          if (i % 5 === 4) continue; // leave a few people unrecorded so Check In can be tried
          const cin = hhmm(9 * 60 + 5 + ((i * 7) % 45));
          attendance.push({ id: `att_${i}_${d}`, employeeId: e.id, date: d, status: 'Present', checkIn: cin, durationMinutes: 0 });
          continue;
        }
        if (r < 80) {
          const cin = hhmm(9 * 60 + 10 + (r % 40)); const cout = hhmm(18 * 60 + (r % 35));
          attendance.push({ id: `att_${i}_${d}`, employeeId: e.id, date: d, status: 'Present', checkIn: cin, checkOut: cout, durationMinutes: workMinutes(cin, cout) });
        } else if (r < 86) {
          attendance.push({ id: `att_${i}_${d}`, employeeId: e.id, date: d, status: 'Half Day', checkIn: '09:40', checkOut: '13:45', durationMinutes: workMinutes('09:40', '13:45'), remarks: 'Left early' });
        } else if (r < 91) {
          attendance.push({ id: `att_${i}_${d}`, employeeId: e.id, date: d, status: 'Absent', durationMinutes: 0 });
        } // else: no record (shown blank, not as absent)
      }
    });

    // ----- Payroll: last month paid, this month pending -----
    const cur = parseISO(today);
    const period = (offset: number) => { const d = new Date(cur.getFullYear(), cur.getMonth() + offset, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
    const payroll: PayrollRecord[] = [];
    for (const off of [-1, 0]) {
      employees.filter((e) => e.status !== 'Inactive' && e.joiningDate <= `${period(off)}-28`).forEach((e) => {
        const a = Math.round((e.basicSalary * DEFAULT_SETTINGS.payroll.allowancePercent) / 100);
        const d = Math.round((e.basicSalary * DEFAULT_SETTINGS.payroll.deductionPercent) / 100);
        payroll.push({ id: `pay_${e.id}_${period(off)}`, employeeId: e.id, period: period(off), basic: e.basicSalary, allowances: a, deductions: d,
          net: e.basicSalary + a - d, status: off < 0 ? 'Paid' : 'Pending', paidOn: off < 0 ? `${period(off)}-28` : undefined, createdAt: new Date().toISOString() });
      });
    }

    const now = new Date().toISOString();
    const activity: ActivityLog[] = [
      { id: 'act_seed2', at: now, type: 'system', message: 'Sample data loaded. Clear or reset it in Settings > Application.' },
    ];
    const notifications: AppNotification[] = [
      { id: 'ntf_seed1', title: 'Welcome to Savvy HRMS', message: 'This is a demo using sample data stored in your browser.', at: now, read: false, link: '/help' },
    ];

    const save = (k: string, v: unknown) => this.storage.set(k, v);
    save('departments', deps); save('employees', employees); save('holidays', holidays); save('leaves', leaves);
    save('attendance', attendance); save('payroll', payroll); save('activity', activity); save('notifications', notifications);
    save('meta', { seeded: true, demo: true, seededAt: now } satisfies Meta);
  }
}
