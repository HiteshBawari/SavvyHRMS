import { Injectable, computed, inject, signal } from '@angular/core';
import { AppNotification } from '../models/models';
import { uid } from '../../shared/utils/date.utils';
import { StorageService } from './storage.service';
import { SettingsService } from './settings.service';

export type ToastType = 'success' | 'error' | 'warning' | 'info';
export interface Toast { id: number; type: ToastType; message: string }

/** Toasts = short pop-up messages (not saved). Notifications = the bell list (saved). */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private storage = inject(StorageService);
  private settings = inject(SettingsService);
  private nextToastId = 1;

  readonly toasts = signal<Toast[]>([]);
  readonly items = signal<AppNotification[]>(this.storage.getArray<AppNotification>('notifications'));
  readonly unread = computed(() => this.items().filter((n) => !n.read).length);

  show(message: string, type: ToastType = 'success', ms = 4000): void {
    const id = this.nextToastId++;
    this.toasts.update((t) => [...t, { id, type, message }]);
    setTimeout(() => this.dismiss(id), ms);
  }
  success(m: string): void { this.show(m, 'success'); }
  error(m: string): void { this.show(m, 'error', 6000); }
  warn(m: string): void { this.show(m, 'warning', 5000); }
  dismiss(id: number): void { this.toasts.update((t) => t.filter((x) => x.id !== id)); }

  /** Adds an item to the bell list when the matching notification preference is on. */
  notify(channel: 'leave' | 'attendance' | 'payroll', title: string, message: string, link?: string): void {
    const p = this.settings.settings().preferences;
    const enabled = channel === 'leave' ? p.notifyLeave : channel === 'attendance' ? p.notifyAttendance : p.notifyPayroll;
    if (!enabled) return;
    this.persist([{ id: uid('ntf'), title, message, at: new Date().toISOString(), read: false, link }, ...this.items()].slice(0, 50));
  }
  markAllRead(): void { this.persist(this.items().map((n) => ({ ...n, read: true }))); }
  markRead(id: string): void { this.persist(this.items().map((n) => (n.id === id ? { ...n, read: true } : n))); }
  clearAll(): void { this.persist([]); }

  private persist(next: AppNotification[]): void {
    this.items.set(next);
    this.storage.set('notifications', next);
  }
}
