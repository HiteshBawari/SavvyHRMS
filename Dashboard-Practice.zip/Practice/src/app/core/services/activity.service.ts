import { Injectable, inject, signal } from '@angular/core';
import { ActivityLog } from '../models/models';
import { uid } from '../../shared/utils/date.utils';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class ActivityService {
  private storage = inject(StorageService);
  readonly items = signal<ActivityLog[]>(this.storage.getArray<ActivityLog>('activity'));

  log(type: ActivityLog['type'], message: string): void {
    const next = [{ id: uid('act'), at: new Date().toISOString(), type, message }, ...this.items()].slice(0, 100);
    this.items.set(next);
    this.storage.set('activity', next);
  }
}
