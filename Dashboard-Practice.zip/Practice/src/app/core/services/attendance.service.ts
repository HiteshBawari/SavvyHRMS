import { Injectable, computed, inject, signal } from '@angular/core';
import { AttendanceRecord, AttendanceStatus, Result } from '../models/models';
import { DayCtx, DayInfo, AttendanceSummary, resolveDay, summarize } from '../../shared/utils/attendance.calc';
import { addDays, isISODate, isTime, nowTime, todayISO, uid, workMinutes } from '../../shared/utils/date.utils';
import { ActivityService } from './activity.service';
import { LeaveService } from './leave.service';
import { NotificationService } from './notification.service';
import { SettingsService } from './settings.service';
import { StorageService } from './storage.service';

export interface EmpRef { id: string; fullName: string; joiningDate: string }
export interface AttendanceInput {
  id?: string; employeeId: string; date: string; status: AttendanceStatus;
  checkIn?: string; checkOut?: string; remarks?: string;
}

@Injectable({ providedIn: 'root' })
export class AttendanceService {
  private storage = inject(StorageService);
  private settings = inject(SettingsService);
  private leave = inject(LeaveService);
  private activity = inject(ActivityService);
  private notifier = inject(NotificationService);

  readonly records = signal<AttendanceRecord[]>(this.storage.getArray<AttendanceRecord>('attendance'));
  private index = computed(() => new Map(this.records().map((r) => [r.employeeId + '|' + r.date, r])));

  recordOf(employeeId: string, date: string): AttendanceRecord | undefined {
    return this.index().get(employeeId + '|' + date);
  }

  /** Everything resolveDay() needs. Reads signals, so screens refresh when data changes. */
  ctx(): DayCtx {
    return {
      att: this.settings.settings().attendance,
      holidays: this.settings.holidayMap(),
      recordOf: (e, d) => this.recordOf(e, d),
      leaveOf: (e, d) => this.leave.leaveOf(e, d),
      today: todayISO(),
    };
  }
  day(emp: EmpRef, date: string): DayInfo { return resolveDay(this.ctx(), emp, date); }
  summary(emp: EmpRef, from: string, to: string): AttendanceSummary { return summarize(this.ctx(), emp, from, to); }

  /** Counts for one date across the given employees. Non-working days are never counted as absent. */
  dailyStats(emps: EmpRef[], date: string): { present: number; half: number; absent: number; leave: number; off: number; noRecord: number; expected: number } {
    const ctx = this.ctx();
    const out = { present: 0, half: 0, absent: 0, leave: 0, off: 0, noRecord: 0, expected: 0 };
    for (const e of emps) {
      const k = resolveDay(ctx, e, date).kind;
      if (k === 'Not Joined' || k === 'Upcoming') continue;
      if (k === 'Present') out.present++;
      else if (k === 'Half Day') out.half++;
      else if (k === 'Absent') out.absent++;
      else if (k === 'Approved Leave') out.leave++;
      else if (k === 'Sunday' || k === 'Weekly Off' || k === 'Holiday') out.off++;
      else out.noRecord++;
      if (k !== 'Sunday' && k !== 'Weekly Off' && k !== 'Holiday' && k !== 'Approved Leave') out.expected++;
    }
    return out;
  }

  // ---------- Check in / out ----------
  checkIn(emp: EmpRef, time = nowTime(), date = todayISO()): Result {
    if (this.recordOf(emp.id, date)) return { ok: false, error: `${emp.fullName} already has an attendance record for today. Edit it from Attendance Records.` };
    this.persist([...this.records(), { id: uid('att'), employeeId: emp.id, date, checkIn: time, status: 'Present', durationMinutes: 0 }]);
    this.activity.log('attendance', `${emp.fullName} checked in at ${time}`);
    this.notifier.notify('attendance', 'Check-in recorded', `${emp.fullName} at ${time}`);
    return { ok: true };
  }

  checkOut(emp: EmpRef, time = nowTime(), today = todayISO()): Result {
    const allowOvernight = this.settings.settings().attendance.allowOvernight;
    let rec = this.recordOf(emp.id, today);
    if ((!rec || !rec.checkIn || rec.checkOut) && allowOvernight) {
      const prev = this.recordOf(emp.id, addDays(today, -1)); // overnight shift started yesterday
      if (prev?.checkIn && !prev.checkOut) rec = prev;
    }
    if (!rec || !rec.checkIn) return { ok: false, error: `${emp.fullName} has not checked in yet.` };
    if (rec.checkOut) return { ok: false, error: `${emp.fullName} has already checked out.` };
    const mins = workMinutes(rec.checkIn, time, allowOvernight);
    if (mins < 0) return { ok: false, error: 'Check-out cannot be earlier than check-in (enable overnight shifts in Settings if needed).' };
    const target = rec;
    this.persist(this.records().map((r) => (r.id === target.id ? { ...r, checkOut: time, durationMinutes: mins } : r)));
    this.activity.log('attendance', `${emp.fullName} checked out at ${time}`);
    this.notifier.notify('attendance', 'Check-out recorded', `${emp.fullName} at ${time}`);
    return { ok: true };
  }

  /** Mark Present / Absent / Half Day without inventing times. */
  mark(emp: EmpRef, date: string, status: AttendanceStatus, remarks?: string): Result {
    return this.save({ employeeId: emp.id, date, status, remarks }, emp);
  }

  /** Create or edit one record with full validation. */
  save(input: AttendanceInput, emp: EmpRef): Result {
    if (!isISODate(input.date)) return { ok: false, error: 'Choose a valid date.' };
    if (input.date > todayISO()) return { ok: false, error: 'You cannot record attendance for a future date.' };
    if (input.date < emp.joiningDate) return { ok: false, error: 'Date is before the employee joined.' };
    const checkIn = input.checkIn || undefined;
    const checkOut = input.checkOut || undefined;
    if (checkIn && !isTime(checkIn)) return { ok: false, error: 'Check-in time is not valid.' };
    if (checkOut && !isTime(checkOut)) return { ok: false, error: 'Check-out time is not valid.' };
    if (checkOut && !checkIn) return { ok: false, error: 'Add a check-in time before the check-out time.' };
    if (input.status === 'Absent' && (checkIn || checkOut)) return { ok: false, error: 'An Absent record cannot have check-in or check-out times.' };
    const dup = this.recordOf(input.employeeId, input.date);
    if (dup && dup.id !== input.id) return { ok: false, error: 'An attendance record already exists for this employee on that date.' };
    const mins = workMinutes(checkIn, checkOut, this.settings.settings().attendance.allowOvernight);
    if (mins < 0) return { ok: false, error: 'Check-out cannot be earlier than check-in.' };
    const rec: AttendanceRecord = {
      id: input.id ?? uid('att'), employeeId: input.employeeId, date: input.date, status: input.status,
      checkIn, checkOut, durationMinutes: mins, remarks: input.remarks?.trim() || undefined,
    };
    this.persist(input.id ? this.records().map((r) => (r.id === input.id ? rec : r)) : [...this.records(), rec]);
    this.activity.log('attendance', `${input.id ? 'Updated' : 'Recorded'} ${input.status.toLowerCase()} for ${emp.fullName} on ${input.date}`);
    return { ok: true };
  }

  remove(id: string, employeeName: string): void {
    this.persist(this.records().filter((r) => r.id !== id));
    this.activity.log('attendance', `Deleted an attendance record for ${employeeName}`);
  }
  countFor(employeeId: string): number { return this.records().filter((r) => r.employeeId === employeeId).length; }
  removeForEmployee(employeeId: string): void { this.persist(this.records().filter((r) => r.employeeId !== employeeId)); }

  private persist(next: AttendanceRecord[]): void {
    this.records.set(next);
    this.storage.set('attendance', next);
  }
}
