import { Injectable, inject, signal } from '@angular/core';
import { PayrollRecord, Result } from '../models/models';
import { todayISO, uid } from '../../shared/utils/date.utils';
import { ActivityService } from './activity.service';
import { NotificationService } from './notification.service';
import { SettingsService } from './settings.service';
import { StorageService } from './storage.service';

export const PERIOD_PATTERN = /^\d{4}-(0[1-9]|1[0-2])$/;
/** Net Salary = Basic + Allowances - Deductions (demo calculation, not statutory payroll). */
export const netSalary = (basic: number, allowances: number, deductions: number): number => basic + allowances - deductions;

@Injectable({ providedIn: 'root' })
export class PayrollService {
  private storage = inject(StorageService);
  private settings = inject(SettingsService);
  private activity = inject(ActivityService);
  private notifier = inject(NotificationService);

  readonly items = signal<PayrollRecord[]>(this.storage.getArray<PayrollRecord>('payroll'));

  byId(id: string): PayrollRecord | undefined { return this.items().find((p) => p.id === id); }
  exists(employeeId: string, period: string): boolean {
    return this.items().some((p) => p.employeeId === employeeId && p.period === period);
  }
  /** Default allowances/deductions from the percentages in Settings > Payroll. */
  defaults(basic: number): { allowances: number; deductions: number } {
    const p = this.settings.settings().payroll;
    return { allowances: Math.round((basic * p.allowancePercent) / 100), deductions: Math.round((basic * p.deductionPercent) / 100) };
  }

  create(emp: { id: string; fullName: string }, period: string, basic: number, allowances: number, deductions: number): Result<PayrollRecord> {
    if (!PERIOD_PATTERN.test(period)) return { ok: false, error: 'Choose a valid payroll month.' };
    if (!(basic > 0)) return { ok: false, error: 'Basic salary must be greater than zero. Add a salary on the employee first.' };
    if (allowances < 0 || deductions < 0) return { ok: false, error: 'Allowances and deductions cannot be negative.' };
    const net = netSalary(basic, allowances, deductions);
    if (net < 0) return { ok: false, error: 'Deductions cannot be larger than basic salary plus allowances.' };
    if (this.exists(emp.id, period)) return { ok: false, error: `${emp.fullName} already has a payroll entry for ${period}.` };
    const rec: PayrollRecord = { id: uid('pay'), employeeId: emp.id, period, basic, allowances, deductions, net, status: 'Pending', createdAt: new Date().toISOString() };
    this.persist([...this.items(), rec]);
    this.activity.log('payroll', `Payroll entry created for ${emp.fullName} (${period})`);
    return { ok: true, value: rec };
  }

  /** Creates entries for everyone who does not have one yet. Employees without a salary are skipped and counted. */
  generate(period: string, employees: { id: string; fullName: string; basicSalary: number }[]): { created: number; skippedNoSalary: number; existing: number } {
    const out = { created: 0, skippedNoSalary: 0, existing: 0 };
    const added: PayrollRecord[] = [];
    for (const e of employees) {
      if (this.exists(e.id, period)) { out.existing++; continue; }
      if (!(e.basicSalary > 0)) { out.skippedNoSalary++; continue; }
      const d = this.defaults(e.basicSalary);
      added.push({ id: uid('pay'), employeeId: e.id, period, basic: e.basicSalary, allowances: d.allowances, deductions: d.deductions,
        net: netSalary(e.basicSalary, d.allowances, d.deductions), status: 'Pending', createdAt: new Date().toISOString() });
      out.created++;
    }
    if (added.length) {
      this.persist([...this.items(), ...added]);
      this.activity.log('payroll', `Generated ${added.length} payroll entries for ${period}`);
    }
    return out;
  }

  setStatus(id: string, status: PayrollRecord['status'], employeeName: string): void {
    this.persist(this.items().map((p) => (p.id === id ? { ...p, status, paidOn: status === 'Paid' ? todayISO() : undefined } : p)));
    this.activity.log('payroll', `Marked ${employeeName}'s salary as ${status}`);
    if (status === 'Paid') this.notifier.notify('payroll', 'Salary marked as paid', `${employeeName} (demo status only)`);
  }
  remove(id: string): void { this.persist(this.items().filter((p) => p.id !== id)); }
  countFor(employeeId: string): number { return this.items().filter((p) => p.employeeId === employeeId).length; }
  removeForEmployee(employeeId: string): void { this.persist(this.items().filter((p) => p.employeeId !== employeeId)); }

  private persist(next: PayrollRecord[]): void {
    this.items.set(next);
    this.storage.set('payroll', next);
  }
}
