import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, catchError, map, of } from 'rxjs';
import { DEMO_CREDENTIALS } from '../models/defaults';
import { Result, UserSession } from '../models/models';
import { StorageService } from './storage.service';

/** Your existing practice API (kept from your original login). It is a REAL server call, unlike demo mode. */
export const PRACTICE_API_LOGIN = 'https://projectapi.gerasim.in/api/UserApp/login';

interface ApiLoginResponse {
  result?: boolean;
  message?: string;
  data?: { userId?: string; emailId?: string; userName?: string } | null;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private storage = inject(StorageService);
  private http = inject(HttpClient);
  private router = inject(Router);

  readonly session = signal<UserSession | null>(this.loadSession());
  readonly isLoggedIn = computed(() => this.session() !== null);

  private loadSession(): UserSession | null {
    const s = this.storage.get<Partial<UserSession> | null>('session', null);
    return s && typeof s.name === 'string' && typeof s.email === 'string'
      ? { name: s.name, email: s.email, role: s.role ?? 'HR Administrator', mode: s.mode ?? 'demo', loginAt: s.loginAt ?? '' }
      : null;
  }
  private start(s: UserSession): void {
    this.session.set(s);
    this.storage.set('session', s);
  }

  /**
   * DEMO LOGIN: compares against a fixed demo account that lives inside this app's source code.
   * It only exists so the frontend can run without a backend. It is NOT secure authentication.
   */
  loginDemo(email: string, password: string): Result {
    if (email.trim().toLowerCase() !== DEMO_CREDENTIALS.email || password !== DEMO_CREDENTIALS.password) {
      return { ok: false, error: 'Incorrect email or password. Use the demo account shown below the form.' };
    }
    this.start({ name: DEMO_CREDENTIALS.name, email: DEMO_CREDENTIALS.email, role: 'HR Administrator', mode: 'demo', loginAt: new Date().toISOString() });
    return { ok: true };
  }

  /** Your original API login, now with proper error handling. Needs internet; the API may reject or be offline. */
  loginApi(email: string, password: string): Observable<Result> {
    return this.http.post<ApiLoginResponse>(PRACTICE_API_LOGIN, { EmailId: email.trim(), Password: password }).pipe(
      map((res): Result => {
        if (res?.result === true && res.data) {
          const name = res.data.userName || res.data.userId || email.split('@')[0];
          this.start({ name, email: res.data.emailId || email.trim(), role: 'HR Administrator', mode: 'api', loginAt: new Date().toISOString() });
          return { ok: true };
        }
        return { ok: false, error: res?.message || 'Invalid email ID or password.' };
      }),
      catchError((err: { status?: number }) =>
        of<Result>({
          ok: false,
          error:
            err.status === 0 ? 'Cannot reach the API. Check your internet connection.'
            : err.status === 400 || err.status === 401 || err.status === 403 ? 'Invalid email ID or password.'
            : `Login request failed (HTTP ${err.status ?? 'unknown'}).`,
        }),
      ),
    );
  }

  updateName(name: string): void {
    const s = this.session();
    if (s && name.trim()) this.start({ ...s, name: name.trim() });
  }

  logout(): void {
    this.session.set(null);
    this.storage.remove('session');
    void this.router.navigateByUrl('/login');
  }
}
