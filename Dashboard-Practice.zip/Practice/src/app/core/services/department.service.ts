import { Injectable, inject, signal } from '@angular/core';
import { Department, Result } from '../models/models';
import { uid } from '../../shared/utils/date.utils';
import { ActivityService } from './activity.service';
import { EmployeeService } from './employee.service';
import { StorageService } from './storage.service';

export type DepartmentInput = Omit<Department, 'id' | 'createdAt'>;

@Injectable({ providedIn: 'root' })
export class DepartmentService {
  private storage = inject(StorageService);
  private employees = inject(EmployeeService);
  private activity = inject(ActivityService);

  readonly items = signal<Department[]>(this.storage.getArray<Department>('departments'));

  byId(id: string | null | undefined): Department | undefined { return this.items().find((d) => d.id === id); }
  nameOf(id: string | null | undefined): string { return this.byId(id)?.name ?? 'Unassigned'; }

  private duplicate(i: DepartmentInput, ignoreId?: string): string | null {
    for (const d of this.items()) {
      if (d.id === ignoreId) continue;
      if (d.name.toLowerCase() === i.name.trim().toLowerCase()) return `A department named "${d.name}" already exists.`;
      if (d.code.toLowerCase() === i.code.trim().toLowerCase()) return `Department code ${d.code} is already used.`;
    }
    return null;
  }

  create(i: DepartmentInput): Result<Department> {
    const dup = this.duplicate(i);
    if (dup) return { ok: false, error: dup };
    const dep: Department = { ...this.clean(i), id: uid('dep'), createdAt: new Date().toISOString() };
    this.persist([...this.items(), dep]);
    this.activity.log('department', `Created department ${dep.name}`);
    return { ok: true, value: dep };
  }

  update(id: string, i: DepartmentInput): Result<Department> {
    const cur = this.byId(id);
    if (!cur) return { ok: false, error: 'Department not found.' };
    const dup = this.duplicate(i, id);
    if (dup) return { ok: false, error: dup };
    const dep = { ...cur, ...this.clean(i) };
    this.persist(this.items().map((d) => (d.id === id ? dep : d)));
    this.activity.log('department', `Updated department ${dep.name}`);
    return { ok: true, value: dep };
  }

  /** A department that still has people cannot be deleted: reassign them first. */
  remove(id: string): Result {
    const dep = this.byId(id);
    if (!dep) return { ok: false, error: 'Department not found.' };
    const n = this.employees.countByDepartment(id);
    if (n > 0) return { ok: false, error: `${dep.name} still has ${n} employee(s). Reassign them to another department first.` };
    this.persist(this.items().filter((d) => d.id !== id));
    this.activity.log('department', `Deleted department ${dep.name}`);
    return { ok: true };
  }

  private clean(i: DepartmentInput): DepartmentInput {
    return { ...i, name: i.name.trim(), code: i.code.trim().toUpperCase(), description: i.description?.trim() || undefined, managerId: i.managerId || undefined };
  }
  private persist(next: Department[]): void {
    this.items.set(next);
    this.storage.set('departments', next);
  }
}
