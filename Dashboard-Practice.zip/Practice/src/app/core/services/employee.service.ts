import { Injectable, computed, inject, signal } from '@angular/core';
import { Employee, Result } from '../models/models';
import { uid } from '../../shared/utils/date.utils';
import { ActivityService } from './activity.service';
import { AttendanceService } from './attendance.service';
import { LeaveService } from './leave.service';
import { PayrollService } from './payroll.service';
import { StorageService } from './storage.service';

export type EmployeeInput = Omit<Employee, 'id' | 'createdAt'>;

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private storage = inject(StorageService);
  private activity = inject(ActivityService);
  private attendance = inject(AttendanceService);
  private leave = inject(LeaveService);
  private payroll = inject(PayrollService);

  readonly items = signal<Employee[]>(this.storage.getArray<Employee>('employees'));

  /** People who still work here (everyone except status "Inactive"). Used for attendance, payroll and headcount. */
  readonly active = computed(() => this.items().filter((e) => e.status !== 'Inactive'));

  byId(id: string | null | undefined): Employee | undefined { return this.items().find((e) => e.id === id); }
  countByDepartment(departmentId: string): number { return this.items().filter((e) => e.departmentId === departmentId).length; }

  /** Next free code like EMP-0013. */
  nextCode(): string {
    const max = this.items().reduce((m, e) => Math.max(m, Number(/(\d+)$/.exec(e.code)?.[1] ?? 0)), 0);
    return 'EMP-' + String(max + 1).padStart(4, '0');
  }

  private duplicate(input: EmployeeInput, ignoreId?: string): string | null {
    const code = input.code.trim().toLowerCase();
    const email = input.email.trim().toLowerCase();
    for (const e of this.items()) {
      if (e.id === ignoreId) continue;
      if (e.code.toLowerCase() === code) return `Employee ID ${input.code} is already used.`;
      if (e.email.toLowerCase() === email) return `Email ${input.email} already belongs to ${e.fullName}.`;
    }
    return null;
  }

  create(input: EmployeeInput): Result<Employee> {
    const dup = this.duplicate(input);
    if (dup) return { ok: false, error: dup };
    const emp: Employee = { ...this.clean(input), id: uid('emp'), createdAt: new Date().toISOString() };
    this.persist([...this.items(), emp]);
    this.activity.log('employee', `Added employee ${emp.fullName} (${emp.code})`);
    return { ok: true, value: emp };
  }

  update(id: string, input: EmployeeInput): Result<Employee> {
    const current = this.byId(id);
    if (!current) return { ok: false, error: 'Employee not found.' };
    const dup = this.duplicate(input, id);
    if (dup) return { ok: false, error: dup };
    const emp: Employee = { ...current, ...this.clean(input) };
    this.persist(this.items().map((e) => (e.id === id ? emp : e))); // other employees are untouched
    this.activity.log('employee', `Updated employee ${emp.fullName}`);
    return { ok: true, value: emp };
  }

  /** What would be removed together with this employee (shown in the delete confirmation). */
  relatedCounts(id: string): { attendance: number; leaves: number; payroll: number } {
    return { attendance: this.attendance.countFor(id), leaves: this.leave.countFor(id), payroll: this.payroll.countFor(id) };
  }

  /**
   * Delete policy: deleting an employee also deletes their attendance, leave and payroll records,
   * so no record is left pointing at a person who no longer exists. A department whose manager is deleted simply shows no manager.
   */
  remove(id: string): Result {
    const emp = this.byId(id);
    if (!emp) return { ok: false, error: 'Employee not found.' };
    this.attendance.removeForEmployee(id);
    this.leave.removeForEmployee(id);
    this.payroll.removeForEmployee(id);
    this.persist(this.items().filter((e) => e.id !== id));
    this.activity.log('employee', `Deleted employee ${emp.fullName} and related records`);
    return { ok: true };
  }

  private clean(i: EmployeeInput): EmployeeInput {
    return {
      ...i, code: i.code.trim().toUpperCase(), fullName: i.fullName.trim(), email: i.email.trim().toLowerCase(),
      phone: i.phone.trim(), designation: i.designation.trim(), basicSalary: Number(i.basicSalary) || 0,
      address: i.address?.trim() || undefined, emergencyContact: i.emergencyContact?.trim() || undefined,
    };
  }

  private persist(next: Employee[]): void {
    this.items.set(next);
    this.storage.set('employees', next);
  }
}
