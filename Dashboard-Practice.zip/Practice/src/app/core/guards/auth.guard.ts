import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Sends visitors without a saved demo session to /login.
 * A client-side guard only hides screens in the browser. It does NOT protect data: a real system
 * must check the user on the server for every request.
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.isLoggedIn() ? true : inject(Router).createUrlTree(['/login']);
};

/** The login page itself: if you are already signed in, go straight to Overview. */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.isLoggedIn() ? inject(Router).createUrlTree(['/overview']) : true;
};
