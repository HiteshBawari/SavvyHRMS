import { Component, computed, effect, inject, input, untracked } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { startWith } from 'rxjs';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SettingsService } from '../../../core/services/settings.service';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { signal } from '@angular/core';

@Component({
  selector: 'app-leave-form',
  imports: [ReactiveFormsModule, RouterLink, Icon, EmptyState],
  templateUrl: './leave-form.html',
})
export class LeaveForm {
  employeeId = input<string>(); // optional ?employeeId=... in the URL
  private fb = inject(FormBuilder);
  private leave = inject(LeaveService);
  private router = inject(Router);
  private notifier = inject(NotificationService);
  employees = inject(EmployeeService);
  settings = inject(SettingsService);
  formError = signal('');

  form = this.fb.nonNullable.group({
    employeeId: ['', Validators.required],
    type: ['', Validators.required],
    startDate: ['', Validators.required],
    endDate: ['', Validators.required],
    reason: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(300)]],
    notes: [''],
  }, { validators: [(g: AbstractControl): ValidationErrors | null => {
    const s = g.get('startDate')?.value as string; const e = g.get('endDate')?.value as string;
    return s && e && e < s ? { range: true } : null;
  }] });

  private value = toSignal(this.form.valueChanges.pipe(startWith(this.form.getRawValue())), { initialValue: this.form.getRawValue() });
  days = computed(() => this.leave.previewDays(this.value().startDate ?? '', this.value().endDate ?? ''));
  balance = computed(() => {
    const v = this.value();
    return v.employeeId && v.type && v.startDate ? this.leave.balance(v.employeeId, v.type, Number(v.startDate.slice(0, 4))) : null;
  });

  constructor() {
    effect(() => {
      const id = this.employeeId(); const types = this.settings.settings().leave.types;
      untracked(() => {
        if (id && this.employees.byId(id) && !this.form.controls.employeeId.value) this.form.controls.employeeId.setValue(id);
        if (!this.form.controls.type.value && types.length) this.form.controls.type.setValue(types[0].name);
      });
    });
  }

  invalid(n: string): boolean { const c = this.form.get(n); return !!c && c.invalid && (c.touched || c.dirty); }

  save(): void {
    this.formError.set('');
    if (this.form.invalid) { this.form.markAllAsTouched(); this.notifier.error('Please fix the highlighted fields.'); return; }
    const v = this.form.getRawValue();
    const emp = this.employees.byId(v.employeeId);
    if (!emp) { this.formError.set('Choose a valid employee.'); return; }
    const r = this.leave.create({ ...v, employeeName: emp.fullName });
    if (!r.ok) { this.formError.set(r.error ?? 'Could not save.'); this.notifier.error(r.error ?? 'Could not save.'); return; }
    this.notifier.success('Leave request submitted.');
    void this.router.navigate(['/leave', r.value?.id]);
  }
}
