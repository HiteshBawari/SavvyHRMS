import { Component, computed, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { formatDate, formatDateTime } from '../../../shared/utils/date.utils';
import { LeaveDecision } from '../leave-decision/leave-decision';

@Component({
  selector: 'app-leave-details',
  imports: [RouterLink, Icon, StatusBadge, EmptyState, ConfirmModal, LeaveDecision],
  templateUrl: './leave-details.html',
})
export class LeaveDetails {
  id = input<string>();
  private leaveSvc = inject(LeaveService);
  private employees = inject(EmployeeService);
  private notifier = inject(NotificationService);
  readonly fmt = formatDate; readonly fmtTime = formatDateTime;

  req = computed(() => this.leaveSvc.byId(this.id() ?? ''));
  emp = computed(() => this.employees.byId(this.req()?.employeeId));
  name = computed(() => this.emp()?.fullName ?? 'Deleted employee');
  action = signal<'Approved' | 'Rejected' | null>(null);
  askCancel = signal(false);
  balance = computed(() => { const r = this.req(); return r ? this.leaveSvc.balance(r.employeeId, r.type, Number(r.startDate.slice(0, 4))) : null; });

  cancel(): void {
    const r = this.req();
    if (!r) return;
    const res = this.leaveSvc.cancel(r.id, this.name());
    this.askCancel.set(false);
    if (res.ok) this.notifier.success('Request cancelled.'); else this.notifier.error(res.error ?? 'Could not cancel.');
  }
}
