import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { LeaveRequest } from '../../../core/models/models';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SettingsService } from '../../../core/services/settings.service';
import { Chart } from '../../../shared/components/chart/chart';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { Pagination } from '../../../shared/components/pagination/pagination';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { formatDate, todayISO } from '../../../shared/utils/date.utils';
import { LeaveDecision } from '../leave-decision/leave-decision';

@Component({
  selector: 'app-leave-dashboard',
  imports: [FormsModule, RouterLink, Icon, StatusBadge, EmptyState, Pagination, Chart, ConfirmModal, LeaveDecision],
  templateUrl: './leave-dashboard.html',
})
export class LeaveDashboard {
  leave = inject(LeaveService);
  employees = inject(EmployeeService);
  settings = inject(SettingsService);
  private notifier = inject(NotificationService);
  readonly fmt = formatDate;
  readonly statuses = ['Pending', 'Approved', 'Rejected', 'Cancelled'];

  employeeId = signal(''); type = signal(''); status = signal(''); from = signal(''); to = signal('');
  page = signal(1); pageSize = 8;
  decision = signal<{ leave: LeaveRequest; action: 'Approved' | 'Rejected' } | null>(null);
  toCancel = signal<LeaveRequest | null>(null);

  name = (id: string): string => this.employees.byId(id)?.fullName ?? 'Deleted employee';

  count = (s: string) => this.leave.items().filter((l) => l.status === s).length;
  onLeaveNow = computed(() => {
    const t = todayISO();
    return this.leave.items().filter((l) => l.status === 'Approved' && l.startDate <= t && t <= l.endDate);
  });
  byType = computed(() => {
    const types = this.settings.settings().leave.types.map((t) => t.name);
    const used = this.leave.items().filter((l) => l.status !== 'Cancelled');
    const extra = [...new Set(used.map((l) => l.type))].filter((t) => !types.includes(t));
    const names = [...types, ...extra];
    return { labels: names, values: names.map((n) => used.filter((l) => l.type === n).length) };
  });

  filtered = computed(() => this.leave.items().filter((l) =>
    (!this.employeeId() || l.employeeId === this.employeeId()) && (!this.type() || l.type === this.type()) && (!this.status() || l.status === this.status())
    && (!this.from() || l.endDate >= this.from()) && (!this.to() || l.startDate <= this.to()))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
  rows = computed(() => this.filtered().slice((this.page() - 1) * this.pageSize, this.page() * this.pageSize));
  hasFilter = computed(() => !!(this.employeeId() || this.type() || this.status() || this.from() || this.to()));

  setFilter(sig: { set(v: string): void }, v: string): void { sig.set(v); this.page.set(1); }
  clear(): void { this.employeeId.set(''); this.type.set(''); this.status.set(''); this.from.set(''); this.to.set(''); this.page.set(1); }

  confirmCancel(): void {
    const l = this.toCancel();
    if (!l) return;
    const r = this.leave.cancel(l.id, this.name(l.employeeId));
    this.toCancel.set(null);
    if (r.ok) this.notifier.success('Request cancelled.'); else this.notifier.error(r.error ?? 'Could not cancel.');
  }
}
