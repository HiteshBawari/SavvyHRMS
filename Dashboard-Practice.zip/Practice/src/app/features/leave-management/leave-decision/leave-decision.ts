import { AfterViewInit, Component, ElementRef, HostListener, computed, inject, input, output, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LeaveRequest } from '../../../core/models/models';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SettingsService } from '../../../core/services/settings.service';
import { formatDate } from '../../../shared/utils/date.utils';

/** Confirmation dialog used to approve or reject a leave request (with an optional decision note). */
@Component({
  selector: 'app-leave-decision',
  imports: [FormsModule],
  template: `
    <div class="modal-backdrop" (click)="closed.emit()">
      <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="ld-title" (click)="$event.stopPropagation()">
        <h2 id="ld-title">{{ action() === 'Approved' ? 'Approve' : 'Reject' }} leave request?</h2>
        <p class="muted">{{ employeeName() }} · {{ leave().type }} · {{ fmt(leave().startDate) }}
          @if (leave().endDate !== leave().startDate) { to {{ fmt(leave().endDate) }} } ({{ leave().days }} working day{{ leave().days === 1 ? '' : 's' }})</p>
        @if (action() === 'Approved') {
          <p class="small muted">Approved leave days will show as "Approved Leave" in attendance (no check-in or check-out times are created) and will not count as absences.</p>
        }
        <div class="field" style="margin-top:12px">
          <label for="ld-note" [class.req]="required()">Note {{ required() ? '' : '(optional)' }}</label>
          <textarea #noteBox id="ld-note" class="input" [ngModel]="note()" (ngModelChange)="note.set($event)" placeholder="Reason for this decision"></textarea>
        </div>
        @if (error()) { <div class="alert alert-error" role="alert" style="margin-top:12px">{{ error() }}</div> }
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" (click)="closed.emit()">Cancel</button>
          <button type="button" class="btn" [class.btn-success]="action() === 'Approved'" [class.btn-danger]="action() === 'Rejected'" (click)="confirm()">
            {{ action() === 'Approved' ? 'Approve request' : 'Reject request' }}
          </button>
        </div>
      </div>
    </div>`,
})
export class LeaveDecision implements AfterViewInit {
  leave = input.required<LeaveRequest>();
  action = input.required<'Approved' | 'Rejected'>();
  employeeName = input('');
  done = output<void>();
  closed = output<void>();

  private svc = inject(LeaveService);
  private settings = inject(SettingsService);
  private notifier = inject(NotificationService);
  private box = viewChild<ElementRef<HTMLTextAreaElement>>('noteBox');
  readonly fmt = formatDate;
  note = signal('');
  error = signal('');
  required = computed(() => this.settings.settings().leave.requireDecisionNote);

  ngAfterViewInit(): void { this.box()?.nativeElement.focus(); }
  @HostListener('document:keydown.escape') onEscape(): void { this.closed.emit(); }

  confirm(): void {
    const r = this.svc.decide(this.leave().id, this.action(), this.employeeName(), this.note());
    if (!r.ok) { this.error.set(r.error ?? 'Could not save the decision.'); return; }
    this.notifier.success(`Leave request ${this.action().toLowerCase()}.`);
    this.done.emit();
  }
}
