import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Employee } from '../../../core/models/models';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { Pagination } from '../../../shared/components/pagination/pagination';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { formatDate, initials } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';

type SortKey = 'code' | 'fullName' | 'email' | 'department' | 'designation' | 'joiningDate' | 'status';

@Component({
  selector: 'app-employee-list',
  imports: [FormsModule, RouterLink, Icon, StatusBadge, EmptyState, Pagination, ConfirmModal],
  templateUrl: './employee-list.html',
  styleUrl: './employee-list.css',
})
export class EmployeeList {
  private employees = inject(EmployeeService);
  private router = inject(Router);
  private notifier = inject(NotificationService);
  departments = inject(DepartmentService);

  readonly fmt = formatDate;
  readonly initials = initials;
  readonly colorFor = colorFor;
  readonly statuses = ['Active', 'Onboarding', 'On Notice', 'Inactive'];

  search = signal('');
  dept = signal('');
  status = signal('');
  sortKey = signal<SortKey>('code');
  sortDir = signal<'asc' | 'desc'>('asc');
  page = signal(1);
  pageSize = 8;
  toDelete = signal<Employee | null>(null);

  total = computed(() => this.employees.items().length);

  filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    const dir = this.sortDir() === 'asc' ? 1 : -1;
    const key = this.sortKey();
    const val = (e: Employee): string => (key === 'department' ? this.departments.nameOf(e.departmentId) : String(e[key]));
    return this.employees.items()
      .filter((e) => (!q || e.fullName.toLowerCase().includes(q) || e.code.toLowerCase().includes(q) || e.email.toLowerCase().includes(q))
        && (!this.dept() || e.departmentId === this.dept()) && (!this.status() || e.status === this.status()))
      .sort((a, b) => val(a).localeCompare(val(b), undefined, { numeric: true }) * dir);
  });
  rows = computed(() => this.filtered().slice((this.page() - 1) * this.pageSize, this.page() * this.pageSize));

  deleteDetails = computed(() => {
    const e = this.toDelete();
    if (!e) return [];
    const c = this.employees.relatedCounts(e.id);
    return [`${c.attendance} attendance record(s)`, `${c.leaves} leave request(s)`, `${c.payroll} payroll entr${c.payroll === 1 ? 'y' : 'ies'}`];
  });

  setSearch(v: string): void { this.search.set(v); this.page.set(1); }
  setDept(v: string): void { this.dept.set(v); this.page.set(1); }
  setStatus(v: string): void { this.status.set(v); this.page.set(1); }
  sortBy(k: SortKey): void {
    if (this.sortKey() === k) this.sortDir.update((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { this.sortKey.set(k); this.sortDir.set('asc'); }
  }
  ariaSort(k: SortKey): 'ascending' | 'descending' | 'none' { return this.sortKey() !== k ? 'none' : this.sortDir() === 'asc' ? 'ascending' : 'descending'; }
  clearFilters(): void { this.search.set(''); this.dept.set(''); this.status.set(''); this.page.set(1); }

  recordAttendance(e: Employee): void {
    void this.router.navigate(['/attendance/records'], { queryParams: { employeeId: e.id, add: 1 } });
  }
  confirmDelete(): void {
    const e = this.toDelete();
    if (!e) return;
    const r = this.employees.remove(e.id);
    this.toDelete.set(null);
    if (r.ok) {
      this.notifier.success(`${e.fullName} and related records were deleted.`);
      if (this.rows().length === 0 && this.page() > 1) this.page.update((p) => p - 1);
    } else this.notifier.error(r.error ?? 'Could not delete employee.');
  }
}
