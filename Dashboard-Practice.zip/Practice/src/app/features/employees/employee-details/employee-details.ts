import { Component, computed, inject, input, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AttendanceService } from '../../../core/services/attendance.service';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { PayrollService } from '../../../core/services/payroll.service';
import { SettingsService } from '../../../core/services/settings.service';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { formatDate, formatDuration, formatTime, initials, monthEnd, monthStart, periodLabel } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';

@Component({
  selector: 'app-employee-details',
  imports: [RouterLink, Icon, StatusBadge, EmptyState, ConfirmModal],
  templateUrl: './employee-details.html',
})
export class EmployeeDetails {
  id = input<string>();
  private employees = inject(EmployeeService);
  private attendance = inject(AttendanceService);
  private leave = inject(LeaveService);
  private payroll = inject(PayrollService);
  private router = inject(Router);
  private notifier = inject(NotificationService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);

  readonly fmt = formatDate; readonly time = formatTime; readonly dur = formatDuration; readonly period = periodLabel;
  readonly initials = initials; readonly colorFor = colorFor;
  confirmDelete = signal(false);

  emp = computed(() => this.employees.byId(this.id()));
  now = new Date();
  year = this.now.getFullYear();
  monthLabel = this.now.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  summary = computed(() => {
    const e = this.emp();
    return e ? this.attendance.summary(e, monthStart(this.year, this.now.getMonth() + 1), monthEnd(this.year, this.now.getMonth() + 1)) : null;
  });
  recent = computed(() => this.attendance.records().filter((r) => r.employeeId === this.id()).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6));
  requests = computed(() => this.leave.items().filter((l) => l.employeeId === this.id()).slice(0, 4));
  balances = computed(() => this.settings.settings().leave.types.map((t) => ({ name: t.name, ...this.leave.balance(this.id() ?? '', t.name, this.year) })));
  pay = computed(() => this.payroll.items().filter((p) => p.employeeId === this.id()).sort((a, b) => b.period.localeCompare(a.period)).slice(0, 3));
  counts = computed(() => (this.emp() ? this.employees.relatedCounts(this.emp()!.id) : { attendance: 0, leaves: 0, payroll: 0 }));
  deleteDetails = computed(() => [`${this.counts().attendance} attendance record(s)`, `${this.counts().leaves} leave request(s)`, `${this.counts().payroll} payroll entr${this.counts().payroll === 1 ? 'y' : 'ies'}`]);

  remove(): void {
    const e = this.emp();
    if (!e) return;
    const r = this.employees.remove(e.id);
    this.confirmDelete.set(false);
    if (r.ok) { this.notifier.success(`${e.fullName} was deleted.`); void this.router.navigateByUrl('/employees'); }
    else this.notifier.error(r.error ?? 'Could not delete.');
  }
}
