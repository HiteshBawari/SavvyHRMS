import { Component, computed, effect, inject, input, signal, untracked } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { EmployeeStatus, EmploymentType } from '../../../core/models/models';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeInput, EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { isISODate } from '../../../shared/utils/date.utils';
import { EMAIL_PATTERN, PHONE_PATTERN } from '../../../shared/utils/format.utils';

/** One form for both "Add employee" (/employees/new) and "Edit employee" (/employees/:id/edit). */
@Component({
  selector: 'app-employee-form',
  imports: [ReactiveFormsModule, RouterLink, Icon, EmptyState],
  templateUrl: './employee-form.html',
})
export class EmployeeForm {
  id = input<string>(); // filled from the :id route parameter
  private fb = inject(FormBuilder);
  private employees = inject(EmployeeService);
  private router = inject(Router);
  private notifier = inject(NotificationService);
  departments = inject(DepartmentService);

  readonly types: EmploymentType[] = ['Full-time', 'Part-time', 'Contract', 'Intern'];
  readonly statuses: EmployeeStatus[] = ['Active', 'Onboarding', 'On Notice', 'Inactive'];
  isEdit = computed(() => !!this.id());
  notFound = signal(false);
  formError = signal('');
  private loadedId: string | undefined;

  form = this.fb.nonNullable.group({
    code: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9-]{3,20}$/), (c: AbstractControl) => this.unique(c, 'code')]],
    fullName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(80)]],
    email: ['', [Validators.required, Validators.pattern(EMAIL_PATTERN), (c: AbstractControl) => this.unique(c, 'email')]],
    phone: ['', [Validators.required, Validators.pattern(PHONE_PATTERN)]],
    departmentId: ['', Validators.required],
    designation: ['', [Validators.required, Validators.maxLength(60)]],
    joiningDate: ['', [Validators.required, (c: AbstractControl) => (c.value && !isISODate(c.value) ? { date: true } : null)]],
    employmentType: ['Full-time' as EmploymentType, Validators.required],
    status: ['Active' as EmployeeStatus, Validators.required],
    basicSalary: [0, [Validators.required, Validators.min(0), Validators.max(100000000)]],
    address: [''],
    emergencyContact: [''],
  });

  constructor() {
    effect(() => {
      const id = this.id();
      const list = this.employees.items(); // re-run if data changes
      untracked(() => {
        if (!id) {
          if (this.loadedId !== '') { this.loadedId = ''; this.form.reset({ ...this.form.getRawValue(), code: this.employees.nextCode(), fullName: '', email: '', phone: '', departmentId: '', designation: '', joiningDate: '', employmentType: 'Full-time', status: 'Active', basicSalary: 0, address: '', emergencyContact: '' }); }
          return;
        }
        if (this.loadedId === id) return;
        const e = list.find((x) => x.id === id);
        if (!e) { this.notFound.set(true); return; }
        this.notFound.set(false);
        this.loadedId = id;
        this.form.reset({ ...e, address: e.address ?? '', emergencyContact: e.emergencyContact ?? '' });
      });
    });
  }

  private unique(c: AbstractControl, field: 'code' | 'email'): ValidationErrors | null {
    const v = String(c.value ?? '').trim().toLowerCase();
    if (!v) return null;
    const clash = this.employees.items().some((e) => e.id !== this.id() && e[field].toLowerCase() === v);
    return clash ? { duplicate: true } : null;
  }

  invalid(name: string): boolean {
    const c = this.form.get(name);
    return !!c && c.invalid && (c.touched || c.dirty);
  }
  err(name: string): string {
    const e = this.form.get(name)?.errors;
    if (!e) return '';
    if (e['required']) return 'This field is required.';
    if (e['duplicate']) return name === 'code' ? 'This employee ID is already used.' : 'This email already belongs to another employee.';
    if (e['pattern']) return name === 'email' ? 'Enter a valid email address.' : name === 'phone' ? 'Enter a valid phone number (digits, optional + and spaces).' : 'Use letters, numbers and dashes only (3-20 characters).';
    if (e['min'] || e['max']) return 'Enter a valid amount.';
    if (e['minlength']) return 'Too short.';
    if (e['maxlength']) return 'Too long.';
    if (e['date']) return 'Enter a valid date.';
    return 'Invalid value.';
  }

  save(): void {
    this.formError.set('');
    if (this.form.invalid) { this.form.markAllAsTouched(); this.notifier.error('Please fix the highlighted fields.'); return; }
    const value = this.form.getRawValue() as EmployeeInput;
    const r = this.isEdit() ? this.employees.update(this.id() as string, value) : this.employees.create(value);
    if (!r.ok) { this.formError.set(r.error ?? 'Could not save.'); this.notifier.error(r.error ?? 'Could not save.'); return; }
    this.notifier.success(this.isEdit() ? 'Employee updated.' : 'Employee added.');
    void this.router.navigate(['/employees', r.value?.id]);
  }
}
