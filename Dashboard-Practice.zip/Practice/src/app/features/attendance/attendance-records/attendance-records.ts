import { Component, computed, effect, inject, input, signal, untracked } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AttendanceStatus, Employee } from '../../../core/models/models';
import { AttendanceService } from '../../../core/services/attendance.service';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { AttendanceSummary, DayInfo, addSummary, emptySummary, percentOf } from '../../../shared/utils/attendance.calc';
import { Chart } from '../../../shared/components/chart/chart';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { MONTH_NAMES, MONTH_SHORT, WEEKDAY_SHORT, daysInMonth, formatDate, formatDuration, formatTime, monthEnd, monthStart, pad, todayISO, weekday } from '../../../shared/utils/date.utils';

type View = 'daily' | 'monthly' | 'yearly';
const CODE: Record<string, string> = { Present: 'P', Absent: 'A', 'Half Day': 'H', 'Approved Leave': 'L', Sunday: 'S', 'Weekly Off': 'W', Holiday: 'Ho' };

@Component({
  selector: 'app-attendance-records',
  imports: [FormsModule, ReactiveFormsModule, RouterLink, Icon, StatusBadge, EmptyState, ConfirmModal, Chart],
  templateUrl: './attendance-records.html',
  styleUrl: './attendance-records.css',
})
export class AttendanceRecords {
  // Optional URL parameters, e.g. /attendance/records?employeeId=...&view=monthly&add=1
  employeeIdParam = input<string | undefined>(undefined, { alias: 'employeeId' });
  viewParam = input<string | undefined>(undefined, { alias: 'view' });
  addParam = input<string | undefined>(undefined, { alias: 'add' });

  private fb = inject(FormBuilder);
  private attendance = inject(AttendanceService);
  employees = inject(EmployeeService);
  departments = inject(DepartmentService);
  private notifier = inject(NotificationService);

  readonly time = formatTime; readonly dur = formatDuration; readonly fmt = formatDate;
  readonly months = MONTH_NAMES; readonly code = CODE;
  readonly now = new Date();
  readonly todayStr = todayISO();
  readonly years = Array.from({ length: 6 }, (_, i) => this.now.getFullYear() - 4 + i);

  view = signal<View>('daily');
  date = signal(todayISO());
  month = signal(this.now.getMonth() + 1);
  year = signal(this.now.getFullYear());
  employeeId = signal('');
  dept = signal('');

  editor = signal<{ id?: string } | null>(null);
  editorError = signal('');
  toDelete = signal<{ id: string; name: string; date: string } | null>(null);

  form = this.fb.nonNullable.group({
    employeeId: ['', Validators.required],
    date: [todayISO(), Validators.required],
    status: ['Present' as AttendanceStatus, Validators.required],
    checkIn: [''], checkOut: [''], remarks: [''],
  });

  constructor() {
    effect(() => {
      const emp = this.employeeIdParam(); const v = this.viewParam(); const add = this.addParam();
      untracked(() => {
        if (emp) this.employeeId.set(emp);
        if (v === 'daily' || v === 'monthly' || v === 'yearly') this.view.set(v);
        if (add && emp) this.openEditor({ employeeId: emp, date: todayISO() });
        else if (add) this.openEditor({});
      });
    });
  }

  /** Employees matching the filters. Inactive people only appear if chosen explicitly. */
  list = computed<Employee[]>(() => this.employees.items()
    .filter((e) => (this.employeeId() ? e.id === this.employeeId() : e.status !== 'Inactive') && (!this.dept() || e.departmentId === this.dept()))
    .sort((a, b) => a.fullName.localeCompare(b.fullName)));
  selected = computed(() => this.employees.byId(this.employeeId()));

  // ---------- Daily ----------
  daily = computed(() => this.list().map((e) => ({ emp: e, info: this.attendance.day(e, this.date()) })));

  // ---------- Monthly ----------
  dates = computed(() => Array.from({ length: daysInMonth(this.year(), this.month()) }, (_, i) => `${this.year()}-${pad(this.month())}-${pad(i + 1)}`));
  dayHead = computed(() => this.dates().map((d) => ({ d, n: Number(d.slice(8)), w: WEEKDAY_SHORT[weekday(d)].charAt(0), off: weekday(d) === 0 })));
  monthly = computed(() => this.list().map((e) => ({
    emp: e,
    days: this.dates().map((d) => this.attendance.day(e, d)),
    sum: this.attendance.summary(e, monthStart(this.year(), this.month()), monthEnd(this.year(), this.month())),
  })));
  /** One employee, one row per calendar day. In/Out stay blank unless a real record exists. */
  dayTable = computed(() => (this.selected() ? this.monthly().find((m) => m.emp.id === this.selected()?.id)?.days ?? [] : []));

  // ---------- Yearly ----------
  yearly = computed(() => this.list().map((e) => {
    const perMonth = Array.from({ length: 12 }, (_, i) => this.attendance.summary(e, monthStart(this.year(), i + 1), monthEnd(this.year(), i + 1)));
    const total = perMonth.reduce(addSummary, emptySummary());
    total.percent = percentOf(total, this.attendance.ctx().att.countNoRecordAsAbsent);
    return { emp: e, perMonth, total };
  }));
  yearChart = computed(() => {
    const per = Array.from({ length: 12 }, (_, m) => this.yearly().reduce((acc, r) => addSummary(acc, r.perMonth[m]), emptySummary()));
    const countNo = this.attendance.ctx().att.countNoRecordAsAbsent;
    return { labels: MONTH_SHORT, series: [{ name: 'Attendance %', color: '#7655E8', values: per.map((s) => percentOf(s, countNo) ?? 0) }] };
  });

  setView(v: View): void { this.view.set(v); }
  cellClass(k: string): string { return 'c-' + k.toLowerCase().replace(/\s+/g, '-'); }
  cellTip(d: DayInfo): string {
    const r = d.record;
    return `${formatDate(d.date)} · ${d.kind}${d.label ? ' (' + d.label + ')' : ''}${r?.checkIn ? ' · In ' + formatTime(r.checkIn) : ''}${r?.checkOut ? ' · Out ' + formatTime(r.checkOut) : ''}`;
  }
  hours(s: AttendanceSummary): string { return formatDuration(s.minutes) || '0h 00m'; }
  pct(s: AttendanceSummary): string { return s.percent === null ? '—' : s.percent + '%'; }
  dayLabel(d: string): string { return WEEKDAY_SHORT[weekday(d)]; }
  monthlyLate = computed(() => this.monthly().reduce((n, m) => n + m.sum.late, 0));

  // ---------- Add / edit ----------
  openEditor(init: { id?: string; employeeId?: string; date?: string }): void {
    this.editorError.set('');
    const rec = init.id ? this.attendance.records().find((r) => r.id === init.id) : undefined;
    this.form.reset({
      employeeId: rec?.employeeId ?? init.employeeId ?? this.employeeId() ?? '',
      date: rec?.date ?? init.date ?? this.date(),
      status: rec?.status ?? 'Present', checkIn: rec?.checkIn ?? '', checkOut: rec?.checkOut ?? '', remarks: rec?.remarks ?? '',
    });
    this.editor.set({ id: rec?.id });
  }
  editCell(emp: Employee, d: DayInfo): void {
    if (d.record) this.openEditor({ id: d.record.id }); else this.openEditor({ employeeId: emp.id, date: d.date });
  }
  saveEditor(): void {
    this.editorError.set('');
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.getRawValue();
    const emp = this.employees.byId(v.employeeId);
    if (!emp) { this.editorError.set('Choose a valid employee.'); return; }
    const r = this.attendance.save({ id: this.editor()?.id, ...v }, emp);
    if (!r.ok) { this.editorError.set(r.error ?? 'Could not save.'); return; }
    this.notifier.success(this.editor()?.id ? 'Attendance updated.' : 'Attendance saved.');
    this.editor.set(null);
  }
  askDelete(id: string, name: string, date: string): void { this.toDelete.set({ id, name, date }); }
  confirmDelete(): void {
    const t = this.toDelete();
    if (t) { this.attendance.remove(t.id, t.name); this.notifier.success('Attendance record deleted.'); }
    this.toDelete.set(null);
  }
}
