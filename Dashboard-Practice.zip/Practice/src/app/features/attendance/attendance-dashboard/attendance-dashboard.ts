import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Employee } from '../../../core/models/models';
import { AttendanceService } from '../../../core/services/attendance.service';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SettingsService } from '../../../core/services/settings.service';
import { Chart } from '../../../shared/components/chart/chart';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { addDays, formatDuration, formatTime, initials, todayISO, WEEKDAY_SHORT, weekday } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';

@Component({
  selector: 'app-attendance-dashboard',
  imports: [FormsModule, RouterLink, Icon, StatusBadge, EmptyState, Chart],
  templateUrl: './attendance-dashboard.html',
})
export class AttendanceDashboard {
  private attendance = inject(AttendanceService);
  employees = inject(EmployeeService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);
  private notifier = inject(NotificationService);

  readonly time = formatTime; readonly dur = formatDuration; readonly initials = initials; readonly colorFor = colorFor;
  today = todayISO();
  todayLabel = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  search = signal('');
  dept = signal('');

  stats = computed(() => this.attendance.dailyStats(this.employees.active(), this.today));
  rate = computed(() => { const s = this.stats(); const d = s.present + s.half + s.absent; return d ? Math.round(((s.present + s.half * 0.5) / d) * 1000) / 10 : null; });
  late = computed(() => this.roster().filter((r) => r.info.late).length);

  roster = computed(() => {
    const q = this.search().trim().toLowerCase();
    return this.employees.active()
      .filter((e) => (!q || e.fullName.toLowerCase().includes(q) || e.code.toLowerCase().includes(q)) && (!this.dept() || e.departmentId === this.dept()))
      .map((e) => ({ emp: e, info: this.attendance.day(e, this.today) }));
  });

  /** Last 7 days, stacked: present+half, absent, on leave. Non-working days show no bars. */
  week = computed(() => {
    const days = Array.from({ length: 7 }, (_, i) => addDays(this.today, i - 6));
    const stats = days.map((d) => this.attendance.dailyStats(this.employees.active(), d));
    return {
      labels: days.map((d) => WEEKDAY_SHORT[weekday(d)]),
      series: [
        { name: 'Present', color: '#38A982', values: stats.map((s) => s.present + s.half) },
        { name: 'Absent', color: '#E05A67', values: stats.map((s) => s.absent) },
        { name: 'On leave', color: '#E8A54B', values: stats.map((s) => s.leave) },
      ],
    };
  });

  checkIn(e: Employee): void { this.report(this.attendance.checkIn(e), `${e.fullName} checked in.`); }
  checkOut(e: Employee): void { this.report(this.attendance.checkOut(e), `${e.fullName} checked out.`); }
  mark(e: Employee, status: 'Present' | 'Absent' | 'Half Day'): void { this.report(this.attendance.mark(e, this.today, status), `${e.fullName} marked ${status.toLowerCase()}.`); }
  private report(r: { ok: boolean; error?: string }, okMsg: string): void { if (r.ok) this.notifier.success(okMsg); else this.notifier.error(r.error ?? 'Could not save.'); }
}
