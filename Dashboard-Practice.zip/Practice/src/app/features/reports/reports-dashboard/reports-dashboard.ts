import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AttendanceService } from '../../../core/services/attendance.service';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { PayrollService } from '../../../core/services/payroll.service';
import { SettingsService } from '../../../core/services/settings.service';
import { addSummary, emptySummary, percentOf } from '../../../shared/utils/attendance.calc';
import { Chart } from '../../../shared/components/chart/chart';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { MONTH_SHORT, monthEnd, monthStart} from '../../../shared/utils/date.utils';

@Component({
  selector: 'app-reports-dashboard',
  imports: [FormsModule, Chart, EmptyState, Icon],
  templateUrl: './reports-dashboard.html',
})
export class ReportsDashboard {
  private attendance = inject(AttendanceService);
  private leave = inject(LeaveService);
  private payroll = inject(PayrollService);
  employees = inject(EmployeeService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);

  readonly nowY = new Date().getFullYear();
  readonly years = Array.from({ length: 5 }, (_, i) => this.nowY - 3 + i);
  year = signal(this.nowY);
  dept = signal('');

  /** Employees included in the report (department filter). */
  scope = computed(() => this.employees.items().filter((e) => !this.dept() || e.departmentId === this.dept()));
  activeScope = computed(() => this.scope().filter((e) => e.status !== 'Inactive'));
  private inScope = (employeeId: string): boolean => this.scope().some((e) => e.id === employeeId);

  headcount = computed(() => ({ total: this.scope().length, active: this.activeScope().length, inactive: this.scope().length - this.activeScope().length }));

  byDept = computed(() => {
    const rows = this.departments.items().filter((d) => !this.dept() || d.id === this.dept()).map((d) => ({ n: d.name, v: this.employees.items().filter((e) => e.departmentId === d.id).length })).filter((r) => r.v > 0);
    return { labels: rows.map((r) => r.n), values: rows.map((r) => r.v) };
  });
  statusChart = computed(() => {
    const names = ['Active', 'Onboarding', 'On Notice', 'Inactive'];
    return { labels: names, values: names.map((n) => this.scope().filter((e) => e.status === n).length) };
  });
  newByMonth = computed(() => ({ labels: MONTH_SHORT, series: [{ name: 'New employees', values: MONTH_SHORT.map((_, i) => this.scope().filter((e) => e.joiningDate.startsWith(`${this.year()}-${String(i + 1).padStart(2, '0')}`)).length) }] }));

  /** Per-month attendance totals for the selected year (only past/current months have data). */
  monthly = computed(() => Array.from({ length: 12 }, (_, i) => {
    const sum = this.activeScope().reduce((acc, e) => addSummary(acc, this.attendance.summary(e, monthStart(this.year(), i + 1), monthEnd(this.year(), i + 1))), emptySummary());
    return { sum, pct: percentOf(sum, this.settings.settings().attendance.countNoRecordAsAbsent) };
  }));
  attendanceTrend = computed(() => ({ labels: MONTH_SHORT, series: [{ name: 'Attendance %', color: '#7655E8', values: this.monthly().map((m) => m.pct ?? 0) }] }));
  absenceLeave = computed(() => ({ labels: MONTH_SHORT, series: [
    { name: 'Absent days', color: '#E05A67', values: this.monthly().map((m) => m.sum.absent) },
    { name: 'Approved leave days', color: '#E8A54B', values: this.monthly().map((m) => m.sum.leave) },
  ] }));
  hasAttendance = computed(() => this.monthly().some((m) => m.pct !== null));

  leaveStatus = computed(() => {
    const names = ['Pending', 'Approved', 'Rejected', 'Cancelled'];
    const items = this.leave.items().filter((l) => this.inScope(l.employeeId) && l.startDate.startsWith(String(this.year())));
    return { labels: names, values: names.map((n) => items.filter((l) => l.status === n).length) };
  });

  payrollByMonth = computed(() => ({ labels: MONTH_SHORT, series: [{ name: 'Net payroll', values: MONTH_SHORT.map((_, i) => this.payroll.items()
    .filter((p) => p.period === `${this.year()}-${String(i + 1).padStart(2, '0')}` && this.inScope(p.employeeId)).reduce((n, p) => n + p.net, 0)) }] }));
  payrollByDept = computed(() => {
    const rows = this.departments.items().map((d) => ({ n: d.name, v: this.payroll.items().filter((p) => p.period.startsWith(String(this.year())) && this.employees.byId(p.employeeId)?.departmentId === d.id).reduce((s, p) => s + p.net, 0) }))
      .filter((r) => r.v > 0 && (!this.dept() || this.departments.items().find((d) => d.name === r.n)?.id === this.dept()));
    return { labels: rows.map((r) => r.n), values: rows.map((r) => r.v) };
  });
  payrollYearTotal = computed(() => this.payrollByMonth().series[0].values.reduce((a, b) => a + b, 0));
  readonly sumFn = (a: number, b: number): number => a + b;
}
