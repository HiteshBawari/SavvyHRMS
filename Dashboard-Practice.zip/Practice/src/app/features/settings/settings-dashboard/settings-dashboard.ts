import { Component, computed, inject, signal } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { LeaveType } from '../../../core/models/models';
import { AuthService } from '../../../core/services/auth.service';
import { DemoDataService } from '../../../core/services/demo-data.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { AttendanceService } from '../../../core/services/attendance.service';
import { LeaveService } from '../../../core/services/leave.service';
import { NotificationService } from '../../../core/services/notification.service';
import { PayrollService } from '../../../core/services/payroll.service';
import { SettingsService } from '../../../core/services/settings.service';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { Icon } from '../../../shared/components/icon/icon';
import { formatDate, isISODate, timeToMinutes } from '../../../shared/utils/date.utils';
import { EMAIL_PATTERN } from '../../../shared/utils/format.utils';

type Tab = 'general' | 'attendance' | 'leave' | 'payroll' | 'profile' | 'data';

@Component({
  selector: 'app-settings-dashboard',
  imports: [ReactiveFormsModule, FormsModule, Icon, ConfirmModal],
  templateUrl: './settings-dashboard.html',
})
export class SettingsDashboard {
  private fb = inject(FormBuilder);
  settings = inject(SettingsService);
  private auth = inject(AuthService);
  private demo = inject(DemoDataService);
  private notifier = inject(NotificationService);
  private employees = inject(EmployeeService);
  private attendance = inject(AttendanceService);
  private leave = inject(LeaveService);
  private payroll = inject(PayrollService);

  readonly fmt = formatDate;
  readonly tabs: { id: Tab; label: string }[] = [
    { id: 'general', label: 'General' }, { id: 'attendance', label: 'Attendance' }, { id: 'leave', label: 'Leave' },
    { id: 'payroll', label: 'Payroll' }, { id: 'profile', label: 'Profile & app' }, { id: 'data', label: 'Data' },
  ];
  readonly weekdays = [{ n: 1, l: 'Mon' }, { n: 2, l: 'Tue' }, { n: 3, l: 'Wed' }, { n: 4, l: 'Thu' }, { n: 5, l: 'Fri' }, { n: 6, l: 'Sat' }, { n: 0, l: 'Sun' }];
  readonly currencies = ['INR', 'USD', 'EUR', 'GBP', 'AED'];
  tab = signal<Tab>('general');
  confirm = signal<'clear' | 'reset' | null>(null);
  s = this.settings.settings;

  // ----- General -----
  general = this.fb.nonNullable.group({
    companyName: [this.s().general.companyName, [Validators.required, Validators.maxLength(60)]],
    email: [this.s().general.email, [Validators.required, Validators.pattern(EMAIL_PATTERN)]],
    phone: [this.s().general.phone, Validators.required],
    address: [this.s().general.address],
    initials: [this.s().general.initials, [Validators.required, Validators.maxLength(3)]],
    openPositions: [this.s().general.openPositions, [Validators.required, Validators.min(0)]],
    showActivity: [this.s().general.showActivity],
    showHolidays: [this.s().general.showHolidays],
  });
  saveGeneral(): void {
    if (this.general.invalid) { this.general.markAllAsTouched(); return; }
    const v = this.general.getRawValue();
    this.settings.patch('general', { ...v, initials: v.initials.toUpperCase() });
    this.notifier.success('General settings saved.');
  }

  // ----- Attendance -----
  att = this.fb.nonNullable.group({
    shiftStart: [this.s().attendance.shiftStart, Validators.required],
    shiftEnd: [this.s().attendance.shiftEnd, Validators.required],
    graceMinutes: [this.s().attendance.graceMinutes, [Validators.required, Validators.min(0), Validators.max(240)]],
    allowOvernight: [this.s().attendance.allowOvernight],
    countNoRecordAsAbsent: [this.s().attendance.countNoRecordAsAbsent],
  });
  workingDays = signal<number[]>([...this.s().attendance.workingDays]);
  attError = signal('');
  toggleDay(n: number): void { this.workingDays.update((d) => (d.includes(n) ? d.filter((x) => x !== n) : [...d, n].sort())); }
  saveAttendance(): void {
    this.attError.set('');
    const v = this.att.getRawValue();
    if (this.att.invalid) { this.att.markAllAsTouched(); return; }
    if (this.workingDays().length === 0) { this.attError.set('Choose at least one working day.'); return; }
    if (!v.allowOvernight && timeToMinutes(v.shiftEnd) <= timeToMinutes(v.shiftStart)) { this.attError.set('Shift end must be after shift start (or enable overnight shifts).'); return; }
    this.settings.patch('attendance', { ...v, workingDays: this.workingDays() });
    this.notifier.success('Attendance settings saved. All attendance screens now use them.');
  }
  hol = this.fb.nonNullable.group({ date: ['', Validators.required], name: ['', [Validators.required, Validators.maxLength(60)]], type: ['Company' as 'Public' | 'Company'] });
  addHoliday(): void {
    if (this.hol.invalid || !isISODate(this.hol.controls.date.value)) { this.hol.markAllAsTouched(); return; }
    const v = this.hol.getRawValue();
    const r = this.settings.addHoliday(v.date, v.name, v.type);
    if (r.ok) { this.notifier.success('Holiday added.'); this.hol.reset({ date: '', name: '', type: 'Company' }); } else this.notifier.error(r.error ?? 'Could not add.');
  }
  removeHoliday(id: string): void { this.settings.removeHoliday(id); this.notifier.success('Holiday removed.'); }

  // ----- Leave -----
  types = signal<LeaveType[]>(this.s().leave.types.map((t) => ({ ...t })));
  requireNote = signal(this.s().leave.requireDecisionNote);
  leaveError = signal('');
  setType(i: number, patch: Partial<LeaveType>): void { this.types.update((t) => t.map((x, j) => (j === i ? { ...x, ...patch } : x))); }
  setQuota(i: number, v: string): void { const n = v === '' ? null : Math.max(0, Math.floor(Number(v))); this.setType(i, { annualQuota: n === null || isNaN(n) ? null : n }); }
  addType(): void { this.types.update((t) => [...t, { name: '', annualQuota: null, paid: true }]); }
  removeType(i: number): void { this.types.update((t) => t.filter((_, j) => j !== i)); }
  saveLeave(): void {
    this.leaveError.set('');
    const names = this.types().map((t) => t.name.trim());
    if (names.length === 0) { this.leaveError.set('Keep at least one leave type.'); return; }
    if (names.some((n) => !n)) { this.leaveError.set('Every leave type needs a name.'); return; }
    if (new Set(names.map((n) => n.toLowerCase())).size !== names.length) { this.leaveError.set('Leave type names must be unique.'); return; }
    this.settings.patch('leave', { types: this.types().map((t, i) => ({ ...t, name: names[i] })), requireDecisionNote: this.requireNote() });
    this.notifier.success('Leave settings saved.');
  }

  // ----- Payroll -----
  pay = this.fb.nonNullable.group({
    currency: [this.s().payroll.currency, Validators.required],
    allowancePercent: [this.s().payroll.allowancePercent, [Validators.required, Validators.min(0), Validators.max(100)]],
    deductionPercent: [this.s().payroll.deductionPercent, [Validators.required, Validators.min(0), Validators.max(100)]],
  });
  savePayroll(): void {
    if (this.pay.invalid) { this.pay.markAllAsTouched(); return; }
    this.settings.patch('payroll', this.pay.getRawValue());
    this.notifier.success('Payroll settings saved. They apply to newly generated entries.');
  }

  // ----- Profile & app -----
  profileName = signal(this.auth.session()?.name ?? '');
  user = this.auth.session;
  prefs = this.fb.nonNullable.group({
    theme: [this.s().preferences.theme as 'light' | 'dark'],
    notifyLeave: [this.s().preferences.notifyLeave], notifyAttendance: [this.s().preferences.notifyAttendance], notifyPayroll: [this.s().preferences.notifyPayroll],
  });
  saveProfile(): void {
    if (!this.profileName().trim()) { this.notifier.error('Name cannot be empty.'); return; }
    this.auth.updateName(this.profileName());
    this.settings.patch('preferences', this.prefs.getRawValue());
    this.notifier.success('Profile and preferences saved.');
  }

  // ----- Data -----
  counts = computed(() => ({
    employees: this.employees.items().length, attendance: this.attendance.records().length,
    leaves: this.leave.items().length, payroll: this.payroll.items().length, holidays: this.settings.holidays().length,
  }));
  run(): void {
    const c = this.confirm();
    if (c === 'clear') this.demo.clearDemoData(); else if (c === 'reset') this.demo.resetAll();
    this.confirm.set(null);
    location.assign('/overview'); // reload so every service re-reads storage
  }
  /** Reads the text of an input event without using `any`. */
  value(e: Event): string { return (e.target as HTMLInputElement).value; }
}
