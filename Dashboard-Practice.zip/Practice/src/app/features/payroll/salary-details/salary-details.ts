import { Component, computed, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { PayrollService } from '../../../core/services/payroll.service';
import { SettingsService } from '../../../core/services/settings.service';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { formatDate, periodLabel } from '../../../shared/utils/date.utils';

@Component({
  selector: 'app-salary-details',
  imports: [RouterLink, Icon, StatusBadge, EmptyState],
  templateUrl: './salary-details.html',
})
export class SalaryDetails {
  id = input<string>();
  private payroll = inject(PayrollService);
  private employees = inject(EmployeeService);
  private notifier = inject(NotificationService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);
  readonly label = periodLabel; readonly fmt = formatDate;

  rec = computed(() => this.payroll.byId(this.id() ?? ''));
  emp = computed(() => this.employees.byId(this.rec()?.employeeId));
  gross = computed(() => (this.rec() ? this.rec()!.basic + this.rec()!.allowances : 0));

  setStatus(s: 'Paid' | 'Pending'): void {
    const r = this.rec();
    if (!r) return;
    this.payroll.setStatus(r.id, s, this.emp()?.fullName ?? 'employee');
    this.notifier.success(`Marked as ${s.toLowerCase()} (demo status only).`);
  }
}
