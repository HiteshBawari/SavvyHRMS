import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PayrollRecord } from '../../../core/models/models';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { PayrollService } from '../../../core/services/payroll.service';
import { SettingsService } from '../../../core/services/settings.service';
import { Chart } from '../../../shared/components/chart/chart';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { MONTH_SHORT, formatDate, periodLabel, todayISO } from '../../../shared/utils/date.utils';

@Component({
  selector: 'app-payroll-dashboard',
  imports: [FormsModule, ReactiveFormsModule, RouterLink, Icon, StatusBadge, EmptyState, ConfirmModal, Chart],
  templateUrl: './payroll-dashboard.html',
})
export class PayrollDashboard {
  private fb = inject(FormBuilder);
  payroll = inject(PayrollService);
  employees = inject(EmployeeService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);
  private notifier = inject(NotificationService);

  readonly label = periodLabel; readonly fmt = formatDate;
  period = signal(todayISO().slice(0, 7));
  search = signal(''); dept = signal(''); status = signal('');
  editor = signal(false);
  editorError = signal('');
  toDelete = signal<PayrollRecord | null>(null);

  form = this.fb.nonNullable.group({
    employeeId: ['', Validators.required],
    period: [todayISO().slice(0, 7), [Validators.required, Validators.pattern(/^\d{4}-(0[1-9]|1[0-2])$/)]],
    basic: [0, [Validators.required, Validators.min(1)]],
    allowances: [0, [Validators.required, Validators.min(0)]],
    deductions: [0, [Validators.required, Validators.min(0)]],
  });

  constructor() {
    this.form.controls.employeeId.valueChanges.pipe(takeUntilDestroyed()).subscribe((id) => this.onEmployeePicked(id));
  }

  name = (id: string): string => this.employees.byId(id)?.fullName ?? 'Deleted employee';
  deptOf = (id: string): string => this.departments.nameOf(this.employees.byId(id)?.departmentId);

  periodItems = computed(() => this.payroll.items().filter((p) => p.period === this.period()));
  rows = computed(() => {
    const q = this.search().trim().toLowerCase();
    return this.periodItems().filter((p) => {
      const e = this.employees.byId(p.employeeId);
      return (!q || (e?.fullName.toLowerCase().includes(q) ?? false) || (e?.code.toLowerCase().includes(q) ?? false))
        && (!this.dept() || e?.departmentId === this.dept()) && (!this.status() || p.status === this.status());
    }).sort((a, b) => this.name(a.employeeId).localeCompare(this.name(b.employeeId)));
  });
  totals = computed(() => {
    const items = this.periodItems();
    const sum = (f: (p: PayrollRecord) => number) => items.reduce((n, p) => n + f(p), 0);
    return { net: sum((p) => p.net), gross: sum((p) => p.basic + p.allowances), deductions: sum((p) => p.deductions),
      paid: sum((p) => (p.status === 'Paid' ? p.net : 0)), pending: sum((p) => (p.status === 'Pending' ? p.net : 0)),
      paidCount: items.filter((p) => p.status === 'Paid').length, pendingCount: items.filter((p) => p.status === 'Pending').length };
  });
  byDepartment = computed(() => {
    const m = new Map<string, { name: string; count: number; net: number }>();
    for (const p of this.periodItems()) {
      const name = this.deptOf(p.employeeId);
      const cur = m.get(name) ?? { name, count: 0, net: 0 };
      cur.count++; cur.net += p.net; m.set(name, cur);
    }
    return [...m.values()].sort((a, b) => b.net - a.net);
  });
  trend = computed(() => {
    const [y, m] = this.period().split('-').map(Number);
    const periods = Array.from({ length: 6 }, (_, i) => { const d = new Date(y, m - 1 - (5 - i), 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
    return { labels: periods.map((p) => MONTH_SHORT[Number(p.slice(5)) - 1]), series: [{ name: 'Net payroll', values: periods.map((p) => this.payroll.items().filter((x) => x.period === p).reduce((n, x) => n + x.net, 0)) }] };
  });
  missing = computed(() => this.employees.active().filter((e) => !this.payroll.exists(e.id, this.period())).length);

  generate(): void {
    const r = this.payroll.generate(this.period(), this.employees.active());
    if (r.created) this.notifier.success(`Created ${r.created} payroll entr${r.created === 1 ? 'y' : 'ies'} for ${this.label(this.period())}.`);
    else this.notifier.warn('No new entries were needed.');
    if (r.skippedNoSalary) this.notifier.warn(`${r.skippedNoSalary} employee(s) were skipped because they have no basic salary. Add one on the employee.`);
  }
  setStatus(p: PayrollRecord, s: 'Paid' | 'Pending'): void { this.payroll.setStatus(p.id, s, this.name(p.employeeId)); this.notifier.success(`Marked as ${s.toLowerCase()} (demo status only).`); }

  openEditor(): void {
    this.editorError.set('');
    this.form.reset({ employeeId: '', period: this.period(), basic: 0, allowances: 0, deductions: 0 });
    this.editor.set(true);
  }
  onEmployeePicked(id: string): void {
    const e = this.employees.byId(id);
    if (!e) return;
    const d = this.payroll.defaults(e.basicSalary);
    this.form.patchValue({ basic: e.basicSalary, allowances: d.allowances, deductions: d.deductions });
  }
  net(): number { const v = this.form.getRawValue(); return v.basic + v.allowances - v.deductions; }
  saveEditor(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.getRawValue();
    const e = this.employees.byId(v.employeeId);
    if (!e) { this.editorError.set('Choose a valid employee.'); return; }
    const r = this.payroll.create(e, v.period, v.basic, v.allowances, v.deductions);
    if (!r.ok) { this.editorError.set(r.error ?? 'Could not save.'); return; }
    this.notifier.success('Payroll entry added.');
    this.period.set(v.period);
    this.editor.set(false);
  }
  confirmDelete(): void {
    const p = this.toDelete();
    if (p) { this.payroll.remove(p.id); this.notifier.success('Payroll entry deleted.'); }
    this.toDelete.set(null);
  }
}
