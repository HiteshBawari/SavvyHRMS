import { Component, computed, effect, inject, input, signal, untracked } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';

@Component({
  selector: 'app-department-form',
  imports: [ReactiveFormsModule, RouterLink, Icon, EmptyState],
  templateUrl: './department-form.html',
})
export class DepartmentForm {
  id = input<string>();
  private fb = inject(FormBuilder);
  private departments = inject(DepartmentService);
  private router = inject(Router);
  private notifier = inject(NotificationService);
  employees = inject(EmployeeService);

  isEdit = computed(() => !!this.id());
  notFound = signal(false);
  formError = signal('');
  private loadedId: string | undefined;

  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(60), (c: AbstractControl) => this.unique(c, 'name')]],
    code: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9]{2,10}$/), (c: AbstractControl) => this.unique(c, 'code')]],
    managerId: [''],
    description: ['', Validators.maxLength(200)],
    status: ['Active' as 'Active' | 'Inactive', Validators.required],
  });

  constructor() {
    effect(() => {
      const id = this.id(); const list = this.departments.items();
      untracked(() => {
        if (!id) { this.loadedId = ''; return; }
        if (this.loadedId === id) return;
        const d = list.find((x) => x.id === id);
        if (!d) { this.notFound.set(true); return; }
        this.loadedId = id; this.notFound.set(false);
        this.form.reset({ name: d.name, code: d.code, managerId: d.managerId ?? '', description: d.description ?? '', status: d.status });
      });
    });
  }

  private unique(c: AbstractControl, field: 'name' | 'code'): ValidationErrors | null {
    const v = String(c.value ?? '').trim().toLowerCase();
    if (!v) return null;
    return this.departments.items().some((d) => d.id !== this.id() && d[field].toLowerCase() === v) ? { duplicate: true } : null;
  }
  invalid(n: string): boolean { const c = this.form.get(n); return !!c && c.invalid && (c.touched || c.dirty); }
  err(n: string): string {
    const e = this.form.get(n)?.errors;
    if (!e) return '';
    if (e['required']) return 'This field is required.';
    if (e['duplicate']) return n === 'name' ? 'A department with this name already exists.' : 'This code is already used.';
    if (e['pattern']) return 'Use 2-10 letters or numbers, no spaces.';
    return 'Invalid value.';
  }

  save(): void {
    this.formError.set('');
    if (this.form.invalid) { this.form.markAllAsTouched(); this.notifier.error('Please fix the highlighted fields.'); return; }
    const v = this.form.getRawValue();
    const r = this.isEdit() ? this.departments.update(this.id() as string, v) : this.departments.create(v);
    if (!r.ok) { this.formError.set(r.error ?? 'Could not save.'); this.notifier.error(r.error ?? 'Could not save.'); return; }
    this.notifier.success(this.isEdit() ? 'Department updated.' : 'Department created.');
    void this.router.navigateByUrl('/departments');
  }
}
