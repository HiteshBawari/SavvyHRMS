import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Department } from '../../../core/models/models';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ConfirmModal } from '../../../shared/components/confirm-modal/confirm-modal';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';

@Component({
  selector: 'app-department-list',
  imports: [FormsModule, RouterLink, Icon, StatusBadge, EmptyState, ConfirmModal],
  templateUrl: './department-list.html',
})
export class DepartmentList {
  private departments = inject(DepartmentService);
  employees = inject(EmployeeService);
  private notifier = inject(NotificationService);

  search = signal('');
  status = signal('');
  selected = signal<Department | null>(null);
  toDelete = signal<Department | null>(null);

  /** Employee counts are computed from saved employees, so they always match. */
  rows = computed(() => {
    const q = this.search().trim().toLowerCase();
    return this.departments.items()
      .filter((d) => (!q || d.name.toLowerCase().includes(q) || d.code.toLowerCase().includes(q)) && (!this.status() || d.status === this.status()))
      .map((d) => ({ dep: d, count: this.employees.items().filter((e) => e.departmentId === d.id).length, manager: this.employees.byId(d.managerId)?.fullName ?? '' }))
      .sort((a, b) => a.dep.name.localeCompare(b.dep.name));
  });
  totalDepartments = computed(() => this.departments.items().length);
  activeDepartments = computed(() => this.departments.items().filter((d) => d.status === 'Active').length);
  assigned = computed(() => this.employees.items().filter((e) => this.departments.byId(e.departmentId)).length);
  members = computed(() => {
    const d = this.selected();
    return d ? this.employees.items().filter((e) => e.departmentId === d.id) : [];
  });
  managerOf = (d: Department): string => this.employees.byId(d.managerId)?.fullName ?? 'Not assigned';

  askDelete(d: Department): void {
    const n = this.employees.countByDepartment(d.id);
    if (n > 0) { this.notifier.error(`${d.name} still has ${n} employee(s). Reassign them to another department first.`); this.selected.set(d); return; }
    this.toDelete.set(d);
  }
  confirmDelete(): void {
    const d = this.toDelete();
    if (!d) return;
    const r = this.departments.remove(d.id);
    this.toDelete.set(null);
    if (r.ok) this.notifier.success(`${d.name} was deleted.`); else this.notifier.error(r.error ?? 'Could not delete.');
  }
}
