import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DEMO_CREDENTIALS } from '../../../core/models/defaults';
import { AuthService } from '../../../core/services/auth.service';
import { Icon } from '../../../shared/components/icon/icon';
import { EMAIL_PATTERN } from '../../../shared/utils/format.utils';

type LoginMode = 'demo' | 'api';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, Icon],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  readonly demo = DEMO_CREDENTIALS;
  mode = signal<LoginMode>('demo');
  showPassword = signal(false);
  loading = signal(false); // true ONLY while the real API request is in flight
  serverError = signal('');

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.pattern(EMAIL_PATTERN)]],
    password: ['', [Validators.required]],
  });

  setMode(m: LoginMode): void {
    this.mode.set(m);
    this.serverError.set('');
    // The practice API may use plain user IDs, so only demo mode enforces an email format.
    this.form.controls.email.setValidators(m === 'demo' ? [Validators.required, Validators.pattern(EMAIL_PATTERN)] : [Validators.required]);
    this.form.controls.email.updateValueAndValidity();
  }

  fillDemo(): void {
    this.form.setValue({ email: this.demo.email, password: this.demo.password });
    this.serverError.set('');
  }

  showError(name: 'email' | 'password'): boolean {
    const c = this.form.controls[name];
    return c.invalid && (c.touched || c.dirty);
  }
  emailError(): string {
    const e = this.form.controls.email.errors;
    return e?.['required'] ? 'Email ID is required.' : 'Enter a valid email address, e.g. name@company.com.';
  }

  submit(): void {
    this.serverError.set('');
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const { email, password } = this.form.getRawValue();

    if (this.mode() === 'demo') {
      const r = this.auth.loginDemo(email, password);
      if (r.ok) void this.router.navigateByUrl('/overview');
      else this.serverError.set(r.error ?? 'Sign in failed.');
      return;
    }

    this.loading.set(true);
    this.auth.loginApi(email, password).subscribe((r) => {
      this.loading.set(false); // always stops, success or failure
      if (r.ok) void this.router.navigateByUrl('/overview');
      else this.serverError.set(r.error ?? 'Sign in failed.');
    });
  }
}
