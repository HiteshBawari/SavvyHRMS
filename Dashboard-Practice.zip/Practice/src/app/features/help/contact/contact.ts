import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { InboxService } from '../../../core/services/inbox.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Icon } from '../../../shared/components/icon/icon';
import { formatDateTime } from '../../../shared/utils/date.utils';
import { EMAIL_PATTERN } from '../../../shared/utils/format.utils';

@Component({
  selector: 'app-contact',
  imports: [ReactiveFormsModule, Icon],
  templateUrl: './contact.html',
})
export class Contact {
  private fb = inject(FormBuilder);
  private inbox = inject(InboxService);
  private notifier = inject(NotificationService);
  readonly fmt = formatDateTime;
  sent = signal(false);
  saved = () => this.inbox.inquiries().filter((i) => i.kind === 'contact').slice(0, 3);

  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.pattern(EMAIL_PATTERN)]],
    subject: ['', [Validators.required, Validators.minLength(3)]],
    message: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(1000)]],
  });
  invalid(n: 'name' | 'email' | 'subject' | 'message'): boolean { const c = this.form.controls[n]; return c.invalid && (c.touched || c.dirty); }
  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.inbox.addInquiry('contact', this.form.getRawValue());
    this.form.reset();
    this.sent.set(true);
    this.notifier.success('Message saved on this device.');
  }
}
