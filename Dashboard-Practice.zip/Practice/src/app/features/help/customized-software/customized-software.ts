import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { InboxService } from '../../../core/services/inbox.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Icon } from '../../../shared/components/icon/icon';
import { EMAIL_PATTERN } from '../../../shared/utils/format.utils';

@Component({
  selector: 'app-customized-software',
  imports: [ReactiveFormsModule, Icon],
  templateUrl: './customized-software.html',
})
export class CustomizedSoftware {
  private fb = inject(FormBuilder);
  private inbox = inject(InboxService);
  private notifier = inject(NotificationService);
  sent = signal(false);
  readonly options = [
    { icon: 'users', title: 'Your own workflows', text: 'Approval chains, onboarding checklists and employee fields that match how your company works.' },
    { icon: 'clock', title: 'Attendance rules', text: 'Shift patterns, regional holidays, overtime and half-day rules.' },
    { icon: 'rupee', title: 'Payroll structure', text: 'Salary components, allowances and deductions suited to your policy.' },
    { icon: 'chart', title: 'Reports & branding', text: 'Reports your managers need, in your colours and logo.' },
    { icon: 'shield', title: 'Real backend & security', text: 'Move from browser storage to a proper server, database and sign-in when you are ready for production.' },
  ];
  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.pattern(EMAIL_PATTERN)]],
    subject: ['Customization request', Validators.required],
    message: ['', [Validators.required, Validators.minLength(10)]],
  });
  bad(n: 'name' | 'email' | 'message'): boolean { const c = this.form.controls[n]; return c.invalid && (c.touched || c.dirty); }
  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.inbox.addInquiry('customization', this.form.getRawValue());
    this.sent.set(true);
    this.notifier.success('Inquiry saved on this device.');
  }
  again(): void { this.form.reset({ name: '', email: '', subject: 'Customization request', message: '' }); this.sent.set(false); }
}
