import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Icon } from '../../../shared/components/icon/icon';

@Component({
  selector: 'app-help-center',
  imports: [RouterLink, Icon],
  templateUrl: './help-center.html',
  styleUrl: './help-center.css',
})
export class HelpCenter {
  readonly modules = [
    { icon: 'users', title: 'Employees', link: '/employees', text: 'Add, edit, search and delete employees. Each person gets a unique ID and email. Deleting someone also deletes their attendance, leave and payroll records.' },
    { icon: 'clock', title: 'Attendance', link: '/attendance', text: 'Check people in and out, or mark Present, Half Day or Absent. Use Attendance records for daily, monthly and yearly views.' },
    { icon: 'calendar', title: 'Leave management', link: '/leave', text: 'Create requests, then approve, reject or cancel them. Approved leave appears in attendance without creating fake times.' },
    { icon: 'briefcase', title: 'Departments', link: '/departments', text: 'Create departments first, then assign employees. A department with employees cannot be deleted.' },
    { icon: 'rupee', title: 'Payroll', link: '/payroll', text: 'Generate monthly salary entries and mark them paid or pending. This is a demo calculation only.' },
    { icon: 'chart', title: 'Reports', link: '/reports', text: 'Charts for headcount, attendance, leave, new joiners and payroll. Filter by year and department.' },
    { icon: 'sliders', title: 'Settings', link: '/settings', text: 'Working days, shift times, holidays, leave types, payroll defaults, theme, and data reset.' },
  ];
  readonly tips = [
    'The sidebar highlights the page you are on. On a phone, open it with the menu button in the top bar.',
    'Weekly offs, holidays and approved leave are shown with their own status and blank In/Out times. They are never counted as absent.',
    'If a screen looks empty, check the filters at the top of the table and click "Clear filters".',
    'Cannot save a form? Scroll to the red messages under the fields: they say what to fix.',
    'Lost your data? Data lives in this browser only. A different browser, device, private window or cleared site data starts fresh.',
    'To start over, use Settings → Data → Reset application data.',
  ];
  readonly more = [
    { link: '/help/faq', label: 'FAQ', icon: 'help' }, { link: '/help/contact', label: 'Contact us', icon: 'mail' },
    { link: '/help/feedback', label: 'Give feedback', icon: 'star' }, { link: '/help/privacy', label: 'Privacy policy', icon: 'shield' },
    { link: '/help/customized-software', label: 'Customized software', icon: 'sliders' }, { link: '/help/happy-clients', label: 'Happy clients', icon: 'message' },
  ];
}
