import { Component } from '@angular/core';
import { Icon } from '../../../shared/components/icon/icon';

@Component({
  selector: 'app-happy-clients',
  imports: [Icon],
  templateUrl: './happy-clients.html',
})
export class HappyClients {
  /** Invented sample text for layout purposes. These are NOT real people, companies or reviews. */
  readonly samples = [
    { initials: 'AB', name: 'Sample Person A', role: 'HR Lead, Example Company', text: 'Sample testimonial: attendance and leave are all in one place, which keeps our monthly review simple.', stars: 5 },
    { initials: 'CD', name: 'Sample Person B', role: 'Operations Manager, Demo Co.', text: 'Sample testimonial: the dashboard shows who is in and who is on leave at a glance.', stars: 5 },
    { initials: 'EF', name: 'Sample Person C', role: 'Founder, Placeholder Ltd.', text: 'Sample testimonial: easy to learn, and the reports help us plan hiring.', stars: 4 },
  ];
  readonly stars = [1, 2, 3, 4, 5];
}
