import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { InboxService } from '../../../core/services/inbox.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Icon } from '../../../shared/components/icon/icon';

@Component({
  selector: 'app-feedback',
  imports: [ReactiveFormsModule, Icon],
  templateUrl: './feedback.html',
  styleUrl: './feedback.css',
})
export class Feedback {
  private fb = inject(FormBuilder);
  private inbox = inject(InboxService);
  private notifier = inject(NotificationService);
  readonly categories = ['General', 'Bug report', 'Feature request', 'Design & usability', 'Other'];
  readonly labels = ['', 'Very unhappy', 'Unhappy', 'Okay', 'Happy', 'Very happy'];
  readonly stars = [1, 2, 3, 4, 5];
  hover = signal(0);
  done = signal(false);
  total = () => this.inbox.feedback().length;

  form = this.fb.nonNullable.group({
    rating: [0, [Validators.required, Validators.min(1)]],
    category: ['General', Validators.required],
    message: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(1000)]],
  });
  setRating(n: number): void { this.form.controls.rating.setValue(n); this.form.controls.rating.markAsDirty(); }
  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.getRawValue();
    this.inbox.addFeedback(v.rating, v.category, v.message);
    this.notifier.success('Thank you for your feedback!');
    this.done.set(true);
  }
  again(): void { this.form.reset({ rating: 0, category: 'General', message: '' }); this.done.set(false); }
}
