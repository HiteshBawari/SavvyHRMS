import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-faq',
  imports: [RouterLink],
  templateUrl: './faq.html',
  styleUrl: './faq.css',
})
export class Faq {
  readonly items = [
    { q: 'How do I add or edit an employee?', a: 'Go to Employees → Add employee. Fill the required fields (marked with *). Employee ID is generated for you and email must be unique. To edit, use the pencil icon on the list or the Edit button on the employee page. Create departments first so you can assign people.' },
    { q: 'How do I record attendance?', a: 'Open Attendance. For each person use Check in, then Check out later, or mark Present, Half day or Absent. For past dates or corrections use Attendance records → Add record, or click a day in the monthly grid. One record per person per date is allowed, and check-out cannot be earlier than check-in.' },
    { q: 'Why are Sundays or holidays not shown as absent?', a: 'Weekly offs, holidays and approved leave are not working days for that person, so they have their own status and blank In/Out times. Working days and holidays are configured in Settings → Attendance. Saturday is only a day off if you untick it there.' },
    { q: 'How do leave approvals work?', a: 'Create a request under Leave management. A pending request can be approved, rejected or cancelled. Approval asks for confirmation. Approved days show as "Approved Leave" in attendance and count against the yearly quota set in Settings → Leave. Overlapping requests for the same employee are blocked.' },
    { q: 'How do departments work?', a: 'Each employee belongs to a department. Employee counts are calculated from saved employees. You cannot delete a department that still has employees: reassign them first.' },
    { q: 'How is payroll calculated?', a: 'Net salary = basic salary + allowances − deductions. Allowances and deductions default to percentages set in Settings → Payroll. Each employee can have only one entry per month. Paid/Pending is just a label: no money moves and no tax or statutory rules are applied.' },
    { q: 'Where is my data stored?', a: 'In your browser\'s localStorage on this device. There is no server or database. It is not shared between devices or browsers, and clearing site data removes it.' },
    { q: 'How do I reset the demo data?', a: 'Settings → Data. "Clear demo data" removes all records but keeps settings. "Reset application data" restores defaults and sample data. Both ask for confirmation first.' },
  ];
}
