import { Component, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AttendanceService } from '../../../core/services/attendance.service';
import { AuthService } from '../../../core/services/auth.service';
import { ActivityService } from '../../../core/services/activity.service';
import { DepartmentService } from '../../../core/services/department.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { LeaveService } from '../../../core/services/leave.service';
import { SettingsService } from '../../../core/services/settings.service';
import { Chart } from '../../../shared/components/chart/chart';
import { EmptyState } from '../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../shared/components/icon/icon';
import { StatusBadge } from '../../../shared/components/status-badge/status-badge';
import { addDays, formatDate, formatDateTime, initials, todayISO, WEEKDAY_SHORT, weekday } from '../../../shared/utils/date.utils';
import { colorFor } from '../../../shared/utils/format.utils';

@Component({
  selector: 'app-overview-dashboard',
  imports: [RouterLink, Icon, StatusBadge, EmptyState, Chart],
  templateUrl: './overview-dashboard.html',
  styleUrl: './overview-dashboard.css',
})
export class OverviewDashboard {
  private auth = inject(AuthService);
  private attendance = inject(AttendanceService);
  private leave = inject(LeaveService);
  private activity = inject(ActivityService);
  employees = inject(EmployeeService);
  departments = inject(DepartmentService);
  settings = inject(SettingsService);

  readonly fmt = formatDate; readonly fmtTime = formatDateTime; readonly initials = initials; readonly colorFor = colorFor;
  today = todayISO();
  firstName = computed(() => (this.auth.session()?.name ?? '').split(' ')[0] || 'there');
  greeting = (() => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; })();

  stats = computed(() => this.attendance.dailyStats(this.employees.active(), this.today));
  rate = computed(() => { const s = this.stats(); const d = s.present + s.half + s.absent; return d ? Math.round(((s.present + s.half * 0.5) / d) * 1000) / 10 : null; });
  todayKind = computed(() => {
    const e = this.employees.active()[0];
    return e ? this.attendance.day(e, this.today).kind : 'Upcoming';
  });
  newThisMonth = computed(() => this.employees.items().filter((e) => e.joiningDate.slice(0, 7) === this.today.slice(0, 7)).length);

  deptChart = computed(() => {
    const rows = this.departments.items().map((d) => ({ name: d.name, n: this.employees.items().filter((e) => e.departmentId === d.id).length })).filter((r) => r.n > 0);
    const unassigned = this.employees.items().filter((e) => !this.departments.byId(e.departmentId)).length;
    if (unassigned) rows.push({ name: 'Unassigned', n: unassigned });
    return { labels: rows.map((r) => r.name), values: rows.map((r) => r.n) };
  });

  week = computed(() => {
    const days = Array.from({ length: 7 }, (_, i) => addDays(this.today, i - 6));
    const s = days.map((d) => this.attendance.dailyStats(this.employees.active(), d));
    return { labels: days.map((d) => WEEKDAY_SHORT[weekday(d)]), series: [
      { name: 'Present', color: '#38A982', values: s.map((x) => x.present + x.half) },
      { name: 'Absent', color: '#E05A67', values: s.map((x) => x.absent) },
      { name: 'On leave', color: '#E8A54B', values: s.map((x) => x.leave) },
    ] };
  });

  recentEmployees = computed(() => [...this.employees.items()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5));
  pendingLeaves = computed(() => this.leave.items().filter((l) => l.status === 'Pending'));
  recentLeaves = computed(() => [...this.leave.items()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4));
  holidays = computed(() => this.settings.holidays().filter((h) => h.date >= this.today).slice(0, 4));
  feed = computed(() => this.activity.items().slice(0, 6));
  name = (id: string): string => this.employees.byId(id)?.fullName ?? 'Deleted employee';
  deptName = (id: string): string => this.departments.nameOf(id);
  daysTo = (d: string): number => Math.round((new Date(d + 'T00:00:00').getTime() - new Date(this.today + 'T00:00:00').getTime()) / 86400000);
}
