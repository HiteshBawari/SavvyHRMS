import { provideHttpClient } from '@angular/common/http';
import { ApplicationConfig, inject, provideAppInitializer, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { DemoDataService } from './core/services/demo-data.service';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(), // needed by the practice-API login (your original login used HttpClient but this was missing)
    // Creates sample data on the very first launch, before any screen reads localStorage.
    provideAppInitializer(() => inject(DemoDataService).ensureSeeded()),
  ],
};
