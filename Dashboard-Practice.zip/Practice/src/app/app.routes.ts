import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './core/guards/auth.guard';
import { MainLayout } from './core/layout/main-layout/main-layout';
import { Login } from './features/auth/login/login';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  // Login lives OUTSIDE the dashboard layout.
  { path: 'login', component: Login, canActivate: [guestGuard], title: 'Sign in · SavvyHRMS' },

  // Everything below needs a (demo) session and is shown inside the sidebar/top-bar layout.
  {
    path: '',
    component: MainLayout,
    canActivate: [authGuard],
    children: [
      { path: 'overview', data: { title: 'Overview' }, title: 'Overview · SavvyHRMS', loadComponent: () => import('./features/overview/overview-dashboard/overview-dashboard').then((m) => m.OverviewDashboard) },

      {
        path: 'employees', data: { title: 'Employees' },
        children: [
          { path: '', title: 'Employees · SavvyHRMS', loadComponent: () => import('./features/employees/employee-list/employee-list').then((m) => m.EmployeeList) },
          { path: 'new', data: { title: 'Add employee' }, title: 'Add employee · SavvyHRMS', loadComponent: () => import('./features/employees/employee-form/employee-form').then((m) => m.EmployeeForm) },
          { path: ':id/edit', data: { title: 'Edit employee' }, title: 'Edit employee · SavvyHRMS', loadComponent: () => import('./features/employees/employee-form/employee-form').then((m) => m.EmployeeForm) },
          { path: ':id', data: { title: 'Employee details' }, title: 'Employee details · SavvyHRMS', loadComponent: () => import('./features/employees/employee-details/employee-details').then((m) => m.EmployeeDetails) },
        ],
      },

      {
        path: 'attendance', data: { title: 'Attendance' },
        children: [
          { path: '', title: 'Attendance · SavvyHRMS', loadComponent: () => import('./features/attendance/attendance-dashboard/attendance-dashboard').then((m) => m.AttendanceDashboard) },
          { path: 'records', data: { title: 'Records' }, title: 'Attendance records · SavvyHRMS', loadComponent: () => import('./features/attendance/attendance-records/attendance-records').then((m) => m.AttendanceRecords) },
        ],
      },

      {
        path: 'leave', data: { title: 'Leave Management' },
        children: [
          { path: '', title: 'Leave · SavvyHRMS', loadComponent: () => import('./features/leave-management/leave-dashboard/leave-dashboard').then((m) => m.LeaveDashboard) },
          { path: 'new', data: { title: 'New request' }, title: 'New leave request · SavvyHRMS', loadComponent: () => import('./features/leave-management/leave-form/leave-form').then((m) => m.LeaveForm) },
          { path: ':id', data: { title: 'Request details' }, title: 'Leave request · SavvyHRMS', loadComponent: () => import('./features/leave-management/leave-details/leave-details').then((m) => m.LeaveDetails) },
        ],
      },

      {
        path: 'departments', data: { title: 'Departments' },
        children: [
          { path: '', title: 'Departments · SavvyHRMS', loadComponent: () => import('./features/departments/department-list/department-list').then((m) => m.DepartmentList) },
          { path: 'new', data: { title: 'Add department' }, title: 'Add department · SavvyHRMS', loadComponent: () => import('./features/departments/department-form/department-form').then((m) => m.DepartmentForm) },
          { path: ':id/edit', data: { title: 'Edit department' }, title: 'Edit department · SavvyHRMS', loadComponent: () => import('./features/departments/department-form/department-form').then((m) => m.DepartmentForm) },
        ],
      },

      {
        path: 'payroll', data: { title: 'Payroll' },
        children: [
          { path: '', title: 'Payroll · SavvyHRMS', loadComponent: () => import('./features/payroll/payroll-dashboard/payroll-dashboard').then((m) => m.PayrollDashboard) },
          { path: ':id', data: { title: 'Salary details' }, title: 'Salary details · SavvyHRMS', loadComponent: () => import('./features/payroll/salary-details/salary-details').then((m) => m.SalaryDetails) },
        ],
      },

      { path: 'reports', data: { title: 'Reports' }, title: 'Reports · SavvyHRMS', loadComponent: () => import('./features/reports/reports-dashboard/reports-dashboard').then((m) => m.ReportsDashboard) },
      { path: 'settings', data: { title: 'Settings' }, title: 'Settings · SavvyHRMS', loadComponent: () => import('./features/settings/settings-dashboard/settings-dashboard').then((m) => m.SettingsDashboard) },

      {
        path: 'help', data: { title: 'Help' },
        children: [
          { path: '', title: 'Help Center · SavvyHRMS', loadComponent: () => import('./features/help/help-center/help-center').then((m) => m.HelpCenter) },
          { path: 'faq', data: { title: 'FAQ' }, title: 'FAQ · SavvyHRMS', loadComponent: () => import('./features/help/faq/faq').then((m) => m.Faq) },
          { path: 'contact', data: { title: 'Contact us' }, title: 'Contact us · SavvyHRMS', loadComponent: () => import('./features/help/contact/contact').then((m) => m.Contact) },
          { path: 'feedback', data: { title: 'Feedback' }, title: 'Feedback · SavvyHRMS', loadComponent: () => import('./features/help/feedback/feedback').then((m) => m.Feedback) },
          { path: 'privacy', data: { title: 'Privacy policy' }, title: 'Privacy policy · SavvyHRMS', loadComponent: () => import('./features/help/privacy-policy/privacy-policy').then((m) => m.PrivacyPolicy) },
          { path: 'customized-software', data: { title: 'Customized software' }, title: 'Customized software · SavvyHRMS', loadComponent: () => import('./features/help/customized-software/customized-software').then((m) => m.CustomizedSoftware) },
          { path: 'happy-clients', data: { title: 'Happy clients' }, title: 'Happy clients · SavvyHRMS', loadComponent: () => import('./features/help/happy-clients/happy-clients').then((m) => m.HappyClients) },
        ],
      },
    ],
  },
  { path: '**', redirectTo: 'login' },
];
