import { AfterViewInit, Component, ElementRef, HostListener, input, output, viewChild } from '@angular/core';

/** Accessible confirmation dialog. Use: @if (open) { <app-confirm-modal ... (confirmed)="..." (cancelled)="open = false" /> } */
@Component({
  selector: 'app-confirm-modal',
  templateUrl: './confirm-modal.html',
  styleUrl: './confirm-modal.css',
})
export class ConfirmModal implements AfterViewInit {
  heading = input('Are you sure?');
  message = input('');
  details = input<string[]>([]);
  confirmLabel = input('Confirm');
  danger = input(false);
  confirmed = output<void>();
  cancelled = output<void>();
  private cancelBtn = viewChild<ElementRef<HTMLButtonElement>>('cancelBtn');

  ngAfterViewInit(): void { this.cancelBtn()?.nativeElement.focus(); }
  @HostListener('document:keydown.escape') onEscape(): void { this.cancelled.emit(); }
}
