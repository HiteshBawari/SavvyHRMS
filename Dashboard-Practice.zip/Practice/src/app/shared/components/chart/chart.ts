import { Component, computed, input } from '@angular/core';
import { CHART_COLORS } from '../../utils/format.utils';

export interface ChartSeries { name: string; values: number[]; color?: string }
interface Rect { x: number; y: number; w: number; h: number; color: string; tip: string }
interface Tick { y: number; label: string }

const W = 560, H = 250, PAD = { l: 40, r: 12, t: 14, b: 30 };

/** Small dependency-free SVG chart: 'bar' (grouped), 'stacked', 'line' and 'donut'. Values come from real saved data. */
@Component({
  selector: 'app-chart',
  templateUrl: './chart.html',
  styleUrl: './chart.css',
})
export class Chart {
  type = input<'bar' | 'stacked' | 'line' | 'donut'>('bar');
  labels = input<string[]>([]);
  series = input<ChartSeries[]>([]);
  unit = input('');
  fixedMax = input<number | null>(null);
  centerLabel = input('');
  centerValue = input('');
  ariaLabel = input('Chart');

  readonly W = W; readonly H = H; readonly baseY = H - PAD.b; readonly left = PAD.l; readonly right = W - PAD.r;

  private colored = computed(() => this.series().map((s, i) => ({ ...s, color: s.color ?? CHART_COLORS[i % CHART_COLORS.length] })));
  legend = computed(() => (this.type() === 'donut'
    ? this.labels().map((l, i) => ({ name: l, color: CHART_COLORS[i % CHART_COLORS.length], value: this.series()[0]?.values[i] ?? 0 }))
    : this.colored().map((s) => ({ name: s.name, color: s.color, value: null as number | null }))));

  hasData = computed(() => this.series().some((s) => s.values.some((v) => v > 0)));

  private maxValue = computed(() => {
    if (this.fixedMax() !== null) return this.fixedMax() as number;
    const s = this.colored();
    const raw = this.type() === 'stacked'
      ? Math.max(0, ...this.labels().map((_, i) => s.reduce((n, x) => n + (x.values[i] || 0), 0)))
      : Math.max(0, ...s.flatMap((x) => x.values));
    if (raw <= 0) return 4;
    const target = raw / 4; const p = Math.pow(10, Math.floor(Math.log10(target)));
    const step = [1, 2, 3, 5, 10].map((f) => f * p).find((v) => v >= target) as number;
    return step * 4;
  });
  private y = (v: number) => PAD.t + (H - PAD.t - PAD.b) * (1 - v / this.maxValue());

  ticks = computed<Tick[]>(() => Array.from({ length: 5 }, (_, i) => {
    const v = (this.maxValue() * i) / 4;
    return { y: this.y(v), label: (Number.isInteger(v) ? v : v.toFixed(1)) + this.unit() };
  }));

  groupWidth = computed(() => (W - PAD.l - PAD.r) / Math.max(1, this.labels().length));
  xLabels = computed(() => this.labels().map((l, i) => ({ text: l, x: PAD.l + this.groupWidth() * (i + 0.5) })));

  bars = computed<Rect[]>(() => {
    const out: Rect[] = []; const s = this.colored(); const gw = this.groupWidth();
    if (this.type() === 'bar') {
      const bw = Math.min(28, (gw * 0.72) / Math.max(1, s.length));
      this.labels().forEach((l, i) => s.forEach((x, j) => {
        const v = x.values[i] || 0;
        out.push({ x: PAD.l + gw * (i + 0.5) - (bw * s.length) / 2 + j * bw, y: this.y(v), w: bw - 2, h: H - PAD.b - this.y(v), color: x.color, tip: `${l} · ${x.name}: ${v}${this.unit()}` });
      }));
    } else if (this.type() === 'stacked') {
      const bw = Math.min(34, gw * 0.6);
      this.labels().forEach((l, i) => {
        let acc = 0;
        s.forEach((x) => {
          const v = x.values[i] || 0; if (v <= 0) return;
          out.push({ x: PAD.l + gw * (i + 0.5) - bw / 2, y: this.y(acc + v), w: bw, h: this.y(acc) - this.y(acc + v), color: x.color, tip: `${l} · ${x.name}: ${v}` });
          acc += v;
        });
      });
    }
    return out;
  });

  lines = computed(() => this.colored().map((s) => {
    const pts = s.values.map((v, i) => ({ x: PAD.l + this.groupWidth() * (i + 0.5), y: this.y(v), tip: `${this.labels()[i]} · ${s.name}: ${v}${this.unit()}` }));
    return { color: s.color, d: pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' '), pts };
  }));

  slices = computed(() => {
    const vals = this.series()[0]?.values ?? []; const total = vals.reduce((a, b) => a + b, 0) || 1; let acc = 0;
    return vals.map((v, i) => {
      const pct = (v / total) * 100; const s = { dash: `${pct} ${100 - pct}`, offset: 25 - acc, color: CHART_COLORS[i % CHART_COLORS.length], tip: `${this.labels()[i]}: ${v}` };
      acc += pct; return s;
    });
  });
}
