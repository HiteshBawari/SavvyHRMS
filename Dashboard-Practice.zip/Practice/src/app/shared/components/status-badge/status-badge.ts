import { Component, computed, input } from '@angular/core';

const TONES: Record<string, string> = {
  Active: 'success', Present: 'success', Approved: 'success', Paid: 'success',
  Pending: 'warning', 'Half Day': 'warning', Onboarding: 'info', 'On Notice': 'warning', 'No Record': 'muted',
  Absent: 'danger', Rejected: 'danger', Inactive: 'danger',
  'Approved Leave': 'info', Holiday: 'purple', Sunday: 'muted', 'Weekly Off': 'muted', Cancelled: 'muted', Upcoming: 'muted', 'Not Joined': 'muted',
};

@Component({
  selector: 'app-status-badge',
  template: `<span [class]="'badge badge-' + tone()"><i class="dot"></i>{{ status() }}</span>`,
  styles: [`.dot{width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block}`],
})
export class StatusBadge {
  status = input.required<string>();
  tone = computed(() => TONES[this.status()] ?? 'muted');
}
