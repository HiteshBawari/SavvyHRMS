import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';

@Component({
  selector: 'app-empty-state',
  imports: [Icon],
  template: `
    <div class="empty">
      <div class="empty-icon"><app-icon [name]="icon()" [size]="26" /></div>
      <h3>{{ heading() }}</h3>
      @if (message()) { <p>{{ message() }}</p> }
      <ng-content />
    </div>`,
  styles: [`
    .empty{display:flex;flex-direction:column;align-items:center;text-align:center;padding:36px 16px;gap:6px}
    .empty-icon{width:56px;height:56px;border-radius:16px;display:grid;place-items:center;background:var(--primary-soft);color:var(--primary);margin-bottom:6px}
    h3{margin:0;font-size:16px} p{margin:0 0 8px;color:var(--text-secondary);font-size:13.5px;max-width:420px}`],
})
export class EmptyState {
  icon = input('inbox');
  heading = input('Nothing here yet');
  message = input('');
}
