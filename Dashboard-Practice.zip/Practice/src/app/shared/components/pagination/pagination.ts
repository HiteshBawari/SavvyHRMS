import { Component, computed, input, output } from '@angular/core';
import { Icon } from '../icon/icon';

@Component({
  selector: 'app-pagination',
  imports: [Icon],
  templateUrl: './pagination.html',
  styleUrl: './pagination.css',
})
export class Pagination {
  total = input.required<number>();
  page = input(1);
  pageSize = input(10);
  pageChange = output<number>();

  pages = computed(() => Math.max(1, Math.ceil(this.total() / this.pageSize())));
  from = computed(() => (this.total() === 0 ? 0 : (this.page() - 1) * this.pageSize() + 1));
  to = computed(() => Math.min(this.total(), this.page() * this.pageSize()));
  numbers = computed(() => {
    const p = this.page(); const n = this.pages();
    const start = Math.max(1, Math.min(p - 2, n - 4));
    return Array.from({ length: Math.min(5, n) }, (_, i) => start + i);
  });
  go(p: number): void { if (p >= 1 && p <= this.pages() && p !== this.page()) this.pageChange.emit(p); }
}
