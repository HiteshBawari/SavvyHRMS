import { Component, inject } from '@angular/core';
import { NotificationService } from '../../../core/services/notification.service';
import { Icon } from '../icon/icon';

@Component({
  selector: 'app-notification-toast',
  imports: [Icon],
  templateUrl: './notification-toast.html',
  styleUrl: './notification-toast.css',
})
export class NotificationToast {
  notifier = inject(NotificationService);
}
