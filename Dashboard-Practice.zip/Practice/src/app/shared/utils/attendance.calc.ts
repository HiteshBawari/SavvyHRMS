import { AttendanceRecord, CompanySettings, Holiday, LeaveRequest } from '../../core/models/models';
import { eachDate, isISODate, timeToMinutes, weekday } from './date.utils';

// Pure attendance rules. Every screen (overview, attendance grid, reports) goes through
// resolveDay() so a Sunday, a holiday or a leave day is never mistaken for an absence.

export type DayKind =
  | 'Present' | 'Absent' | 'Half Day'
  | 'Sunday' | 'Weekly Off' | 'Holiday' | 'Approved Leave'
  | 'No Record' | 'Not Joined' | 'Upcoming';

export interface DayInfo {
  date: string;
  kind: DayKind;
  record?: AttendanceRecord;
  label?: string; // holiday name or leave type
  late?: boolean;
}

export interface DayCtx {
  att: CompanySettings['attendance'];
  holidays: Map<string, Holiday>;
  recordOf: (employeeId: string, date: string) => AttendanceRecord | undefined;
  leaveOf: (employeeId: string, date: string) => LeaveRequest | undefined;
  today: string;
}

export function isLate(att: CompanySettings['attendance'], checkIn?: string): boolean {
  if (!checkIn) return false;
  return timeToMinutes(checkIn) > timeToMinutes(att.shiftStart) + att.graceMinutes;
}

export function resolveDay(ctx: DayCtx, emp: { id: string; joiningDate: string }, date: string): DayInfo {
  const rec = ctx.recordOf(emp.id, date);
  if (rec) {
    return { date, kind: rec.status, record: rec, late: rec.status !== 'Absent' && isLate(ctx.att, rec.checkIn) };
  }
  if (isISODate(emp.joiningDate) && date < emp.joiningDate) return { date, kind: 'Not Joined' };
  if (!ctx.att.workingDays.includes(weekday(date))) {
    return { date, kind: weekday(date) === 0 ? 'Sunday' : 'Weekly Off' };
  }
  const hol = ctx.holidays.get(date);
  if (hol) return { date, kind: 'Holiday', label: hol.name };
  const leave = ctx.leaveOf(emp.id, date);
  if (leave) return { date, kind: 'Approved Leave', label: leave.type };
  if (date > ctx.today) return { date, kind: 'Upcoming' };
  return { date, kind: 'No Record' };
}

export interface AttendanceSummary {
  present: number; absent: number; half: number; leave: number;
  holiday: number; weeklyOff: number; noRecord: number;
  minutes: number; late: number;
  percent: number | null; // null when there is nothing to measure
}

export const emptySummary = (): AttendanceSummary => ({
  present: 0, absent: 0, half: 0, leave: 0, holiday: 0, weeklyOff: 0, noRecord: 0, minutes: 0, late: 0, percent: null,
});

export function addSummary(a: AttendanceSummary, b: AttendanceSummary): AttendanceSummary {
  return {
    present: a.present + b.present, absent: a.absent + b.absent, half: a.half + b.half, leave: a.leave + b.leave,
    holiday: a.holiday + b.holiday, weeklyOff: a.weeklyOff + b.weeklyOff, noRecord: a.noRecord + b.noRecord,
    minutes: a.minutes + b.minutes, late: a.late + b.late, percent: null,
  };
}

export function percentOf(s: AttendanceSummary, countNoRecord: boolean): number | null {
  const denom = s.present + s.half + s.absent + (countNoRecord ? s.noRecord : 0);
  return denom > 0 ? Math.round(((s.present + s.half * 0.5) / denom) * 1000) / 10 : null;
}

/**
 * Attendance % = (present + 0.5 * half days) / (present + half + absent [+ no-record days if the
 * "count no-record days as absent" policy is on]). Sundays, holidays, leave days and today's
 * not-yet-recorded day are never part of the denominator.
 */
export function summarize(ctx: DayCtx, emp: { id: string; joiningDate: string }, from: string, to: string): AttendanceSummary {
  const s = emptySummary();
  for (const date of eachDate(from, to)) {
    const d = resolveDay(ctx, emp, date);
    switch (d.kind) {
      case 'Present': s.present++; break;
      case 'Absent': s.absent++; break;
      case 'Half Day': s.half++; break;
      case 'Approved Leave': s.leave++; break;
      case 'Holiday': s.holiday++; break;
      case 'Sunday': case 'Weekly Off': s.weeklyOff++; break;
      case 'No Record': if (date !== ctx.today) s.noRecord++; break;
    }
    if (d.record) s.minutes += d.record.durationMinutes || 0;
    if (d.late) s.late++;
  }
  s.percent = percentOf(s, ctx.att.countNoRecordAsAbsent);
  return s;
}

/** Working days inside a leave range (weekly offs and holidays are not charged to the employee). */
export function countLeaveDays(att: CompanySettings['attendance'], holidays: Map<string, Holiday>, start: string, end: string): number {
  return eachDate(start, end).filter((d) => att.workingDays.includes(weekday(d)) && !holidays.has(d)).length;
}
