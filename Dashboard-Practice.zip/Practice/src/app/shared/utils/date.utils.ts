// Pure helper functions for dates and times. No Angular code here so they are easy to test.
// Dates are handled as local calendar dates ("YYYY-MM-DD"), never converted through UTC.

export const pad = (n: number): string => String(n).padStart(2, '0');

export function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export const todayISO = (): string => toISO(new Date());

export function parseISO(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}
export function isISODate(s: string | null | undefined): boolean {
  if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  return toISO(parseISO(s)) === s;
}
export function addDays(s: string, n: number): string {
  const d = parseISO(s);
  d.setDate(d.getDate() + n);
  return toISO(d);
}
export const weekday = (s: string): number => parseISO(s).getDay(); // 0 = Sunday
export const daysInMonth = (year: number, month1to12: number): number => new Date(year, month1to12, 0).getDate();

export function eachDate(from: string, to: string): string[] {
  const out: string[] = [];
  if (!isISODate(from) || !isISODate(to) || from > to) return out;
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}
export const monthStart = (year: number, m: number): string => `${year}-${pad(m)}-01`;
export const monthEnd = (year: number, m: number): string => `${year}-${pad(m)}-${pad(daysInMonth(year, m))}`;

export function nowTime(): string {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function isTime(s: string | null | undefined): boolean {
  return !!s && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
}
export function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}
/** Minutes worked, or -1 when check-out is before check-in and overnight shifts are not allowed. */
export function workMinutes(checkIn?: string, checkOut?: string, allowOvernight = false): number {
  if (!checkIn || !checkOut) return 0;
  let diff = timeToMinutes(checkOut) - timeToMinutes(checkIn);
  if (diff < 0) {
    if (!allowOvernight) return -1;
    diff += 24 * 60;
  }
  return diff;
}
export function formatDuration(min: number): string {
  if (!min || min <= 0) return '';
  return `${Math.floor(min / 60)}h ${pad(min % 60)}m`;
}
/** "14:05" -> "02:05 PM" ; empty stays empty (never invent a time). */
export function formatTime(t?: string): string {
  if (!isTime(t)) return '';
  const [h, m] = (t as string).split(':').map(Number);
  return `${pad(h % 12 === 0 ? 12 : h % 12)}:${pad(m)} ${h < 12 ? 'AM' : 'PM'}`;
}
export function formatDate(s?: string): string {
  if (!s || !isISODate(s)) return '';
  return parseISO(s).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
export const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const MONTH_SHORT = MONTH_NAMES.map((m) => m.slice(0, 3));
export const WEEKDAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
export function initials(name: string): string {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}
export function periodLabel(period: string): string {
  const [y, m] = period.split('-').map(Number);
  return m ? `${MONTH_NAMES[m - 1]} ${y}` : period;
}
