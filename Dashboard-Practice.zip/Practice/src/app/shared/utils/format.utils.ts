export function formatMoney(amount: number, currency = 'INR'): string {
  const n = Number.isFinite(amount) ? amount : 0;
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
  } catch {
    return `${currency} ${Math.round(n).toLocaleString('en-IN')}`;
  }
}
export const PHONE_PATTERN = /^[+]?[0-9][0-9\s\-]{6,16}[0-9]$/;
export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const AVATAR_COLORS = ['#7655E8', '#3F8CE8', '#E8A54B', '#38A982', '#E05A91', '#5B6FD6'];
export function colorFor(key: string): string {
  let h = 0;
  for (const c of key) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
export const CHART_COLORS = ['#7655E8', '#3F8CE8', '#E8A54B', '#38A982', '#E05A91', '#8D8AA5', '#5B6FD6'];
