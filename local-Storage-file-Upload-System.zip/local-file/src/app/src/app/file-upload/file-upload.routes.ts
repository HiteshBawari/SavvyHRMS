import { Routes } from '@angular/router';

/** Lazy route: the whole feature is only downloaded when this page opens. */
export const FILE_UPLOAD_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./file-upload.component').then(m => m.FileUploadComponent),
  },
];
