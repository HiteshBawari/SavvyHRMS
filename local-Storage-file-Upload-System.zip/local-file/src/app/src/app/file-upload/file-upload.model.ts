/** The three groups of files this module accepts. Add a new one here + in file-upload.config.ts. */
export type FileCategory = 'image' | 'document' | 'video';

/** What we keep in localStorage for every file (the "index card"). The real bytes live in IndexedDB. */
export interface StoredFileMeta {
  id: string;
  name: string;
  size: number;        // bytes
  type: string;        // MIME type, e.g. "application/pdf"
  category: FileCategory;
  uploadedAt: number;  // Date.now()
}
