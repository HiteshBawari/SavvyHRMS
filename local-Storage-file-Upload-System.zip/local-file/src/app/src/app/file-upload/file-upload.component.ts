import { DatePipe } from '@angular/common';
import { Component, HostListener, OnDestroy, OnInit, computed, inject, signal } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import {
  CATEGORIES, UPLOAD_RULES, detectCategory, formatBytes, getExtension,
} from './file-upload.config';
import { FileStorageService } from './file-storage.service';
import { FileCategory, StoredFileMeta } from './file-upload.model';

type Filter = 'all' | FileCategory;
type PreviewKind = 'image' | 'video' | 'frame' | 'none';
type Validation = { ok: true; category: FileCategory } | { ok: false; error: string };

interface PreviewState {
  meta: StoredFileMeta;
  rawUrl: string;          // needed later to revoke (free memory)
  safeUrl: SafeResourceUrl;
  kind: PreviewKind;
}

@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './file-upload.component.html',
  styleUrl: './file-upload.component.css',
})
export class FileUploadComponent implements OnInit, OnDestroy {
  private readonly storage = inject(FileStorageService);
  private readonly sanitizer = inject(DomSanitizer);

  // static info used by the template
  readonly rules = UPLOAD_RULES;
  readonly categories = CATEGORIES;
  readonly fmt = formatBytes;
  readonly accept = CATEGORIES.flatMap(c => UPLOAD_RULES[c].extensions.map(e => '.' + e)).join(',');

  // state (signals)
  readonly files = this.storage.files;
  readonly ready = signal(false);
  readonly isBusy = signal(false);
  readonly isDragging = signal(false);
  readonly activeFilter = signal<Filter>('all');
  readonly search = signal('');
  readonly errors = signal<string[]>([]);
  readonly success = signal('');
  readonly preview = signal<PreviewState | null>(null);
  readonly toDelete = signal<StoredFileMeta | null>(null);
  readonly usage = signal<{ used: number; quota: number } | null>(null);

  private dragDepth = 0;

  // derived state (computed re-runs automatically when its signals change)
  readonly visibleFiles = computed(() => {
    const filter = this.activeFilter();
    const term = this.search().trim().toLowerCase();
    return this.files().filter(f =>
      (filter === 'all' || f.category === filter) &&
      (!term || f.name.toLowerCase().includes(term)));
  });

  readonly counts = computed(() => {
    const c: Record<Filter, number> = { all: 0, image: 0, document: 0, video: 0 };
    for (const f of this.files()) { c.all++; c[f.category]++; }
    return c;
  });

  readonly totalSize = computed(() => this.files().reduce((sum, f) => sum + f.size, 0));

  // ───────────── lifecycle ─────────────
  async ngOnInit(): Promise<void> {
    try {
      await this.storage.init();
    } catch (e) {
      this.errors.set([`Storage could not be opened: ${this.reason(e)}`]);
    }
    this.ready.set(true);
    void this.refreshUsage();
  }

  ngOnDestroy(): void {
    this.closePreview();
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.closePreview();
    this.toDelete.set(null);
  }

  // ───────────── choosing files ─────────────
  async onPick(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const list = input.files ? Array.from(input.files) : []; // copy BEFORE resetting
    input.value = '';                                         // lets user pick the same file again
    await this.processFiles(list);
  }

  onDragEnter(e: DragEvent): void {
    e.preventDefault();
    this.dragDepth++;
    this.isDragging.set(true);
  }
  onDragOver(e: DragEvent): void {
    e.preventDefault(); // required, otherwise the browser refuses the drop
  }
  onDragLeave(e: DragEvent): void {
    e.preventDefault();
    this.dragDepth = Math.max(0, this.dragDepth - 1);
    if (this.dragDepth === 0) this.isDragging.set(false);
  }
  async onDrop(e: DragEvent): Promise<void> {
    e.preventDefault(); // otherwise the browser opens the file in the tab
    this.dragDepth = 0;
    this.isDragging.set(false);
    const list = e.dataTransfer?.files ? Array.from(e.dataTransfer.files) : [];
    await this.processFiles(list);
  }

  // ───────────── validate + save ─────────────
  private validate(file: File): Validation {
    const category = detectCategory(file.name);
    if (!category) {
      const ext = getExtension(file.name);
      return { ok: false, error: `${file.name}: type ${ext ? '".' + ext + '"' : '(none)'} is not allowed.` };
    }
    if (file.size === 0) {
      return { ok: false, error: `${file.name}: file is empty.` };
    }
    const rule = UPLOAD_RULES[category];
    if (file.size > rule.maxMB * 1024 * 1024) {
      return {
        ok: false,
        error: `${file.name}: ${formatBytes(file.size)} is too big. ${rule.label} can be at most ${rule.maxMB} MB.`,
      };
    }
    return { ok: true, category };
  }

  private async processFiles(list: File[]): Promise<void> {
    if (list.length === 0 || this.isBusy()) return;
    this.isBusy.set(true);
    this.errors.set([]);
    this.success.set('');

    const errs: string[] = [];
    let saved = 0;
    try {
      for (const file of list) {
        const check = this.validate(file);
        if (!check.ok) { errs.push(check.error); continue; }
        try {
          await this.storage.add(file, check.category);
          saved++;
        } catch (e) {
          errs.push(`${file.name}: could not be saved (${this.reason(e)}).`);
        }
      }
    } finally {
      this.errors.set(errs);
      if (saved > 0) this.success.set(`${saved} file${saved > 1 ? 's' : ''} uploaded successfully.`);
      this.isBusy.set(false);
      void this.refreshUsage();
    }
  }

  // ───────────── preview / download / delete ─────────────
  async openPreview(meta: StoredFileMeta): Promise<void> {
    try {
      const blob = await this.storage.getBlob(meta.id);
      if (!blob) { this.errors.set([`${meta.name}: file data was not found.`]); return; }
      this.closePreview();
      const rawUrl = URL.createObjectURL(blob);
      this.preview.set({
        meta, rawUrl,
        safeUrl: this.sanitizer.bypassSecurityTrustResourceUrl(rawUrl), // blob made by us from the user's own file
        kind: this.previewKind(meta),
      });
    } catch (e) {
      this.errors.set([`${meta.name}: could not be opened (${this.reason(e)}).`]);
    }
  }

  closePreview(): void {
    const p = this.preview();
    if (p) URL.revokeObjectURL(p.rawUrl);
    this.preview.set(null);
  }

  async download(meta: StoredFileMeta): Promise<void> {
    try {
      const blob = await this.storage.getBlob(meta.id);
      if (!blob) { this.errors.set([`${meta.name}: file data was not found.`]); return; }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = meta.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      this.errors.set([`${meta.name}: download failed (${this.reason(e)}).`]);
    }
  }

  askDelete(meta: StoredFileMeta): void {
    this.toDelete.set(meta);
  }

  async confirmDelete(): Promise<void> {
    const meta = this.toDelete();
    if (!meta) return;
    this.toDelete.set(null);
    try {
      await this.storage.remove(meta.id);   // removes from IndexedDB AND localStorage AND the UI list
      if (this.preview()?.meta.id === meta.id) this.closePreview();
      this.errors.set([]);
      this.success.set(`"${meta.name}" deleted.`);
      void this.refreshUsage();
    } catch (e) {
      this.errors.set([`${meta.name}: could not be deleted (${this.reason(e)}).`]);
    }
  }

  // ───────────── helpers ─────────────
  setFilter(f: Filter): void { this.activeFilter.set(f); }
  onSearch(e: Event): void { this.search.set((e.target as HTMLInputElement).value); }
  icon(c: FileCategory): string { return UPLOAD_RULES[c].icon; }
  ext(name: string): string { return getExtension(name).toUpperCase(); }

  usagePercent(): number {
    const u = this.usage();
    return u && u.quota ? Math.min(100, Math.round((u.used / u.quota) * 100)) : 0;
  }

  private previewKind(meta: StoredFileMeta): PreviewKind {
    const ext = getExtension(meta.name);
    if (meta.category === 'image') return 'image';
    if (meta.category === 'video') return 'video';
    if (ext === 'pdf' || ext === 'txt') return 'frame';
    return 'none';
  }

  private async refreshUsage(): Promise<void> {
    try {
      if (navigator.storage?.estimate) {
        const e = await navigator.storage.estimate();
        this.usage.set({ used: e.usage ?? 0, quota: e.quota ?? 0 });
      }
    } catch { /* usage bar is optional */ }
  }

  private reason(e: unknown): string {
    if (e instanceof DOMException && e.name === 'QuotaExceededError') return 'browser storage is full';
    if (e instanceof Error && e.message) return e.message;
    if (e && typeof e === 'object' && 'name' in e) return String((e as { name: unknown }).name);
    return 'unknown error';
  }
}
