import { FileCategory } from './file-upload.model';

export interface CategoryRule {
  label: string;
  maxMB: number;          // <<< CHANGE THE SIZE LIMITS HERE
  extensions: string[];   // <<< ADD / REMOVE ALLOWED TYPES HERE (lowercase, no dot)
  icon: string;
}

export const UPLOAD_RULES: Record<FileCategory, CategoryRule> = {
  image:    { label: 'Images',    maxMB: 10, icon: '🖼️', extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'] },
  document: { label: 'Documents', maxMB: 25, icon: '📄', extensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv'] },
  video:    { label: 'Videos',    maxMB: 35, icon: '🎬', extensions: ['mp4', 'webm', 'mov', 'mkv'] },
};

export const CATEGORIES = Object.keys(UPLOAD_RULES) as FileCategory[];

/** Storage names. Bump the "_v1" if you ever change the saved format. */
export const META_KEY = 'savvy_files_meta_v1';   // localStorage key
export const DB_NAME = 'savvy_files_db';          // IndexedDB database
export const STORE_NAME = 'files';                // IndexedDB object store

export function getExtension(fileName: string): string {
  const dot = fileName.lastIndexOf('.');
  return dot >= 0 ? fileName.slice(dot + 1).toLowerCase() : '';
}

export function detectCategory(fileName: string): FileCategory | null {
  const ext = getExtension(fileName);
  if (!ext) return null;
  return CATEGORIES.find(c => UPLOAD_RULES[c].extensions.includes(ext)) ?? null;
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, i);
  return `${i === 0 ? value : value.toFixed(value < 10 ? 2 : 1)} ${units[i]}`;
}
