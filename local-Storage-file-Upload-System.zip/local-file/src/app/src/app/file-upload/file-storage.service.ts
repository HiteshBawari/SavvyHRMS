import { Injectable, signal } from '@angular/core';
import { DB_NAME, META_KEY, STORE_NAME } from './file-upload.config';
import { FileCategory, StoredFileMeta } from './file-upload.model';

/**
 * Two-place storage:
 *  - localStorage  -> small JSON list of file info (name, size, type, date)   [fast, ~5 MB limit]
 *  - IndexedDB     -> the real file bytes (Blob)                              [big, hundreds of MB]
 * Both are always changed together, so the UI list and the stored data never disagree.
 */
@Injectable({ providedIn: 'root' })
export class FileStorageService {
  private readonly _files = signal<StoredFileMeta[]>([]);
  /** Read-only list for the UI (newest first). */
  readonly files = this._files.asReadonly();

  private dbPromise: Promise<IDBDatabase> | null = null;

  constructor() {
    // If another browser tab changes the list, update this tab too.
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', (e: StorageEvent) => {
        if (e.key === META_KEY || e.key === null) this._files.set(this.readMeta());
      });
    }
  }

  // ───────────── public API ─────────────

  /** Call once when the page opens. Loads the list and repairs any mismatch (after refresh). */
  async init(): Promise<void> {
    const stored = this.readMeta();
    const keys = new Set((await this.run('readonly', s => s.getAllKeys())).map(k => String(k)));

    // 1) list says a file exists but bytes are gone -> drop it from the list
    const valid = stored.filter(m => keys.has(m.id));
    // 2) bytes exist but list has no entry -> delete the orphan bytes
    const validIds = new Set(valid.map(m => m.id));
    for (const key of keys) {
      if (!validIds.has(key)) await this.run('readwrite', s => s.delete(key));
    }

    if (valid.length !== stored.length) {
      try { localStorage.setItem(META_KEY, JSON.stringify(valid)); } catch { /* ignore, list is still shown */ }
    }
    this._files.set(valid);
  }

  async add(file: File, category: FileCategory): Promise<StoredFileMeta> {
    const id = this.makeId();
    await this.run('readwrite', s => s.put(file, id)); // 1) save the bytes
    const meta: StoredFileMeta = {
      id, name: file.name, size: file.size,
      type: file.type || 'application/octet-stream',
      category, uploadedAt: Date.now(),
    };
    try {
      this.persist([meta, ...this._files()]);            // 2) save the info card
    } catch (e) {
      await this.run('readwrite', s => s.delete(id));    // undo step 1 so nothing is half-saved
      throw e;
    }
    return meta;
  }

  async getBlob(id: string): Promise<Blob | null> {
    const result = await this.run('readonly', s => s.get(id));
    return result instanceof Blob ? result : null;
  }

  async remove(id: string): Promise<void> {
    await this.run('readwrite', s => s.delete(id));      // 1) delete bytes
    this.persist(this._files().filter(f => f.id !== id)); // 2) delete info card + refresh UI
  }

  // ───────────── internals ─────────────

  private persist(list: StoredFileMeta[]): void {
    localStorage.setItem(META_KEY, JSON.stringify(list)); // throws if storage is full
    this._files.set(list);
  }

  private readMeta(): StoredFileMeta[] {
    try {
      const raw = localStorage.getItem(META_KEY);
      if (!raw) return [];
      const parsed: unknown = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed
        .filter((m): m is StoredFileMeta =>
          !!m && typeof m.id === 'string' && typeof m.name === 'string' &&
          typeof m.size === 'number' && typeof m.uploadedAt === 'number')
        .sort((a, b) => b.uploadedAt - a.uploadedAt);
    } catch {
      return []; // corrupted JSON -> start clean instead of crashing
    }
  }

  private makeId(): string {
    return typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }

  private openDb(): Promise<IDBDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
        if (typeof indexedDB === 'undefined') {
          reject(new Error('IndexedDB is not available in this browser'));
          return;
        }
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => req.result.createObjectStore(STORE_NAME); // first run only
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => { this.dbPromise = null; reject(req.error); };
        req.onblocked = () => { this.dbPromise = null; reject(new Error('Database is blocked by another tab')); };
      });
    }
    return this.dbPromise;
  }

  /** Runs one IndexedDB operation and waits until the transaction is fully committed. */
  private async run<T>(mode: IDBTransactionMode, op: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.openDb();
    return new Promise<T>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, mode);
      const req = op(tx.objectStore(STORE_NAME));
      tx.oncomplete = () => resolve(req.result);
      tx.onerror = () => reject(tx.error ?? req.error);
      tx.onabort = () => reject(tx.error ?? req.error);
    });
  }
}
