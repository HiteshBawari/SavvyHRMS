import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', loadChildren: () => import('./src/app/file-upload/file-upload.routes').then(m => m.FILE_UPLOAD_ROUTES) },
];

