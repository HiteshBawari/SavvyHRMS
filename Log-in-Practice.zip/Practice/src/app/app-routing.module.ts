import { RouterModule, Routes } from "@angular/router";
import { Dashboard } from "./dashboard/dashboard";
import { EmployeeForm } from "./employee-form/employee-form";
import { Attendance } from "./attendance/attendance";
import { Employees } from "./employees/employees";
import { NgModule } from "@angular/core";


const routes: Routes= [
    {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
    }, 
    
    {
        path: 'dashboard',
        component: Dashboard
    },

    {
        path: 'employee-form',
        component: EmployeeForm

    },
    {
        path: 'attendance',
        component: Attendance
    },
    {
        path: 'employees',
        component: Employees
    }


];

@NgModule({
    imports:[RouterModule.forRoot(routes)],

    exports:[RouterModule]

})

export class AppRoutingModule{}
