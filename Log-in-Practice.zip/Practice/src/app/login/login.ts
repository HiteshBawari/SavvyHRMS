/*
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  imports: [FormsModule],
  standalone: true,
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

  
  private Router = inject(Router);
  userObj = {
    EmailId: '',
    Password: '',
  };
  router = inject(Router);
  http = inject(HttpClient)
  onLogin() { 
    debugger;
  this.http.post("https://projectapi.gerasim.in/api/UserApp/login", this.userObj).subscribe((res: any)=>{
    if(res.result){
      alert("Login Successfull");
      localStorage.setItem('LoginUser', JSON.stringify(res.data));
      this.router.navigateByUrl('/dashboard');
    } else{
      alert("Invalid Credentials");
    }
  })
  }
  
}
*/
/*  
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  imports: [FormsModule],
  standalone: true,
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
onLogin() { 
    debugger;
  this.http.post("https://projectapi.gerasim.in/api/UserApp/login", this.userObj).subscribe(({
    next : (res)=>{
      console.log(res);
      alert("Login Successfull");
      localStorage.setItem('LoginUser', JSON.stringify(res.data));
      this.router.navigateByUrl('/dashboard');
      
    },
    error : (err)=>{
      alert("Invalid Credentials");
      console.log(err);
    }
  }))
  
  } */
//Working Test its also working with simple Api Calling

  import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  imports: [FormsModule],
  standalone: true,
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

  
  private Router = inject(Router);
  userObj = {
    EmailId: '',
    Password: '',
  };
  router = inject(Router);
  http = inject(HttpClient) 

  onLogin() { 
    //debugger;
  this.http.post("https://projectapi.gerasim.in/api/UserApp/login", this.userObj).subscribe(({
    next : (res : any)=>{
      console.log(res);
      alert("Login Successfull");
      localStorage.setItem('LoginUser', JSON.stringify(res.data));
      this.router.navigateByUrl('/dashboard');
      
    },
    error : (err : any)=>{
      alert("Invalid Credentials");
      console.log(err);
    }
  }))
  
  }

}
  

/*
//Working Api Calling with Error Handling

import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  imports: [FormsModule],
  standalone: true,
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

  
  private Router = inject(Router);
  userObj = {
    EmailId: '',
    Password: '',
  };
  router = inject(Router);
  http = inject(HttpClient) 

  onLogin(): void {
  // Step 1: Validate the input fields
  if (
    !this.userObj.EmailId.trim() ||
    !this.userObj.Password.trim()
  ) {
    alert('Please enter your email ID and password.');
    return;
  }

  console.log('Sending login request...');

  // Step 2: Send the request and expect JSON data
  this.http.post<any>(
    'https://projectapi.gerasim.in/api/UserApp/login',
    this.userObj
  ).subscribe({
    next: (res: any) => {
      // Step 3: Inspect the API response
      console.log('API JSON response:', res);

      // Step 4: Check whether login really succeeded
      if (res?.result === true) {
        if (res.data == null) {
          alert('Login response has no user data. Check the API response.');
          return;
        }

        localStorage.setItem(
          'LoginUser',
          JSON.stringify(res.data)
        );

        alert('Login successful!');

        this.router.navigateByUrl('/dashboard');
      } else {
        // HTTP succeeded, but the login was rejected
        alert(
          res?.message ||
          res?.Message ||
          'Invalid email ID or password.'
        );
      }
    },

    error: (err: any) => {
      // Step 5: Handle HTTP, server and network errors
      console.error('Login API error:', err);

      if (err.status === 0) {
        alert('Cannot connect to the API. Check your internet or server.');
      } else if (
        err.status === 400 ||
        err.status === 401 ||
        err.status === 403
      ) {
        alert('Invalid email ID or password.');
      } else {
        alert('Login request failed. HTTP status: ' + err.status);
      }
    }
  });
}

}
*/