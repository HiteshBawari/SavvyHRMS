import { Component,inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  imports: [],
  selector: 'app-employees',
  styleUrl: './employees.css',
  templateUrl: './employees.html',
})

export class EmployeeForm {
  private route = inject(ActivatedRoute);
  id = this.route.snapshot.paramMap.get('id');   // null when adding
  isEdit = this.id !== null;
}
