import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Dashboard } from './dashboard/dashboard';
import { Attendance } from './attendance/attendance';
import { Employees } from './employees/employees';
import { EmployeeForm } from './employee-form/employee-form';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },   // empty URL goes to login
  { path: 'login', component: Login },
  { path: 'dashboard', component: Dashboard },
  { path: 'employees', component: Employees },
  { path: 'employee-form', component: EmployeeForm },
  { path: 'attendance', component: Attendance },

  { path: '**', redirectTo: 'login' },                    // MUST be last
];