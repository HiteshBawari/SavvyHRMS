import { Component, inject } from '@angular/core';
import { RouterOutlet, Router, RouterLink } from '@angular/router';

@Component({
  imports: [RouterOutlet, RouterLink],
  standalone: true,
  selector: 'app-dashboard',
  styleUrl: './dashboard.css',
  templateUrl: './dashboard.html',
})
export class Dashboard {
  private Router = inject(Router);
  loggedUserData: any;
  constructor() {
    const loggedData = localStorage.getItem('LoginUser');
    if(loggedData != null){
    this.loggedUserData = JSON.parse(loggedData); 
    }
  }
  onLogout(): void{
    localStorage.removeItem('LoginStatus');
    this.Router.navigateByUrl('/Login');
  }

}
