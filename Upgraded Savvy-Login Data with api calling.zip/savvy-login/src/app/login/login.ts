/*import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  userObj: any = {
    userName: '',
    password: ''
  };

  private router = inject(Router);

  onLogin(): void {
    const email = this.userObj.userName.trim();
    const password = this.userObj.password;

    if (
      email === 'admin@company.com' &&
      password === '112233'
    ) {
      alert('Login Successful');
      localStorage.setItem('loginStatus',this.userObj.userName);

      this.router.navigateByUrl('/dashboard');
    } else if(
      email === 'hitesh@company.com' &&
      password === '96678'
    ) {
      alert('Login Successful');
      localStorage.setItem('loginStatus',this.userObj.userName);

      this.router.navigateByUrl('/dashboard');
    }
    
    else {
      alert('Invalid email or password');
    }
  }
}*/
//API First email: vineet@gmail.com pass: 966780 , Login with API
/*
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

interface LoginRequest {
  EmailId: string;
  Password: string;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  private router = inject(Router);
  private http = inject(HttpClient);

  userObj: LoginRequest = {
    EmailId: '',
    Password: ''
  };

  isLoading = false;
  errorMessage = '';

  private readonly apiUrl =
    'https://projectapi.gerasim.in/api/UserApp/login';

  onLogin(): void {
    this.errorMessage = '';

    // Validate before sending the API request
    if (
      !this.userObj.EmailId.trim() ||
      !this.userObj.Password
    ) {
      this.errorMessage = 'Please enter your email and password.';
      return;
    }

    if (this.isLoading) {
      return;
    }

    this.isLoading = true;

    const request: LoginRequest = {
      EmailId: this.userObj.EmailId.trim(),
      Password: this.userObj.Password
    };

    this.http.post<any>(this.apiUrl, request).subscribe({
      next: (res) => {
        console.log('Login API response:', res);

        // Keep this condition only if Swagger/API response
        // confirms that "result" indicates successful login.
        if (res?.result) {
          localStorage.setItem(
            'LoginStatus',
            request.EmailId
          );

          alert('Login successful!');
          this.router.navigateByUrl('/dashboard');
        } else {
          this.errorMessage =
            res?.message || 'Login failed. Check your credentials.';
        }
      },

      error: (error: HttpErrorResponse) => {
        console.error('Login API error:', error);

        if (error.status === 0) {
          this.errorMessage =
            'Cannot connect to the API. Check your internet, CORS, or server availability.';
        } else if (error.status === 401 || error.status === 403) {
          this.errorMessage =
            'The server rejected the login. Check your credentials or API access.';
        } else {
          this.errorMessage =
            error.error?.message ||
            `Login request failed (HTTP ${error.status}).`;
        }
      },

      complete: () => {
        this.isLoading = false;
      }
    });
  }
} */

import { CommonModule } from '@angular/common';
import { Component, OnDestroy, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, timeout } from 'rxjs';

interface LoginRequest {
  EmailId: string;
  Password: string;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login implements OnDestroy {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  private readonly apiUrl =
    'https://projectapi.gerasim.in/api/UserApp/login';

  private toastTimer?: ReturnType<typeof setTimeout>;

  userObj: LoginRequest = {
    EmailId: '',
    Password: ''
  };

  // Login screen state
  step: 'email' | 'password' = 'email';
  isLoading = false;
  showPassword = false;
  submitted = false;

  // UI messages
  emailError = '';
  passwordError = '';
  successMessage = '';

  // Step 1: Validate the email format
  continueWithEmail(): void {
    this.emailError = '';
    this.passwordError = '';
    this.successMessage = '';

    const email = this.userObj.EmailId.trim();

    if (!email) {
      this.emailError = 'Please enter your work email.';
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.emailError = 'Enter a valid email address.';
      return;
    }

    this.userObj.EmailId = email;
    this.step = 'password';
  }

  // Return to the email step
  backToEmail(): void {
    if (this.isLoading) return;

    this.step = 'email';
    this.passwordError = '';
    this.successMessage = '';
  }

  // Step 2: Send login credentials to the API
  onLogin(): void {
    this.submitted = true;
    this.emailError = '';
    this.passwordError = '';
    this.successMessage = '';

    const email = this.userObj.EmailId.trim();
    const password = this.userObj.Password;

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.step = 'email';
      this.emailError = !email
        ? 'Please enter your work email.'
        : 'Enter a valid email address.';
      return;
    }

    if (!password) {
      this.passwordError = 'Please enter your password.';
      return;
    }

    if (this.isLoading) return;

    this.isLoading = true;

    const request: LoginRequest = {
      EmailId: email,
      Password: password
    };

    this.http.post<unknown>(this.apiUrl, request).pipe(
      // Prevent endless loading if the API does not respond.
      timeout({ first: 10000 }),

      // Runs on success, error, or timeout.
      finalize(() => {
        this.isLoading = false;
      })
    ).subscribe({
      next: (response: unknown) => {
        console.log('Login API response:', response);

        const result = this.readResponse(response);

        if (result.success) {
          this.passwordError = '';
          this.emailError = '';
          this.successMessage = 'Welcome back! You are signed in.';

          // UI marker only; this is not secure authentication.
          localStorage.setItem('LoginStatus', email);

          if (this.toastTimer) {
            clearTimeout(this.toastTimer);
          }

          this.toastTimer = setTimeout(() => {
            this.router.navigateByUrl('/dashboard');
          }, 1000);

          return;
        }

        this.showLoginError(result.message);
      },

      error: (error: unknown) => {
        console.error('Login API error:', error);

        if (
          error instanceof Error &&
          error.name === 'TimeoutError'
        ) {
          this.passwordError =
            'The server took too long to respond. Please try again.';
          return;
        }

        if (error instanceof HttpErrorResponse) {
          const message = this.getServerMessage(error);

          if (error.status === 0) {
            this.passwordError =
              'Cannot connect to the login service. Check your connection and try again.';
            return;
          }

          if (
            error.status === 400 ||
            error.status === 401 ||
            error.status === 403
          ) {
            this.showLoginError(message);
            return;
          }

          this.passwordError =
            message ||
            `Login failed (HTTP ${error.status}). Please try again.`;

          return;
        }

        this.passwordError =
          'Something went wrong. Please try again.';
      }
    });
  }

  // Interpret common API response formats.
  // Update this method if Swagger shows a different response schema.
  private readResponse(response: unknown): {
    success: boolean;
    message: string;
  } {
    if (!response || typeof response !== 'object') {
      return {
        success: false,
        message: 'Unexpected response from the server.'
      };
    }

    const data = response as Record<string, unknown>;

    const message =
      typeof data['message'] === 'string'
        ? data['message']
        : '';

    const success =
      data['result'] === true ||
      data['success'] === true ||
      data['isSuccess'] === true;

    return { success, message };
  }

  // Read a useful message from an HTTP error response.
  private getServerMessage(error: HttpErrorResponse): string {
    const body: unknown = error.error;

    if (typeof body === 'string' && body.trim()) {
      return body;
    }

    if (body && typeof body === 'object') {
      const data = body as Record<string, unknown>;

      for (const key of ['message', 'title', 'error']) {
        const value = data[key];

        if (typeof value === 'string' && value.trim()) {
          return value;
        }
      }
    }

    return '';
  }

  // Display an error in the appropriate field.
  private showLoginError(message: string): void {
    const text = message.trim();
    const normalized = text.toLowerCase();

    if (
      normalized.includes('email not found') ||
      normalized.includes('user not found') ||
      normalized.includes('unknown email') ||
      normalized.includes('email does not exist')
    ) {
      this.step = 'email';
      this.emailError = text;
      return;
    }

    // For generic "invalid credentials" responses, highlight password.
    this.passwordError =
      text || 'Incorrect email or password. Please try again.';
  }

  clearEmailError(): void {
    this.emailError = '';
    this.successMessage = '';
  }

  clearPasswordError(): void {
    this.passwordError = '';
    this.successMessage = '';
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  ngOnDestroy(): void {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
    }
  }
}