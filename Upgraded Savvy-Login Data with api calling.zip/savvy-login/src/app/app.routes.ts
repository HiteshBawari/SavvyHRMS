import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Dashboard } from './dashboard/dashboard';

export const routes: Routes = [
//default route
    {
path: '',
redirectTo: 'login',
pathMatch: 'full',
},
{
    path: 'login',
    component: Login,
},
{
    path : 'dashboard',
    component: Dashboard,
},
{
    path : '**',
    redirectTo: 'login',
},


];