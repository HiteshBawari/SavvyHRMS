import { Component, inject } from '@angular/core';
import { RouterOutlet, Router } from '@angular/router';

@Component({
  imports: [RouterOutlet],
  standalone: true,
  selector: 'app-dashboard',
  styleUrl: './dashboard.css',
  templateUrl: './dashboard.html',
})
export class Dashboard {
  private Router = inject(Router);
  onLogout(): void{
    localStorage.removeItem('LoginStatus');
    this.Router.navigateByUrl('/Login');
  }

}
